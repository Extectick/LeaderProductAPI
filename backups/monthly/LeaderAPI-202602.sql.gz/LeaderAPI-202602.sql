--
-- PostgreSQL database dump
--

\restrict fsEk4TJRIcRDIi1aK04dHOeLJBGwZUuye0CdidsYooNqeildaFoETULESnIuv8v

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionType" AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'LOGIN',
    'LOGOUT',
    'PASSWORD_RESET',
    'EMAIL_VERIFICATION',
    'OTHER'
);


ALTER TYPE public."ActionType" OWNER TO postgres;

--
-- Name: AppPlatform; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppPlatform" AS ENUM (
    'ANDROID',
    'IOS'
);


ALTER TYPE public."AppPlatform" OWNER TO postgres;

--
-- Name: AppUpdateEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppUpdateEventType" AS ENUM (
    'CHECK',
    'PROMPT_SHOWN',
    'UPDATE_CLICK',
    'DISMISS'
);


ALTER TYPE public."AppUpdateEventType" OWNER TO postgres;

--
-- Name: AppealPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."AppealPriority" OWNER TO postgres;

--
-- Name: AppealStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'COMPLETED',
    'DECLINED',
    'RESOLVED'
);


ALTER TYPE public."AppealStatus" OWNER TO postgres;

--
-- Name: AttachmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AttachmentType" AS ENUM (
    'IMAGE',
    'AUDIO',
    'FILE'
);


ALTER TYPE public."AttachmentType" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'DRAFT',
    'QUEUED',
    'SENT_TO_1C',
    'CONFIRMED',
    'PARTIAL',
    'REJECTED',
    'CANCELLED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- Name: ProfileStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'BLOCKED'
);


ALTER TYPE public."ProfileStatus" OWNER TO postgres;

--
-- Name: ProfileType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileType" AS ENUM (
    'CLIENT',
    'SUPPLIER',
    'EMPLOYEE'
);


ALTER TYPE public."ProfileType" OWNER TO postgres;

--
-- Name: QRStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'DELETED'
);


ALTER TYPE public."QRStatus" OWNER TO postgres;

--
-- Name: QRType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRType" AS ENUM (
    'PHONE',
    'LINK',
    'EMAIL',
    'TEXT',
    'WHATSAPP',
    'CONTACT',
    'TELEGRAM'
);


ALTER TYPE public."QRType" OWNER TO postgres;

--
-- Name: RouteEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteEventType" AS ENUM (
    'MOVE',
    'STOP'
);


ALTER TYPE public."RouteEventType" OWNER TO postgres;

--
-- Name: RouteStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."RouteStatus" OWNER TO postgres;

--
-- Name: SyncDirection; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncDirection" AS ENUM (
    'IMPORT',
    'EXPORT'
);


ALTER TYPE public."SyncDirection" OWNER TO postgres;

--
-- Name: SyncEntityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncEntityType" AS ENUM (
    'NOMENCLATURE',
    'WAREHOUSES',
    'COUNTERPARTIES',
    'AGREEMENTS',
    'PRODUCT_PRICES',
    'SPECIAL_PRICES',
    'STOCK',
    'ORDERS_EXPORT',
    'ORDERS_STATUS'
);


ALTER TYPE public."SyncEntityType" OWNER TO postgres;

--
-- Name: SyncItemStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncItemStatus" AS ENUM (
    'OK',
    'ERROR',
    'SKIPPED'
);


ALTER TYPE public."SyncItemStatus" OWNER TO postgres;

--
-- Name: SyncStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncStatus" AS ENUM (
    'STARTED',
    'COMPLETED',
    'PARTIAL',
    'FAILED'
);


ALTER TYPE public."SyncStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    id integer NOT NULL,
    street text NOT NULL,
    city text NOT NULL,
    state text,
    "postalCode" text,
    country text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Address_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Address_id_seq" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Address_id_seq" OWNED BY public."Address".id;


--
-- Name: AppUpdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdate" (
    id integer NOT NULL,
    platform public."AppPlatform" NOT NULL,
    channel text DEFAULT 'prod'::text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text NOT NULL,
    "minSupportedVersionCode" integer NOT NULL,
    "isMandatory" boolean DEFAULT false NOT NULL,
    "rolloutPercent" integer DEFAULT 100 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "releaseNotes" text,
    "storeUrl" text,
    "apkKey" text,
    "fileSize" integer,
    checksum text,
    "checksumMd5" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AppUpdate" OWNER TO postgres;

--
-- Name: AppUpdateEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdateEvent" (
    id integer NOT NULL,
    "updateId" integer,
    platform public."AppPlatform" NOT NULL,
    channel text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text,
    "deviceId" text,
    "eventType" public."AppUpdateEventType" NOT NULL,
    "userId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppUpdateEvent" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdateEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNED BY public."AppUpdateEvent".id;


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdate_id_seq" OWNER TO postgres;

--
-- Name: AppUpdate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdate_id_seq" OWNED BY public."AppUpdate".id;


--
-- Name: Appeal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appeal" (
    id integer NOT NULL,
    number integer NOT NULL,
    "fromDepartmentId" integer,
    "toDepartmentId" integer NOT NULL,
    "createdById" integer NOT NULL,
    status public."AppealStatus" DEFAULT 'OPEN'::public."AppealStatus" NOT NULL,
    priority public."AppealPriority" DEFAULT 'MEDIUM'::public."AppealPriority" NOT NULL,
    deadline timestamp(3) without time zone,
    title text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Appeal" OWNER TO postgres;

--
-- Name: AppealAssignee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAssignee" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealAssignee" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAssignee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAssignee_id_seq" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAssignee_id_seq" OWNED BY public."AppealAssignee".id;


--
-- Name: AppealAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAttachment" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text NOT NULL,
    "fileType" public."AttachmentType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealAttachment" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAttachment_id_seq" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAttachment_id_seq" OWNED BY public."AppealAttachment".id;


--
-- Name: AppealMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessage" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "senderId" integer NOT NULL,
    text text,
    "editedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessage" OWNER TO postgres;

--
-- Name: AppealMessageRead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessageRead" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "userId" integer NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessageRead" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessageRead_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNED BY public."AppealMessageRead".id;


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessage_id_seq" OWNER TO postgres;

--
-- Name: AppealMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessage_id_seq" OWNED BY public."AppealMessage".id;


--
-- Name: AppealStatusHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealStatusHistory" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "oldStatus" public."AppealStatus" NOT NULL,
    "newStatus" public."AppealStatus" NOT NULL,
    "changedById" integer NOT NULL,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealStatusHistory" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealStatusHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNED BY public."AppealStatusHistory".id;


--
-- Name: AppealWatcher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealWatcher" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealWatcher" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealWatcher_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealWatcher_id_seq" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealWatcher_id_seq" OWNED BY public."AppealWatcher".id;


--
-- Name: Appeal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Appeal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Appeal_id_seq" OWNER TO postgres;

--
-- Name: Appeal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Appeal_id_seq" OWNED BY public."Appeal".id;


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id integer NOT NULL,
    "userId" integer,
    action public."ActionType" NOT NULL,
    "targetType" text,
    "targetId" integer,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details text
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: ClientAgreement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientAgreement" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "counterpartyId" text,
    "contractId" text,
    "priceTypeId" text,
    "warehouseId" text,
    currency text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientAgreement" OWNER TO postgres;

--
-- Name: ClientContract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientContract" (
    id text NOT NULL,
    guid text NOT NULL,
    "counterpartyId" text NOT NULL,
    number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "validFrom" timestamp(3) without time zone,
    "validTo" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientContract" OWNER TO postgres;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    "avatarUrl" text,
    "counterpartyId" text,
    "activeAgreementId" text,
    "activeContractId" text,
    "activeWarehouseId" text,
    "activePriceTypeId" text,
    "activeDeliveryAddressId" text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientProfile" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ClientProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ClientProfile_id_seq" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ClientProfile_id_seq" OWNED BY public."ClientProfile".id;


--
-- Name: Counterparty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Counterparty" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "fullName" text,
    inn text,
    kpp text,
    phone text,
    email text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Counterparty" OWNER TO postgres;

--
-- Name: DeliveryAddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeliveryAddress" (
    id text NOT NULL,
    guid text,
    "counterpartyId" text NOT NULL,
    name text,
    "fullAddress" text NOT NULL,
    city text,
    street text,
    house text,
    building text,
    apartment text,
    postcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeliveryAddress" OWNER TO postgres;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: DepartmentRole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DepartmentRole" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "roleId" integer NOT NULL,
    "departmentId" integer NOT NULL
);


ALTER TABLE public."DepartmentRole" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DepartmentRole_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DepartmentRole_id_seq" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DepartmentRole_id_seq" OWNED BY public."DepartmentRole".id;


--
-- Name: Department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Department_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Department_id_seq" OWNER TO postgres;

--
-- Name: Department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Department_id_seq" OWNED BY public."Department".id;


--
-- Name: DeviceToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeviceToken" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    platform text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DeviceToken" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DeviceToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeviceToken_id_seq" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DeviceToken_id_seq" OWNED BY public."DeviceToken".id;


--
-- Name: EmailVerification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailVerification" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "attemptsCount" integer DEFAULT 0 NOT NULL,
    "lastSentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailVerification" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailVerification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailVerification_id_seq" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailVerification_id_seq" OWNED BY public."EmailVerification".id;


--
-- Name: EmployeeProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmployeeProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "departmentId" integer,
    phone text,
    "avatarUrl" text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmployeeProfile" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmployeeProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNED BY public."EmployeeProfile".id;


--
-- Name: LoginAttempt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoginAttempt" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    success boolean NOT NULL,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginAttempt" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoginAttempt_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoginAttempt_id_seq" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoginAttempt_id_seq" OWNED BY public."LoginAttempt".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    guid text,
    number1c text,
    date1c timestamp(3) without time zone,
    "counterpartyId" text NOT NULL,
    "agreementId" text,
    "contractId" text,
    "warehouseId" text,
    "deliveryAddressId" text,
    status public."OrderStatus" DEFAULT 'DRAFT'::public."OrderStatus" NOT NULL,
    comment text,
    "deliveryDate" timestamp(3) without time zone,
    "totalAmount" numeric(18,2),
    currency text,
    "queuedAt" timestamp(3) without time zone,
    "sentTo1cAt" timestamp(3) without time zone,
    "lastStatusSyncAt" timestamp(3) without time zone,
    "exportAttempts" integer DEFAULT 0 NOT NULL,
    "lastExportError" text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "packageId" text,
    "unitId" text,
    quantity numeric(18,3) NOT NULL,
    "quantityBase" numeric(18,3),
    price numeric(18,4) NOT NULL,
    "discountPercent" numeric(5,2),
    "lineAmount" numeric(18,2),
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrderItem" OWNER TO postgres;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordReset_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordReset_id_seq" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordReset_id_seq" OWNED BY public."PasswordReset".id;


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Permission" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Permission" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Permission_id_seq" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Permission_id_seq" OWNED BY public."Permission".id;


--
-- Name: PriceType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PriceType" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PriceType" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    article text,
    sku text,
    "groupId" text,
    "isWeight" boolean DEFAULT false NOT NULL,
    "isService" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "baseUnitId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: ProductGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductGroup" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductGroup" OWNER TO postgres;

--
-- Name: ProductPackage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPackage" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "unitId" text NOT NULL,
    name text NOT NULL,
    multiplier numeric(18,4) NOT NULL,
    barcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPackage" OWNER TO postgres;

--
-- Name: ProductPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPrice" OWNER TO postgres;

--
-- Name: QRAnalytic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRAnalytic" (
    id integer NOT NULL,
    ip text,
    location text,
    browser text,
    device text,
    "scanDuration" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "qrListId" text NOT NULL
);


ALTER TABLE public."QRAnalytic" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."QRAnalytic_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QRAnalytic_id_seq" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."QRAnalytic_id_seq" OWNED BY public."QRAnalytic".id;


--
-- Name: QRList; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRList" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    status public."QRStatus" DEFAULT 'ACTIVE'::public."QRStatus" NOT NULL,
    "createdById" integer NOT NULL,
    "qrData" text NOT NULL,
    "qrType" public."QRType" DEFAULT 'TEXT'::public."QRType" NOT NULL,
    description text
);


ALTER TABLE public."QRList" OWNER TO postgres;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RefreshToken" (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RefreshToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RefreshToken_id_seq" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RefreshToken_id_seq" OWNED BY public."RefreshToken".id;


--
-- Name: Role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Role" (
    id integer NOT NULL,
    name text NOT NULL,
    "parentRoleId" integer
);


ALTER TABLE public."Role" OWNER TO postgres;

--
-- Name: RolePermissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RolePermissions" (
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public."RolePermissions" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Role_id_seq" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Role_id_seq" OWNED BY public."Role".id;


--
-- Name: RoutePoint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RoutePoint" (
    id integer NOT NULL,
    "routeId" integer NOT NULL,
    "userId" integer NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    "recordedAt" timestamp(3) without time zone NOT NULL,
    "eventType" public."RouteEventType" DEFAULT 'MOVE'::public."RouteEventType" NOT NULL,
    accuracy double precision,
    speed double precision,
    heading double precision,
    "stayDurationSeconds" integer,
    sequence integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RoutePoint" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RoutePoint_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RoutePoint_id_seq" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RoutePoint_id_seq" OWNED BY public."RoutePoint".id;


--
-- Name: SpecialPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SpecialPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "counterpartyId" text,
    "agreementId" text,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SpecialPrice" OWNER TO postgres;

--
-- Name: StockBalance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StockBalance" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "warehouseId" text NOT NULL,
    quantity numeric(18,3) NOT NULL,
    reserved numeric(18,3),
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone
);


ALTER TABLE public."StockBalance" OWNER TO postgres;

--
-- Name: SupplierProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SupplierProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    "avatarUrl" text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SupplierProfile" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SupplierProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SupplierProfile_id_seq" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SupplierProfile_id_seq" OWNED BY public."SupplierProfile".id;


--
-- Name: SyncRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRun" (
    id text NOT NULL,
    "requestId" text NOT NULL,
    entity public."SyncEntityType" NOT NULL,
    direction public."SyncDirection" NOT NULL,
    status public."SyncStatus" DEFAULT 'STARTED'::public."SyncStatus" NOT NULL,
    "totalCount" integer DEFAULT 0 NOT NULL,
    "successCount" integer DEFAULT 0 NOT NULL,
    "errorCount" integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    notes text,
    meta jsonb
);


ALTER TABLE public."SyncRun" OWNER TO postgres;

--
-- Name: SyncRunItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRunItem" (
    id text NOT NULL,
    "runId" text NOT NULL,
    key text NOT NULL,
    status public."SyncItemStatus" NOT NULL,
    error text,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SyncRunItem" OWNER TO postgres;

--
-- Name: Unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Unit" (
    id text NOT NULL,
    guid text,
    name text NOT NULL,
    code text,
    symbol text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Unit" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "roleId" integer NOT NULL,
    "firstName" text,
    "lastName" text,
    "middleName" text,
    phone text,
    "avatarUrl" text,
    "deletedAt" timestamp(3) without time zone,
    "currentProfileType" public."ProfileType",
    "profileStatus" public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "lastSeenAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserRoute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserRoute" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    status public."RouteStatus" DEFAULT 'ACTIVE'::public."RouteStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserRoute" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserRoute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserRoute_id_seq" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserRoute_id_seq" OWNED BY public."UserRoute".id;


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warehouse" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isPickup" boolean DEFAULT false NOT NULL,
    address text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Warehouse" OWNER TO postgres;

--
-- Name: _EmployeeDepartmentRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_EmployeeDepartmentRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_EmployeeDepartmentRoles" OWNER TO postgres;

--
-- Name: Address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address" ALTER COLUMN id SET DEFAULT nextval('public."Address_id_seq"'::regclass);


--
-- Name: AppUpdate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdate_id_seq"'::regclass);


--
-- Name: AppUpdateEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdateEvent_id_seq"'::regclass);


--
-- Name: Appeal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal" ALTER COLUMN id SET DEFAULT nextval('public."Appeal_id_seq"'::regclass);


--
-- Name: AppealAssignee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee" ALTER COLUMN id SET DEFAULT nextval('public."AppealAssignee_id_seq"'::regclass);


--
-- Name: AppealAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment" ALTER COLUMN id SET DEFAULT nextval('public."AppealAttachment_id_seq"'::regclass);


--
-- Name: AppealMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessage_id_seq"'::regclass);


--
-- Name: AppealMessageRead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessageRead_id_seq"'::regclass);


--
-- Name: AppealStatusHistory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory" ALTER COLUMN id SET DEFAULT nextval('public."AppealStatusHistory_id_seq"'::regclass);


--
-- Name: AppealWatcher id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher" ALTER COLUMN id SET DEFAULT nextval('public."AppealWatcher_id_seq"'::regclass);


--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: ClientProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile" ALTER COLUMN id SET DEFAULT nextval('public."ClientProfile_id_seq"'::regclass);


--
-- Name: Department id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department" ALTER COLUMN id SET DEFAULT nextval('public."Department_id_seq"'::regclass);


--
-- Name: DepartmentRole id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole" ALTER COLUMN id SET DEFAULT nextval('public."DepartmentRole_id_seq"'::regclass);


--
-- Name: DeviceToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken" ALTER COLUMN id SET DEFAULT nextval('public."DeviceToken_id_seq"'::regclass);


--
-- Name: EmailVerification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification" ALTER COLUMN id SET DEFAULT nextval('public."EmailVerification_id_seq"'::regclass);


--
-- Name: EmployeeProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile" ALTER COLUMN id SET DEFAULT nextval('public."EmployeeProfile_id_seq"'::regclass);


--
-- Name: LoginAttempt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt" ALTER COLUMN id SET DEFAULT nextval('public."LoginAttempt_id_seq"'::regclass);


--
-- Name: PasswordReset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset" ALTER COLUMN id SET DEFAULT nextval('public."PasswordReset_id_seq"'::regclass);


--
-- Name: Permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission" ALTER COLUMN id SET DEFAULT nextval('public."Permission_id_seq"'::regclass);


--
-- Name: QRAnalytic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic" ALTER COLUMN id SET DEFAULT nextval('public."QRAnalytic_id_seq"'::regclass);


--
-- Name: RefreshToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken" ALTER COLUMN id SET DEFAULT nextval('public."RefreshToken_id_seq"'::regclass);


--
-- Name: Role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role" ALTER COLUMN id SET DEFAULT nextval('public."Role_id_seq"'::regclass);


--
-- Name: RoutePoint id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint" ALTER COLUMN id SET DEFAULT nextval('public."RoutePoint_id_seq"'::regclass);


--
-- Name: SupplierProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile" ALTER COLUMN id SET DEFAULT nextval('public."SupplierProfile_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserRoute id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute" ALTER COLUMN id SET DEFAULT nextval('public."UserRoute_id_seq"'::regclass);


--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (id, street, city, state, "postalCode", country, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdate" (id, platform, channel, "versionCode", "versionName", "minSupportedVersionCode", "isMandatory", "rolloutPercent", "isActive", "releaseNotes", "storeUrl", "apkKey", "fileSize", checksum, "checksumMd5", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdateEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdateEvent" (id, "updateId", platform, channel, "versionCode", "versionName", "deviceId", "eventType", "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Appeal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appeal" (id, number, "fromDepartmentId", "toDepartmentId", "createdById", status, priority, deadline, title, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppealAssignee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAssignee" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AppealAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAttachment" (id, "messageId", "fileUrl", "fileName", "fileType", "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessage" (id, "appealId", "senderId", text, "editedAt", deleted, "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessageRead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessageRead" (id, "messageId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: AppealStatusHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealStatusHistory" (id, "appealId", "oldStatus", "newStatus", "changedById", "changedAt") FROM stdin;
\.


--
-- Data for Name: AppealWatcher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealWatcher" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", action, "targetType", "targetId", "timestamp", details) FROM stdin;
1	1	LOGIN	USER	1	2026-02-03 17:44:18.591	Успешный вход в систему
\.


--
-- Data for Name: ClientAgreement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientAgreement" (id, guid, name, "counterpartyId", "contractId", "priceTypeId", "warehouseId", currency, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientContract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientContract" (id, guid, "counterpartyId", number, date, "validFrom", "validTo", "isActive", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientProfile" (id, "userId", "addressId", phone, "avatarUrl", "counterpartyId", "activeAgreementId", "activeContractId", "activeWarehouseId", "activePriceTypeId", "activeDeliveryAddressId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Counterparty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Counterparty" (id, guid, name, "fullName", inn, kpp, phone, email, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DeliveryAddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeliveryAddress" (id, guid, "counterpartyId", name, "fullAddress", city, street, house, building, apartment, postcode, "isDefault", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" (id, name) FROM stdin;
1	IT Отдел
2	Бухгалтерия
3	Маркетинг
4	Менеджеры
\.


--
-- Data for Name: DepartmentRole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DepartmentRole" (id, "userId", "roleId", "departmentId") FROM stdin;
\.


--
-- Data for Name: DeviceToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeviceToken" (id, "userId", token, platform, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailVerification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailVerification" (id, "userId", code, "expiresAt", used, "attemptsCount", "lastSentAt", "createdAt") FROM stdin;
1	1	453388	2026-02-03 18:38:01.579	t	0	2026-02-03 17:38:01.579	2026-02-03 17:38:01.583
\.


--
-- Data for Name: EmployeeProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmployeeProfile" (id, "userId", "departmentId", phone, "avatarUrl", status, "createdAt", "updatedAt") FROM stdin;
1	1	1	+7 (961) 223-13-45	avatars/1770141022478_04a3302a	ACTIVE	2026-02-03 17:38:40.744	2026-02-03 17:50:22.491
\.


--
-- Data for Name: LoginAttempt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoginAttempt" (id, "userId", success, ip, "createdAt") FROM stdin;
1	1	t	::ffff:172.20.0.1	2026-02-03 17:44:18.589
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, guid, number1c, date1c, "counterpartyId", "agreementId", "contractId", "warehouseId", "deliveryAddressId", status, comment, "deliveryDate", "totalAmount", currency, "queuedAt", "sentTo1cAt", "lastStatusSyncAt", "exportAttempts", "lastExportError", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderItem" (id, "orderId", "productId", "packageId", "unitId", quantity, "quantityBase", price, "discountPercent", "lineAmount", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordReset" (id, "userId", code, "expiresAt", used, "createdAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Permission" (id, name) FROM stdin;
1	view_profile
2	update_profile
3	logout
4	manage_roles
5	manage_permissions
6	assign_roles
7	assign_permissions
8	manage_departments
9	manage_users
10	view_fin_reports
11	approve_payments
12	manage_payroll
13	view_shipments
14	manage_shipments
15	manage_inventory
16	create_appeal
17	view_appeal
18	assign_appeal
19	update_appeal_status
20	add_appeal_message
21	edit_appeal_message
22	delete_appeal_message
23	manage_appeal_watchers
24	export_appeals
25	manage_updates
\.


--
-- Data for Name: PriceType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PriceType" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, guid, name, code, article, sku, "groupId", "isWeight", "isService", "isActive", "sourceUpdatedAt", "lastSyncedAt", "baseUnitId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductGroup" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPackage" (id, guid, "productId", "unitId", name, multiplier, barcode, "isDefault", "sortOrder", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPrice" (id, guid, "productId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: QRAnalytic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRAnalytic" (id, ip, location, browser, device, "scanDuration", "createdAt", "qrListId") FROM stdin;
\.


--
-- Data for Name: QRList; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRList" (id, "createdAt", "updatedAt", status, "createdById", "qrData", "qrType", description) FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt", revoked) FROM stdin;
1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImYyNWJiM2JiLWEyYWYtNDNhNy04YWY0LTI1OTE1NjIxZDI2YiIsImlhdCI6MTc3MDE0MDMwMiwiZXhwIjoxNzcyNzMyMzAyfQ.IueLnezmGohg-W-BniabrIe2j-D0b4CaLyR5BhEPh_Q	1	2026-03-05 17:38:22.513	2026-02-03 17:38:22.514	f
2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImU0M2M2ZjJiLWIwNDYtNDRkMi04Y2JkLThmNGFlYzI3OGQ0NyIsImlhdCI6MTc3MDE0MDY1OCwiZXhwIjoxNzcyNzMyNjU4fQ.x5KgLrhJKkWr2qFHwOssyCKUpPBJtCGQ3JewQ2P3ylo	1	2026-03-05 17:44:18.584	2026-02-03 17:44:18.585	f
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Role" (id, name, "parentRoleId") FROM stdin;
1	user	\N
2	employee	1
3	department_manager	2
4	admin	3
\.


--
-- Data for Name: RolePermissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RolePermissions" ("roleId", "permissionId") FROM stdin;
1	1
1	2
1	3
2	16
2	17
2	20
2	21
2	22
2	23
3	18
3	19
3	24
4	1
4	2
4	3
4	4
4	5
4	6
4	7
4	8
4	9
4	10
4	11
4	12
4	13
4	14
4	15
4	16
4	17
4	18
4	19
4	20
4	21
4	22
4	23
4	24
4	25
\.


--
-- Data for Name: RoutePoint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RoutePoint" (id, "routeId", "userId", latitude, longitude, "recordedAt", "eventType", accuracy, speed, heading, "stayDurationSeconds", sequence, "createdAt") FROM stdin;
\.


--
-- Data for Name: SpecialPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SpecialPrice" (id, guid, "productId", "counterpartyId", "agreementId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockBalance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StockBalance" (id, "productId", "warehouseId", quantity, reserved, "updatedAt", "sourceUpdatedAt", "lastSyncedAt") FROM stdin;
\.


--
-- Data for Name: SupplierProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SupplierProfile" (id, "userId", "addressId", phone, "avatarUrl", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SyncRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRun" (id, "requestId", entity, direction, status, "totalCount", "successCount", "errorCount", "startedAt", "finishedAt", notes, meta) FROM stdin;
\.


--
-- Data for Name: SyncRunItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRunItem" (id, "runId", key, status, error, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: Unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Unit" (id, guid, name, code, symbol, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, "passwordHash", "isActive", "roleId", "firstName", "lastName", "middleName", phone, "avatarUrl", "deletedAt", "currentProfileType", "profileStatus", "lastSeenAt", "createdAt", "updatedAt") FROM stdin;
1	extectick@yandex.ru	$2b$10$C7HdGPZn/SowVsH63AVsPOTQT1nzf.TKM7D7vp6TVKluOgvUQLQwi	t	4	Алексей	Борховецкий	Евгеньевич	\N	\N	\N	EMPLOYEE	ACTIVE	2026-02-03 17:52:25.683	2026-02-03 17:38:01.564	2026-02-03 17:52:25.685
\.


--
-- Data for Name: UserRoute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserRoute" (id, "userId", status, "startedAt", "endedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warehouse" (id, guid, name, code, "isActive", "isDefault", "isPickup", address, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _EmployeeDepartmentRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_EmployeeDepartmentRoles" ("A", "B") FROM stdin;
\.


--
-- Name: Address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Address_id_seq"', 1, false);


--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdateEvent_id_seq"', 1, false);


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdate_id_seq"', 1, false);


--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAssignee_id_seq"', 1, false);


--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAttachment_id_seq"', 1, false);


--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessageRead_id_seq"', 1, false);


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessage_id_seq"', 1, false);


--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealStatusHistory_id_seq"', 1, false);


--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealWatcher_id_seq"', 1, false);


--
-- Name: Appeal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Appeal_id_seq"', 1, false);


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 1, true);


--
-- Name: ClientProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ClientProfile_id_seq"', 1, false);


--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DepartmentRole_id_seq"', 1, false);


--
-- Name: Department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Department_id_seq"', 4, true);


--
-- Name: DeviceToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DeviceToken_id_seq"', 1, false);


--
-- Name: EmailVerification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailVerification_id_seq"', 1, true);


--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmployeeProfile_id_seq"', 1, true);


--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoginAttempt_id_seq"', 1, true);


--
-- Name: PasswordReset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordReset_id_seq"', 1, false);


--
-- Name: Permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Permission_id_seq"', 25, true);


--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."QRAnalytic_id_seq"', 1, false);


--
-- Name: RefreshToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RefreshToken_id_seq"', 2, true);


--
-- Name: Role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Role_id_seq"', 4, true);


--
-- Name: RoutePoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RoutePoint_id_seq"', 1, false);


--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SupplierProfile_id_seq"', 1, false);


--
-- Name: UserRoute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserRoute_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdateEvent AppUpdateEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdate AppUpdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate"
    ADD CONSTRAINT "AppUpdate_pkey" PRIMARY KEY (id);


--
-- Name: AppealAssignee AppealAssignee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_pkey" PRIMARY KEY (id);


--
-- Name: AppealAttachment AppealAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessageRead AppealMessageRead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessage AppealMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_pkey" PRIMARY KEY (id);


--
-- Name: AppealStatusHistory AppealStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: AppealWatcher AppealWatcher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_pkey" PRIMARY KEY (id);


--
-- Name: Appeal Appeal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ClientAgreement ClientAgreement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_pkey" PRIMARY KEY (id);


--
-- Name: ClientContract ClientContract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: Counterparty Counterparty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Counterparty"
    ADD CONSTRAINT "Counterparty_pkey" PRIMARY KEY (id);


--
-- Name: DeliveryAddress DeliveryAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_pkey" PRIMARY KEY (id);


--
-- Name: DepartmentRole DepartmentRole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_pkey" PRIMARY KEY (id);


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY (id);


--
-- Name: DeviceToken DeviceToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_pkey" PRIMARY KEY (id);


--
-- Name: EmailVerification EmailVerification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeProfile EmployeeProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_pkey" PRIMARY KEY (id);


--
-- Name: LoginAttempt LoginAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PriceType PriceType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceType"
    ADD CONSTRAINT "PriceType_pkey" PRIMARY KEY (id);


--
-- Name: ProductGroup ProductGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_pkey" PRIMARY KEY (id);


--
-- Name: ProductPackage ProductPackage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_pkey" PRIMARY KEY (id);


--
-- Name: ProductPrice ProductPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: QRAnalytic QRAnalytic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_pkey" PRIMARY KEY (id);


--
-- Name: QRList QRList_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: RolePermissions RolePermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_pkey" PRIMARY KEY ("roleId", "permissionId");


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: RoutePoint RoutePoint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_pkey" PRIMARY KEY (id);


--
-- Name: SpecialPrice SpecialPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_pkey" PRIMARY KEY (id);


--
-- Name: StockBalance StockBalance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_pkey" PRIMARY KEY (id);


--
-- Name: SupplierProfile SupplierProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_pkey" PRIMARY KEY (id);


--
-- Name: SyncRunItem SyncRunItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_pkey" PRIMARY KEY (id);


--
-- Name: SyncRun SyncRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRun"
    ADD CONSTRAINT "SyncRun_pkey" PRIMARY KEY (id);


--
-- Name: Unit Unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unit"
    ADD CONSTRAINT "Unit_pkey" PRIMARY KEY (id);


--
-- Name: UserRoute UserRoute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY (id);


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: AppUpdateEvent_deviceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_deviceId_idx" ON public."AppUpdateEvent" USING btree ("deviceId");


--
-- Name: AppUpdateEvent_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_platform_channel_versionCode_idx" ON public."AppUpdateEvent" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdateEvent_updateId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_updateId_idx" ON public."AppUpdateEvent" USING btree ("updateId");


--
-- Name: AppUpdate_platform_channel_minSupportedVersionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_minSupportedVersionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "minSupportedVersionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_versionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppUpdate_platform_channel_versionCode_key" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppealAssignee_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealAssignee_appealId_userId_key" ON public."AppealAssignee" USING btree ("appealId", "userId");


--
-- Name: AppealMessageRead_messageId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealMessageRead_messageId_userId_key" ON public."AppealMessageRead" USING btree ("messageId", "userId");


--
-- Name: AppealWatcher_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealWatcher_appealId_userId_key" ON public."AppealWatcher" USING btree ("appealId", "userId");


--
-- Name: Appeal_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Appeal_number_key" ON public."Appeal" USING btree (number);


--
-- Name: ClientAgreement_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_contractId_idx" ON public."ClientAgreement" USING btree ("contractId");


--
-- Name: ClientAgreement_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_counterpartyId_idx" ON public."ClientAgreement" USING btree ("counterpartyId");


--
-- Name: ClientAgreement_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientAgreement_guid_key" ON public."ClientAgreement" USING btree (guid);


--
-- Name: ClientAgreement_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_isActive_idx" ON public."ClientAgreement" USING btree ("isActive");


--
-- Name: ClientAgreement_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_priceTypeId_idx" ON public."ClientAgreement" USING btree ("priceTypeId");


--
-- Name: ClientAgreement_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_sourceUpdatedAt_idx" ON public."ClientAgreement" USING btree ("sourceUpdatedAt");


--
-- Name: ClientAgreement_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_warehouseId_idx" ON public."ClientAgreement" USING btree ("warehouseId");


--
-- Name: ClientContract_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_counterpartyId_idx" ON public."ClientContract" USING btree ("counterpartyId");


--
-- Name: ClientContract_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientContract_guid_key" ON public."ClientContract" USING btree (guid);


--
-- Name: ClientContract_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_isActive_idx" ON public."ClientContract" USING btree ("isActive");


--
-- Name: ClientContract_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_sourceUpdatedAt_idx" ON public."ClientContract" USING btree ("sourceUpdatedAt");


--
-- Name: ClientProfile_activeAgreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeAgreementId_idx" ON public."ClientProfile" USING btree ("activeAgreementId");


--
-- Name: ClientProfile_activeContractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeContractId_idx" ON public."ClientProfile" USING btree ("activeContractId");


--
-- Name: ClientProfile_activeDeliveryAddressId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeDeliveryAddressId_idx" ON public."ClientProfile" USING btree ("activeDeliveryAddressId");


--
-- Name: ClientProfile_activePriceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activePriceTypeId_idx" ON public."ClientProfile" USING btree ("activePriceTypeId");


--
-- Name: ClientProfile_activeWarehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeWarehouseId_idx" ON public."ClientProfile" USING btree ("activeWarehouseId");


--
-- Name: ClientProfile_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_counterpartyId_idx" ON public."ClientProfile" USING btree ("counterpartyId");


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: Counterparty_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Counterparty_guid_key" ON public."Counterparty" USING btree (guid);


--
-- Name: Counterparty_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_isActive_idx" ON public."Counterparty" USING btree ("isActive");


--
-- Name: Counterparty_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_sourceUpdatedAt_idx" ON public."Counterparty" USING btree ("sourceUpdatedAt");


--
-- Name: DeliveryAddress_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_counterpartyId_idx" ON public."DeliveryAddress" USING btree ("counterpartyId");


--
-- Name: DeliveryAddress_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeliveryAddress_guid_key" ON public."DeliveryAddress" USING btree (guid);


--
-- Name: DeliveryAddress_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_isActive_idx" ON public."DeliveryAddress" USING btree ("isActive");


--
-- Name: DeliveryAddress_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_sourceUpdatedAt_idx" ON public."DeliveryAddress" USING btree ("sourceUpdatedAt");


--
-- Name: DepartmentRole_userId_roleId_departmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DepartmentRole_userId_roleId_departmentId_key" ON public."DepartmentRole" USING btree ("userId", "roleId", "departmentId");


--
-- Name: Department_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Department_name_key" ON public."Department" USING btree (name);


--
-- Name: DeviceToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeviceToken_token_key" ON public."DeviceToken" USING btree (token);


--
-- Name: EmployeeProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmployeeProfile_userId_key" ON public."EmployeeProfile" USING btree ("userId");


--
-- Name: OrderItem_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_orderId_idx" ON public."OrderItem" USING btree ("orderId");


--
-- Name: OrderItem_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_productId_idx" ON public."OrderItem" USING btree ("productId");


--
-- Name: OrderItem_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_sourceUpdatedAt_idx" ON public."OrderItem" USING btree ("sourceUpdatedAt");


--
-- Name: Order_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_agreementId_idx" ON public."Order" USING btree ("agreementId");


--
-- Name: Order_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_contractId_idx" ON public."Order" USING btree ("contractId");


--
-- Name: Order_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_counterpartyId_idx" ON public."Order" USING btree ("counterpartyId");


--
-- Name: Order_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_guid_key" ON public."Order" USING btree (guid);


--
-- Name: Order_queuedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_queuedAt_idx" ON public."Order" USING btree ("queuedAt");


--
-- Name: Order_sentTo1cAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sentTo1cAt_idx" ON public."Order" USING btree ("sentTo1cAt");


--
-- Name: Order_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sourceUpdatedAt_idx" ON public."Order" USING btree ("sourceUpdatedAt");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: Order_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_warehouseId_idx" ON public."Order" USING btree ("warehouseId");


--
-- Name: Permission_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Permission_name_key" ON public."Permission" USING btree (name);


--
-- Name: PriceType_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PriceType_guid_key" ON public."PriceType" USING btree (guid);


--
-- Name: PriceType_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_isActive_idx" ON public."PriceType" USING btree ("isActive");


--
-- Name: PriceType_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_sourceUpdatedAt_idx" ON public."PriceType" USING btree ("sourceUpdatedAt");


--
-- Name: ProductGroup_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductGroup_guid_key" ON public."ProductGroup" USING btree (guid);


--
-- Name: ProductGroup_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_isActive_idx" ON public."ProductGroup" USING btree ("isActive");


--
-- Name: ProductGroup_parentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_parentId_idx" ON public."ProductGroup" USING btree ("parentId");


--
-- Name: ProductGroup_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_sourceUpdatedAt_idx" ON public."ProductGroup" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPackage_barcode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_barcode_idx" ON public."ProductPackage" USING btree (barcode);


--
-- Name: ProductPackage_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPackage_guid_key" ON public."ProductPackage" USING btree (guid);


--
-- Name: ProductPackage_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_productId_idx" ON public."ProductPackage" USING btree ("productId");


--
-- Name: ProductPackage_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_sourceUpdatedAt_idx" ON public."ProductPackage" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_guid_key" ON public."ProductPrice" USING btree (guid);


--
-- Name: ProductPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_isActive_idx" ON public."ProductPrice" USING btree ("isActive");


--
-- Name: ProductPrice_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_priceTypeId_idx" ON public."ProductPrice" USING btree ("priceTypeId");


--
-- Name: ProductPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_productId_idx" ON public."ProductPrice" USING btree ("productId");


--
-- Name: ProductPrice_productId_priceTypeId_startDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_productId_priceTypeId_startDate_key" ON public."ProductPrice" USING btree ("productId", "priceTypeId", "startDate");


--
-- Name: ProductPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_sourceUpdatedAt_idx" ON public."ProductPrice" USING btree ("sourceUpdatedAt");


--
-- Name: Product_article_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_article_idx" ON public."Product" USING btree (article);


--
-- Name: Product_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_groupId_idx" ON public."Product" USING btree ("groupId");


--
-- Name: Product_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Product_guid_key" ON public."Product" USING btree (guid);


--
-- Name: Product_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_isActive_idx" ON public."Product" USING btree ("isActive");


--
-- Name: Product_sku_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sku_idx" ON public."Product" USING btree (sku);


--
-- Name: Product_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sourceUpdatedAt_idx" ON public."Product" USING btree ("sourceUpdatedAt");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: RoutePoint_routeId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_routeId_recordedAt_idx" ON public."RoutePoint" USING btree ("routeId", "recordedAt");


--
-- Name: RoutePoint_userId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_userId_recordedAt_idx" ON public."RoutePoint" USING btree ("userId", "recordedAt");


--
-- Name: SpecialPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_guid_key" ON public."SpecialPrice" USING btree (guid);


--
-- Name: SpecialPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_isActive_idx" ON public."SpecialPrice" USING btree ("isActive");


--
-- Name: SpecialPrice_productId_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_agreementId_idx" ON public."SpecialPrice" USING btree ("productId", "agreementId");


--
-- Name: SpecialPrice_productId_counterpartyId_agreementId_priceType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_productId_counterpartyId_agreementId_priceType_key" ON public."SpecialPrice" USING btree ("productId", "counterpartyId", "agreementId", "priceTypeId", "startDate");


--
-- Name: SpecialPrice_productId_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_counterpartyId_idx" ON public."SpecialPrice" USING btree ("productId", "counterpartyId");


--
-- Name: SpecialPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_idx" ON public."SpecialPrice" USING btree ("productId");


--
-- Name: SpecialPrice_productId_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_priceTypeId_idx" ON public."SpecialPrice" USING btree ("productId", "priceTypeId");


--
-- Name: SpecialPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_sourceUpdatedAt_idx" ON public."SpecialPrice" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_productId_warehouseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StockBalance_productId_warehouseId_key" ON public."StockBalance" USING btree ("productId", "warehouseId");


--
-- Name: StockBalance_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_sourceUpdatedAt_idx" ON public."StockBalance" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_updatedAt_idx" ON public."StockBalance" USING btree ("updatedAt");


--
-- Name: StockBalance_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_warehouseId_idx" ON public."StockBalance" USING btree ("warehouseId");


--
-- Name: SupplierProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SupplierProfile_userId_key" ON public."SupplierProfile" USING btree ("userId");


--
-- Name: SyncRunItem_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_key_idx" ON public."SyncRunItem" USING btree (key);


--
-- Name: SyncRunItem_runId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_runId_idx" ON public."SyncRunItem" USING btree ("runId");


--
-- Name: SyncRunItem_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_status_idx" ON public."SyncRunItem" USING btree (status);


--
-- Name: SyncRun_entity_direction_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_entity_direction_startedAt_idx" ON public."SyncRun" USING btree (entity, direction, "startedAt");


--
-- Name: SyncRun_requestId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SyncRun_requestId_key" ON public."SyncRun" USING btree ("requestId");


--
-- Name: SyncRun_status_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_status_startedAt_idx" ON public."SyncRun" USING btree (status, "startedAt");


--
-- Name: Unit_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Unit_guid_key" ON public."Unit" USING btree (guid);


--
-- Name: Unit_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Unit_sourceUpdatedAt_idx" ON public."Unit" USING btree ("sourceUpdatedAt");


--
-- Name: UserRoute_userId_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserRoute_userId_startedAt_idx" ON public."UserRoute" USING btree ("userId", "startedAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Warehouse_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Warehouse_guid_key" ON public."Warehouse" USING btree (guid);


--
-- Name: Warehouse_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isActive_idx" ON public."Warehouse" USING btree ("isActive");


--
-- Name: Warehouse_isDefault_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isDefault_idx" ON public."Warehouse" USING btree ("isDefault");


--
-- Name: Warehouse_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_sourceUpdatedAt_idx" ON public."Warehouse" USING btree ("sourceUpdatedAt");


--
-- Name: _EmployeeDepartmentRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_EmployeeDepartmentRoles_B_index" ON public."_EmployeeDepartmentRoles" USING btree ("B");


--
-- Name: AppUpdateEvent AppUpdateEvent_updateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_updateId_fkey" FOREIGN KEY ("updateId") REFERENCES public."AppUpdate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppUpdateEvent AppUpdateEvent_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppealAssignee AppealAssignee_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAssignee AppealAssignee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAttachment AppealAttachment_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessageRead AppealMessageRead_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessageRead AppealMessageRead_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessage AppealMessage_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessage AppealMessage_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_changedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_changedById_fkey" FOREIGN KEY ("changedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_fromDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_fromDepartmentId_fkey" FOREIGN KEY ("fromDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appeal Appeal_toDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_toDepartmentId_fkey" FOREIGN KEY ("toDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientContract ClientContract_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientProfile ClientProfile_activeAgreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeAgreementId_fkey" FOREIGN KEY ("activeAgreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeContractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeContractId_fkey" FOREIGN KEY ("activeContractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeDeliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeDeliveryAddressId_fkey" FOREIGN KEY ("activeDeliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activePriceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activePriceTypeId_fkey" FOREIGN KEY ("activePriceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeWarehouseId_fkey" FOREIGN KEY ("activeWarehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeliveryAddress DeliveryAddress_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeviceToken DeviceToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailVerification EmailVerification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeProfile EmployeeProfile_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmployeeProfile EmployeeProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LoginAttempt LoginAttempt_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_packageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES public."ProductPackage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_deliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_deliveryAddressId_fkey" FOREIGN KEY ("deliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductGroup ProductGroup_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPackage ProductPackage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPackage ProductPackage_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPrice ProductPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPrice ProductPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_baseUnitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_baseUnitId_fkey" FOREIGN KEY ("baseUnitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QRAnalytic QRAnalytic_qrListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_qrListId_fkey" FOREIGN KEY ("qrListId") REFERENCES public."QRList"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QRList QRList_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Role Role_parentRoleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_parentRoleId_fkey" FOREIGN KEY ("parentRoleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RoutePoint RoutePoint_routeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_routeId_fkey" FOREIGN KEY ("routeId") REFERENCES public."UserRoute"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RoutePoint RoutePoint_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SpecialPrice SpecialPrice_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SupplierProfile SupplierProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SupplierProfile SupplierProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SyncRunItem SyncRunItem_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."SyncRun"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRoute UserRoute_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."DepartmentRole"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."EmployeeProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fsEk4TJRIcRDIi1aK04dHOeLJBGwZUuye0CdidsYooNqeildaFoETULESnIuv8v

