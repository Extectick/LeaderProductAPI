--
-- PostgreSQL database dump
--

\restrict uxaaTUx5JE6ybY1ZZoN1tlMLBsPdvKWvCPUWISaC3wZ9SkJr8zqVK9xHfMf04dD

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionType" AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'LOGIN',
    'LOGOUT',
    'PASSWORD_RESET',
    'EMAIL_VERIFICATION',
    'OTHER'
);


ALTER TYPE public."ActionType" OWNER TO postgres;

--
-- Name: AppPlatform; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppPlatform" AS ENUM (
    'ANDROID',
    'IOS'
);


ALTER TYPE public."AppPlatform" OWNER TO postgres;

--
-- Name: AppUpdateEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppUpdateEventType" AS ENUM (
    'CHECK',
    'PROMPT_SHOWN',
    'UPDATE_CLICK',
    'DISMISS'
);


ALTER TYPE public."AppUpdateEventType" OWNER TO postgres;

--
-- Name: AppealPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."AppealPriority" OWNER TO postgres;

--
-- Name: AppealStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'COMPLETED',
    'DECLINED',
    'RESOLVED'
);


ALTER TYPE public."AppealStatus" OWNER TO postgres;

--
-- Name: AttachmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AttachmentType" AS ENUM (
    'IMAGE',
    'AUDIO',
    'FILE'
);


ALTER TYPE public."AttachmentType" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'DRAFT',
    'QUEUED',
    'SENT_TO_1C',
    'CONFIRMED',
    'PARTIAL',
    'REJECTED',
    'CANCELLED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- Name: ProfileStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'BLOCKED'
);


ALTER TYPE public."ProfileStatus" OWNER TO postgres;

--
-- Name: ProfileType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileType" AS ENUM (
    'CLIENT',
    'SUPPLIER',
    'EMPLOYEE'
);


ALTER TYPE public."ProfileType" OWNER TO postgres;

--
-- Name: QRStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'DELETED'
);


ALTER TYPE public."QRStatus" OWNER TO postgres;

--
-- Name: QRType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRType" AS ENUM (
    'PHONE',
    'LINK',
    'EMAIL',
    'TEXT',
    'WHATSAPP',
    'CONTACT',
    'TELEGRAM'
);


ALTER TYPE public."QRType" OWNER TO postgres;

--
-- Name: RouteEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteEventType" AS ENUM (
    'MOVE',
    'STOP'
);


ALTER TYPE public."RouteEventType" OWNER TO postgres;

--
-- Name: RouteStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."RouteStatus" OWNER TO postgres;

--
-- Name: SyncDirection; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncDirection" AS ENUM (
    'IMPORT',
    'EXPORT'
);


ALTER TYPE public."SyncDirection" OWNER TO postgres;

--
-- Name: SyncEntityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncEntityType" AS ENUM (
    'NOMENCLATURE',
    'WAREHOUSES',
    'COUNTERPARTIES',
    'AGREEMENTS',
    'PRODUCT_PRICES',
    'SPECIAL_PRICES',
    'STOCK',
    'ORDERS_EXPORT',
    'ORDERS_STATUS'
);


ALTER TYPE public."SyncEntityType" OWNER TO postgres;

--
-- Name: SyncItemStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncItemStatus" AS ENUM (
    'OK',
    'ERROR',
    'SKIPPED'
);


ALTER TYPE public."SyncItemStatus" OWNER TO postgres;

--
-- Name: SyncStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncStatus" AS ENUM (
    'STARTED',
    'COMPLETED',
    'PARTIAL',
    'FAILED'
);


ALTER TYPE public."SyncStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    id integer NOT NULL,
    street text NOT NULL,
    city text NOT NULL,
    state text,
    "postalCode" text,
    country text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Address_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Address_id_seq" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Address_id_seq" OWNED BY public."Address".id;


--
-- Name: AppUpdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdate" (
    id integer NOT NULL,
    platform public."AppPlatform" NOT NULL,
    channel text DEFAULT 'prod'::text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text NOT NULL,
    "minSupportedVersionCode" integer NOT NULL,
    "isMandatory" boolean DEFAULT false NOT NULL,
    "rolloutPercent" integer DEFAULT 100 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "releaseNotes" text,
    "storeUrl" text,
    "apkKey" text,
    "fileSize" integer,
    checksum text,
    "checksumMd5" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AppUpdate" OWNER TO postgres;

--
-- Name: AppUpdateEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdateEvent" (
    id integer NOT NULL,
    "updateId" integer,
    platform public."AppPlatform" NOT NULL,
    channel text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text,
    "deviceId" text,
    "eventType" public."AppUpdateEventType" NOT NULL,
    "userId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppUpdateEvent" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdateEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNED BY public."AppUpdateEvent".id;


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdate_id_seq" OWNER TO postgres;

--
-- Name: AppUpdate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdate_id_seq" OWNED BY public."AppUpdate".id;


--
-- Name: Appeal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appeal" (
    id integer NOT NULL,
    number integer NOT NULL,
    "fromDepartmentId" integer,
    "toDepartmentId" integer NOT NULL,
    "createdById" integer NOT NULL,
    status public."AppealStatus" DEFAULT 'OPEN'::public."AppealStatus" NOT NULL,
    priority public."AppealPriority" DEFAULT 'MEDIUM'::public."AppealPriority" NOT NULL,
    deadline timestamp(3) without time zone,
    title text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Appeal" OWNER TO postgres;

--
-- Name: AppealAssignee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAssignee" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealAssignee" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAssignee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAssignee_id_seq" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAssignee_id_seq" OWNED BY public."AppealAssignee".id;


--
-- Name: AppealAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAttachment" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text NOT NULL,
    "fileType" public."AttachmentType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealAttachment" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAttachment_id_seq" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAttachment_id_seq" OWNED BY public."AppealAttachment".id;


--
-- Name: AppealMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessage" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "senderId" integer NOT NULL,
    text text,
    "editedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessage" OWNER TO postgres;

--
-- Name: AppealMessageRead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessageRead" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "userId" integer NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessageRead" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessageRead_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNED BY public."AppealMessageRead".id;


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessage_id_seq" OWNER TO postgres;

--
-- Name: AppealMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessage_id_seq" OWNED BY public."AppealMessage".id;


--
-- Name: AppealStatusHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealStatusHistory" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "oldStatus" public."AppealStatus" NOT NULL,
    "newStatus" public."AppealStatus" NOT NULL,
    "changedById" integer NOT NULL,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealStatusHistory" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealStatusHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNED BY public."AppealStatusHistory".id;


--
-- Name: AppealWatcher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealWatcher" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealWatcher" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealWatcher_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealWatcher_id_seq" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealWatcher_id_seq" OWNED BY public."AppealWatcher".id;


--
-- Name: Appeal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Appeal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Appeal_id_seq" OWNER TO postgres;

--
-- Name: Appeal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Appeal_id_seq" OWNED BY public."Appeal".id;


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id integer NOT NULL,
    "userId" integer,
    "targetType" text,
    "targetId" integer,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details text,
    action public."ActionType" NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: ClientAgreement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientAgreement" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "counterpartyId" text,
    "contractId" text,
    "priceTypeId" text,
    "warehouseId" text,
    currency text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientAgreement" OWNER TO postgres;

--
-- Name: ClientContract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientContract" (
    id text NOT NULL,
    guid text NOT NULL,
    "counterpartyId" text NOT NULL,
    number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "validFrom" timestamp(3) without time zone,
    "validTo" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientContract" OWNER TO postgres;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "activeAgreementId" text,
    "activeContractId" text,
    "activeDeliveryAddressId" text,
    "activePriceTypeId" text,
    "activeWarehouseId" text,
    "counterpartyId" text
);


ALTER TABLE public."ClientProfile" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ClientProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ClientProfile_id_seq" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ClientProfile_id_seq" OWNED BY public."ClientProfile".id;


--
-- Name: Counterparty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Counterparty" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "fullName" text,
    inn text,
    kpp text,
    phone text,
    email text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Counterparty" OWNER TO postgres;

--
-- Name: DeliveryAddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeliveryAddress" (
    id text NOT NULL,
    guid text,
    "counterpartyId" text NOT NULL,
    name text,
    "fullAddress" text NOT NULL,
    city text,
    street text,
    house text,
    building text,
    apartment text,
    postcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeliveryAddress" OWNER TO postgres;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: DepartmentRole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DepartmentRole" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "roleId" integer NOT NULL,
    "departmentId" integer NOT NULL
);


ALTER TABLE public."DepartmentRole" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DepartmentRole_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DepartmentRole_id_seq" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DepartmentRole_id_seq" OWNED BY public."DepartmentRole".id;


--
-- Name: Department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Department_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Department_id_seq" OWNER TO postgres;

--
-- Name: Department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Department_id_seq" OWNED BY public."Department".id;


--
-- Name: DeviceToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeviceToken" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    platform text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DeviceToken" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DeviceToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeviceToken_id_seq" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DeviceToken_id_seq" OWNED BY public."DeviceToken".id;


--
-- Name: EmailVerification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailVerification" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "attemptsCount" integer DEFAULT 0 NOT NULL,
    "lastSentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailVerification" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailVerification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailVerification_id_seq" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailVerification_id_seq" OWNED BY public."EmailVerification".id;


--
-- Name: EmployeeProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmployeeProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "departmentId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmployeeProfile" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmployeeProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNED BY public."EmployeeProfile".id;


--
-- Name: LoginAttempt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoginAttempt" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    success boolean NOT NULL,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginAttempt" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoginAttempt_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoginAttempt_id_seq" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoginAttempt_id_seq" OWNED BY public."LoginAttempt".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    guid text,
    number1c text,
    date1c timestamp(3) without time zone,
    "counterpartyId" text NOT NULL,
    "agreementId" text,
    "contractId" text,
    "warehouseId" text,
    "deliveryAddressId" text,
    status public."OrderStatus" DEFAULT 'DRAFT'::public."OrderStatus" NOT NULL,
    comment text,
    "deliveryDate" timestamp(3) without time zone,
    "totalAmount" numeric(18,2),
    currency text,
    "queuedAt" timestamp(3) without time zone,
    "sentTo1cAt" timestamp(3) without time zone,
    "lastStatusSyncAt" timestamp(3) without time zone,
    "exportAttempts" integer DEFAULT 0 NOT NULL,
    "lastExportError" text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "packageId" text,
    "unitId" text,
    quantity numeric(18,3) NOT NULL,
    "quantityBase" numeric(18,3),
    price numeric(18,4) NOT NULL,
    "discountPercent" numeric(5,2),
    "lineAmount" numeric(18,2),
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrderItem" OWNER TO postgres;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordReset_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordReset_id_seq" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordReset_id_seq" OWNED BY public."PasswordReset".id;


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Permission" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Permission" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Permission_id_seq" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Permission_id_seq" OWNED BY public."Permission".id;


--
-- Name: PriceType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PriceType" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PriceType" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    article text,
    sku text,
    "groupId" text,
    "isWeight" boolean DEFAULT false NOT NULL,
    "isService" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "baseUnitId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: ProductGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductGroup" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductGroup" OWNER TO postgres;

--
-- Name: ProductPackage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPackage" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "unitId" text NOT NULL,
    name text NOT NULL,
    multiplier numeric(18,4) NOT NULL,
    barcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPackage" OWNER TO postgres;

--
-- Name: ProductPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPrice" OWNER TO postgres;

--
-- Name: QRAnalytic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRAnalytic" (
    id integer NOT NULL,
    ip text,
    location text,
    browser text,
    device text,
    "scanDuration" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "qrListId" text NOT NULL
);


ALTER TABLE public."QRAnalytic" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."QRAnalytic_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QRAnalytic_id_seq" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."QRAnalytic_id_seq" OWNED BY public."QRAnalytic".id;


--
-- Name: QRList; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRList" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    status public."QRStatus" DEFAULT 'ACTIVE'::public."QRStatus" NOT NULL,
    "createdById" integer NOT NULL,
    "qrData" text NOT NULL,
    description text,
    "qrType" public."QRType" DEFAULT 'TEXT'::public."QRType" NOT NULL
);


ALTER TABLE public."QRList" OWNER TO postgres;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RefreshToken" (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RefreshToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RefreshToken_id_seq" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RefreshToken_id_seq" OWNED BY public."RefreshToken".id;


--
-- Name: Role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Role" (
    id integer NOT NULL,
    name text NOT NULL,
    "parentRoleId" integer
);


ALTER TABLE public."Role" OWNER TO postgres;

--
-- Name: RolePermissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RolePermissions" (
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public."RolePermissions" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Role_id_seq" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Role_id_seq" OWNED BY public."Role".id;


--
-- Name: RoutePoint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RoutePoint" (
    id integer NOT NULL,
    "routeId" integer NOT NULL,
    "userId" integer NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    "recordedAt" timestamp(3) without time zone NOT NULL,
    "eventType" public."RouteEventType" DEFAULT 'MOVE'::public."RouteEventType" NOT NULL,
    accuracy double precision,
    speed double precision,
    heading double precision,
    "stayDurationSeconds" integer,
    sequence integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RoutePoint" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RoutePoint_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RoutePoint_id_seq" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RoutePoint_id_seq" OWNED BY public."RoutePoint".id;


--
-- Name: SpecialPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SpecialPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "counterpartyId" text,
    "agreementId" text,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SpecialPrice" OWNER TO postgres;

--
-- Name: StockBalance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StockBalance" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "warehouseId" text NOT NULL,
    quantity numeric(18,3) NOT NULL,
    reserved numeric(18,3),
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone
);


ALTER TABLE public."StockBalance" OWNER TO postgres;

--
-- Name: SupplierProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SupplierProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SupplierProfile" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SupplierProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SupplierProfile_id_seq" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SupplierProfile_id_seq" OWNED BY public."SupplierProfile".id;


--
-- Name: SyncRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRun" (
    id text NOT NULL,
    "requestId" text NOT NULL,
    entity public."SyncEntityType" NOT NULL,
    direction public."SyncDirection" NOT NULL,
    status public."SyncStatus" DEFAULT 'STARTED'::public."SyncStatus" NOT NULL,
    "totalCount" integer DEFAULT 0 NOT NULL,
    "successCount" integer DEFAULT 0 NOT NULL,
    "errorCount" integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    notes text,
    meta jsonb
);


ALTER TABLE public."SyncRun" OWNER TO postgres;

--
-- Name: SyncRunItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRunItem" (
    id text NOT NULL,
    "runId" text NOT NULL,
    key text NOT NULL,
    status public."SyncItemStatus" NOT NULL,
    error text,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SyncRunItem" OWNER TO postgres;

--
-- Name: Unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Unit" (
    id text NOT NULL,
    guid text,
    name text NOT NULL,
    code text,
    symbol text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Unit" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "roleId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "deletedAt" timestamp(3) without time zone,
    phone text,
    "profileStatus" public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "currentProfileType" public."ProfileType",
    "firstName" text,
    "lastName" text,
    "middleName" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserRoute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserRoute" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    status public."RouteStatus" DEFAULT 'ACTIVE'::public."RouteStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserRoute" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserRoute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserRoute_id_seq" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserRoute_id_seq" OWNED BY public."UserRoute".id;


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warehouse" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isPickup" boolean DEFAULT false NOT NULL,
    address text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Warehouse" OWNER TO postgres;

--
-- Name: _EmployeeDepartmentRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_EmployeeDepartmentRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_EmployeeDepartmentRoles" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address" ALTER COLUMN id SET DEFAULT nextval('public."Address_id_seq"'::regclass);


--
-- Name: AppUpdate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdate_id_seq"'::regclass);


--
-- Name: AppUpdateEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdateEvent_id_seq"'::regclass);


--
-- Name: Appeal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal" ALTER COLUMN id SET DEFAULT nextval('public."Appeal_id_seq"'::regclass);


--
-- Name: AppealAssignee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee" ALTER COLUMN id SET DEFAULT nextval('public."AppealAssignee_id_seq"'::regclass);


--
-- Name: AppealAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment" ALTER COLUMN id SET DEFAULT nextval('public."AppealAttachment_id_seq"'::regclass);


--
-- Name: AppealMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessage_id_seq"'::regclass);


--
-- Name: AppealMessageRead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessageRead_id_seq"'::regclass);


--
-- Name: AppealStatusHistory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory" ALTER COLUMN id SET DEFAULT nextval('public."AppealStatusHistory_id_seq"'::regclass);


--
-- Name: AppealWatcher id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher" ALTER COLUMN id SET DEFAULT nextval('public."AppealWatcher_id_seq"'::regclass);


--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: ClientProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile" ALTER COLUMN id SET DEFAULT nextval('public."ClientProfile_id_seq"'::regclass);


--
-- Name: Department id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department" ALTER COLUMN id SET DEFAULT nextval('public."Department_id_seq"'::regclass);


--
-- Name: DepartmentRole id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole" ALTER COLUMN id SET DEFAULT nextval('public."DepartmentRole_id_seq"'::regclass);


--
-- Name: DeviceToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken" ALTER COLUMN id SET DEFAULT nextval('public."DeviceToken_id_seq"'::regclass);


--
-- Name: EmailVerification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification" ALTER COLUMN id SET DEFAULT nextval('public."EmailVerification_id_seq"'::regclass);


--
-- Name: EmployeeProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile" ALTER COLUMN id SET DEFAULT nextval('public."EmployeeProfile_id_seq"'::regclass);


--
-- Name: LoginAttempt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt" ALTER COLUMN id SET DEFAULT nextval('public."LoginAttempt_id_seq"'::regclass);


--
-- Name: PasswordReset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset" ALTER COLUMN id SET DEFAULT nextval('public."PasswordReset_id_seq"'::regclass);


--
-- Name: Permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission" ALTER COLUMN id SET DEFAULT nextval('public."Permission_id_seq"'::regclass);


--
-- Name: QRAnalytic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic" ALTER COLUMN id SET DEFAULT nextval('public."QRAnalytic_id_seq"'::regclass);


--
-- Name: RefreshToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken" ALTER COLUMN id SET DEFAULT nextval('public."RefreshToken_id_seq"'::regclass);


--
-- Name: Role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role" ALTER COLUMN id SET DEFAULT nextval('public."Role_id_seq"'::regclass);


--
-- Name: RoutePoint id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint" ALTER COLUMN id SET DEFAULT nextval('public."RoutePoint_id_seq"'::regclass);


--
-- Name: SupplierProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile" ALTER COLUMN id SET DEFAULT nextval('public."SupplierProfile_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserRoute id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute" ALTER COLUMN id SET DEFAULT nextval('public."UserRoute_id_seq"'::regclass);


--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (id, street, city, state, "postalCode", country, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdate" (id, platform, channel, "versionCode", "versionName", "minSupportedVersionCode", "isMandatory", "rolloutPercent", "isActive", "releaseNotes", "storeUrl", "apkKey", "fileSize", checksum, "checksumMd5", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdateEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdateEvent" (id, "updateId", platform, channel, "versionCode", "versionName", "deviceId", "eventType", "userId", "createdAt") FROM stdin;
1	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	\N	2026-01-27 11:52:55.569
2	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	\N	2026-01-27 11:52:55.653
3	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	UPDATE_CLICK	\N	2026-01-27 11:53:00.764
4	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	DISMISS	\N	2026-01-27 11:53:13.532
5	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	DISMISS	\N	2026-01-27 11:53:13.613
6	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-27 11:54:59.401
7	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	1	2026-01-27 11:54:59.503
8	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-27 11:54:59.505
9	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	UPDATE_CLICK	1	2026-01-27 11:55:04.322
10	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-29 07:32:53.056
11	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-29 07:32:53.181
12	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	1	2026-01-29 07:32:53.183
\.


--
-- Data for Name: Appeal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appeal" (id, number, "fromDepartmentId", "toDepartmentId", "createdById", status, priority, deadline, title, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppealAssignee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAssignee" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AppealAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAttachment" (id, "messageId", "fileUrl", "fileName", "fileType", "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessage" (id, "appealId", "senderId", text, "editedAt", deleted, "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessageRead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessageRead" (id, "messageId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: AppealStatusHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealStatusHistory" (id, "appealId", "oldStatus", "newStatus", "changedById", "changedAt") FROM stdin;
\.


--
-- Data for Name: AppealWatcher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealWatcher" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", "targetType", "targetId", "timestamp", details, action) FROM stdin;
1	1	USER	1	2026-01-27 10:35:19.853	Успешный вход в систему	LOGIN
2	1	USER	1	2026-01-27 11:00:54.637	Успешный вход в систему	LOGIN
3	1	USER	1	2026-01-27 11:04:19.225	Успешный вход в систему	LOGIN
4	1	USER	1	2026-01-27 11:05:09.942	Успешный вход в систему	LOGIN
5	1	USER	1	2026-01-29 07:30:49.607	Успешный вход в систему	LOGIN
6	1	USER	1	2026-01-29 08:56:38.956	Успешный вход в систему	LOGIN
7	1	USER	1	2026-01-31 07:50:30.272	Успешный вход в систему	LOGIN
\.


--
-- Data for Name: ClientAgreement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientAgreement" (id, guid, name, "counterpartyId", "contractId", "priceTypeId", "warehouseId", currency, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientContract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientContract" (id, guid, "counterpartyId", number, date, "validFrom", "validTo", "isActive", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientProfile" (id, "userId", "addressId", phone, status, "createdAt", "updatedAt", "activeAgreementId", "activeContractId", "activeDeliveryAddressId", "activePriceTypeId", "activeWarehouseId", "counterpartyId") FROM stdin;
\.


--
-- Data for Name: Counterparty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Counterparty" (id, guid, name, "fullName", inn, kpp, phone, email, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DeliveryAddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeliveryAddress" (id, guid, "counterpartyId", name, "fullAddress", city, street, house, building, apartment, postcode, "isDefault", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" (id, name) FROM stdin;
1	IT Отдел
2	Бухгалтерия
3	Маркетинг
4	Менеджеры
\.


--
-- Data for Name: DepartmentRole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DepartmentRole" (id, "userId", "roleId", "departmentId") FROM stdin;
\.


--
-- Data for Name: DeviceToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeviceToken" (id, "userId", token, platform, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailVerification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailVerification" (id, "userId", code, "expiresAt", used, "attemptsCount", "lastSentAt", "createdAt") FROM stdin;
1	1	746216	2026-01-27 11:13:43.637	t	0	2026-01-27 10:13:43.637	2026-01-27 10:13:43.64
\.


--
-- Data for Name: EmployeeProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmployeeProfile" (id, "userId", "departmentId", phone, status, "createdAt", "updatedAt") FROM stdin;
1	1	1	+7 (961) 223-13-45	PENDING	2026-01-27 10:56:02.762	2026-01-27 10:56:02.762
\.


--
-- Data for Name: LoginAttempt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoginAttempt" (id, "userId", success, ip, "createdAt") FROM stdin;
1	1	t	::ffff:172.20.0.1	2026-01-27 10:35:19.85
2	1	t	::ffff:172.20.0.1	2026-01-27 11:00:54.634
3	1	t	::ffff:172.20.0.1	2026-01-27 11:04:19.222
4	1	t	::ffff:172.20.0.1	2026-01-27 11:05:09.94
5	1	t	::ffff:172.20.0.1	2026-01-29 07:30:49.603
6	1	t	::ffff:172.20.0.1	2026-01-29 08:56:38.954
7	1	t	::ffff:172.20.0.1	2026-01-31 07:50:30.269
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, guid, number1c, date1c, "counterpartyId", "agreementId", "contractId", "warehouseId", "deliveryAddressId", status, comment, "deliveryDate", "totalAmount", currency, "queuedAt", "sentTo1cAt", "lastStatusSyncAt", "exportAttempts", "lastExportError", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderItem" (id, "orderId", "productId", "packageId", "unitId", quantity, "quantityBase", price, "discountPercent", "lineAmount", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordReset" (id, "userId", code, "expiresAt", used, "createdAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Permission" (id, name) FROM stdin;
1	view_profile
2	update_profile
3	logout
4	manage_roles
5	manage_permissions
6	assign_roles
7	assign_permissions
8	manage_departments
9	manage_users
10	view_fin_reports
11	approve_payments
12	manage_payroll
13	view_shipments
14	manage_shipments
15	manage_inventory
16	create_appeal
17	view_appeal
18	assign_appeal
19	update_appeal_status
20	add_appeal_message
21	edit_appeal_message
22	delete_appeal_message
23	manage_appeal_watchers
24	export_appeals
25	manage_updates
\.


--
-- Data for Name: PriceType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PriceType" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, guid, name, code, article, sku, "groupId", "isWeight", "isService", "isActive", "sourceUpdatedAt", "lastSyncedAt", "baseUnitId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductGroup" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPackage" (id, guid, "productId", "unitId", name, multiplier, barcode, "isDefault", "sortOrder", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPrice" (id, guid, "productId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: QRAnalytic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRAnalytic" (id, ip, location, browser, device, "scanDuration", "createdAt", "qrListId") FROM stdin;
\.


--
-- Data for Name: QRList; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRList" (id, "createdAt", "updatedAt", status, "createdById", "qrData", description, "qrType") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt", revoked) FROM stdin;
1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijg0OGYyNDhiLWUyMjMtNDdkZC1hOTQyLTgyMTNjZjY0YTY4ZCIsImlhdCI6MTc2OTUxMDExOSwiZXhwIjoxNzcyMTAyMTE5fQ.6x2KCqtCbSfq6X4WmqnmJr5bwgT430itvPgse7Xe9PA	1	2026-02-26 10:35:19.844	2026-01-27 10:35:19.845	f
2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjNmY2YwZWNkLTZmYjAtNDEzMi1hOTFjLTc4MWY2NjVmYWRiMSIsImlhdCI6MTc2OTUxMTY1NCwiZXhwIjoxNzcyMTAzNjU0fQ.kQsj529-DRXCTYucDx5DHckWM-Fpow4wKbprNAynSug	1	2026-02-26 11:00:54.629	2026-01-27 11:00:54.629	f
3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImJiZGQwZWJlLTc0ZTAtNDhjZi05Y2MxLTYyMjg5NGMyOGFkNyIsImlhdCI6MTc2OTUxMTg1OSwiZXhwIjoxNzcyMTAzODU5fQ.vLw1b1toM3_7Qhjzzw6k_yywKSBL9dG-ZkWU6JjmKu0	1	2026-02-26 11:04:19.216	2026-01-27 11:04:19.217	t
4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjY2MzM1OGYxLWUxYWEtNGI1YS1hYTUzLTczNzllZmZjMTBlYiIsImlhdCI6MTc2OTUxMTkwOSwiZXhwIjoxNzcyMTAzOTA5fQ.W4fzSPkUispAvAimT4nsGxP1f6Dg_I7TAQemcxKoZ-g	1	2026-02-26 11:05:09.936	2026-01-27 11:05:09.937	t
5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImFjMWRhNDVjLWUyMGMtNGE4Zi05ZTUwLWNkZDNmNTM5YmRmYSIsImlhdCI6MTc2OTUxMzk0NywiZXhwIjoxNzcyMTA1OTQ3fQ.0XajzuBKrYW3y463QxWu1lynBzDi9RMihpVTOwem8rU	1	2026-02-26 11:39:07.337	2026-01-27 11:39:07.343	t
7	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjkxMWNmNzliLTQ5MWMtNGViOS04Njc1LTFiY2FmMTc1YTBjYSIsImlhdCI6MTc2OTUxNTg5MCwiZXhwIjoxNzcyMTA3ODkwfQ.mFYjNSQFlKwDXehc1URkAY8CAEvzzIWAXwqbTlA-yFQ	1	2026-02-26 12:11:30.961	2026-01-27 12:11:30.965	t
8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjJkOThjMzE3LTY0YTEtNGY5Zi1hYWE4LWY1ODFlZGUyOWRhNyIsImlhdCI6MTc2OTUyMzEyNywiZXhwIjoxNzcyMTE1MTI3fQ.lE-p3wjxMC2JrhVx1pEQz8D9cwGb6UQguh8OhrlNKxI	1	2026-02-26 14:12:07.001	2026-01-27 14:12:07.006	t
9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijc3NjUzMjJjLTkzNjMtNGU3Yy05OWQ5LTc2YjkyOWI1ZDU0NyIsImlhdCI6MTc2OTUzNTE3MSwiZXhwIjoxNzcyMTI3MTcxfQ.ScbAiaTl9_FgcJrd4jWB4ZoEptuUWiaZMQiAXx4QJm0	1	2026-02-26 17:32:51.523	2026-01-27 17:32:51.528	f
6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjUzMjJhMTA4LWM1MmUtNDJmMy05M2Q1LWZhZjhlYWYzZGJjYiIsImlhdCI6MTc2OTUxNDg5MywiZXhwIjoxNzcyMTA2ODkzfQ.nzxA9dbpGvxChM62rjGsZgauthTAQoNDzzjicrRawrQ	1	2026-02-26 11:54:53.282	2026-01-27 11:54:53.283	t
10	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjMzOGExMzBmLTU0NGYtNGRjZi04ODljLTA5ODdkZjJkNzMyNCIsImlhdCI6MTc2OTY3MTg0OSwiZXhwIjoxNzcyMjYzODQ5fQ.j6eGvAErCnHStinnZrx1IX90V3Tt2cTOGqOVlxLHDSc	1	2026-02-28 07:30:49.592	2026-01-29 07:30:49.596	t
11	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijk5MDRlNDQ5LWUxNTAtNGM4Mi1hMWFlLWI2ZjA1ZjM2NzNlNSIsImlhdCI6MTc2OTY3MTk3MiwiZXhwIjoxNzcyMjYzOTcyfQ.bE7uu_mKhafW9lH7AaS3xXPrfVObH-ex3bsblF6p7hw	1	2026-02-28 07:32:52.549	2026-01-29 07:32:52.549	t
12	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjUyMmM3YzZlLTk2YWEtNGQwMC05MzlhLTcyN2UzMzg4ZjZiNSIsImlhdCI6MTc2OTY3NDcyNCwiZXhwIjoxNzcyMjY2NzI0fQ.6Ruruaap8XR6pKf9qVAT_p3KBTIc4xzgFYosa4y6rZo	1	2026-02-28 08:18:44.042	2026-01-29 08:18:44.043	t
14	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjFjZGRmMGIzLTEzOTYtNDhiZS04MzMxLTc0NWI1MjQyZjUzNSIsImlhdCI6MTc2OTY3Njk2NCwiZXhwIjoxNzcyMjY4OTY0fQ.L2X6xuiA2cEggvhfo2XCaFa9ZnzuMV0lIzlxZmKSwr0	1	2026-02-28 08:56:04.02	2026-01-29 08:56:04.021	f
15	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjcxY2NmMDk5LWZhYmMtNGViMy1iM2YxLTY0ZTE4ZTQ1NjUyYiIsImlhdCI6MTc2OTY3Njk5OCwiZXhwIjoxNzcyMjY4OTk4fQ.wB2LBMvX-UemdbQj8UrbJQynZK5T-nNtslRRidbuJ3w	1	2026-02-28 08:56:38.949	2026-01-29 08:56:38.95	f
16	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjNlM2Q4YzM4LWFlNDAtNDEzYy1hOTEwLWY1OWZiNWU3OTMxNCIsImlhdCI6MTc2OTg0NTgzMCwiZXhwIjoxNzcyNDM3ODMwfQ.erV_iOi30RpU3veuDp273_wQkRoOg6Qsx2HwTeWU3Xc	1	2026-03-02 07:50:30.261	2026-01-31 07:50:30.266	f
13	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImY1NjI0MDE5LThiZjItNDhlYS1hMWFjLTdmZjY1ZjE0N2JmNiIsImlhdCI6MTc2OTY3NjY0NCwiZXhwIjoxNzcyMjY4NjQ0fQ.bbOGMA7UpY1XScxTk_e0E0z4A3C9WHI6wt6np05eTHA	1	2026-02-28 08:50:44.407	2026-01-29 08:50:44.408	t
17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjJiMGZmYzc2LTgyMWEtNDIyOC05N2EzLTIxZDI3YWViNzE2OSIsImlhdCI6MTc2OTg4NDI0MywiZXhwIjoxNzcyNDc2MjQzfQ.jKitCDhCPOSIaTd1n0iGapcTp5YcBz23n8Hx3gmBMdo	1	2026-03-02 18:30:43.973	2026-01-31 18:30:43.973	t
18	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImIzM2Y1OWY1LThlMzctNDQyNC1hODVjLTgwZTJjOGFkYTZlYSIsImlhdCI6MTc2OTg4NjQ1OCwiZXhwIjoxNzcyNDc4NDU4fQ.yDU6obdsHzyowvlIqwu05LCNz0qrniUN1z9pblhrUR4	1	2026-03-02 19:07:38.257	2026-01-31 19:07:38.257	t
19	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImVhOWY4NzY1LTUzNDUtNGFkNy05ZWM1LWY3MDU3MzAwOTM0MyIsImlhdCI6MTc2OTg4ODk1NCwiZXhwIjoxNzcyNDgwOTU0fQ.XqoXUuXgp9Dl68ol363xZnLAREGYaB8Ghg9lAqtYvDY	1	2026-03-02 19:49:14.09	2026-01-31 19:49:14.09	t
20	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjM0MWRjODcwLWIzNjMtNDcyMy04NThhLTM1Y2YzMzY5MzNjZSIsImlhdCI6MTc2OTg5MjU2MiwiZXhwIjoxNzcyNDg0NTYyfQ.zlAA5xd-519mJgO5sPsUoboWJjJj2X-ifUWP8LJaIvo	1	2026-03-02 20:49:22.341	2026-01-31 20:49:22.341	t
21	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImMwNTZmM2I1LTM4YTctNDU3OC1hOWQzLTEwMDdiM2E1YWJmZiIsImlhdCI6MTc2OTg5OTgwOSwiZXhwIjoxNzcyNDkxODA5fQ.K9bn51oiBCRxwgVDtQRLxSTPqIbdDmaVk3rJKJzizUQ	1	2026-03-02 22:50:09.319	2026-01-31 22:50:09.32	t
22	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjU3ZGU0MzBlLWI3OTktNDYwNy1hZjE4LTFiYzQ2ZDQ2OTE4ZiIsImlhdCI6MTc2OTkxMDU4MCwiZXhwIjoxNzcyNTAyNTgwfQ.SGusoob0jWKzP3LI8j4XZrycqE0StyoakTPhlC83aoI	1	2026-03-03 01:49:40.322	2026-02-01 01:49:40.323	t
23	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImExM2U0MTAwLThmYmUtNDFhZi04MmI0LWFjNWM4OTIwZTdlNSIsImlhdCI6MTc2OTkxMzA2MCwiZXhwIjoxNzcyNTA1MDYwfQ.4cN58-C5vS9byyvhvaNEVC8jgILpEOhSRX5XUxLHQNg	1	2026-03-03 02:31:00.215	2026-02-01 02:31:00.215	t
24	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjZkNGVlMTMyLTNkNjItNGE3YS1iY2E3LWY4ODY4YzI0YTNlYSIsImlhdCI6MTc2OTkxNTQ1MywiZXhwIjoxNzcyNTA3NDUzfQ.ESBp41iRDykMJRlew-DMbja2nfuwpngJhxxwTTFbUNU	1	2026-03-03 03:10:53.683	2026-02-01 03:10:53.684	t
25	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImY0MjY1YzM5LWM3ZDItNDcxOC04YmFhLWI5ODBmNDhmNjE0MSIsImlhdCI6MTc2OTkxNzc5MSwiZXhwIjoxNzcyNTA5NzkxfQ.yXQaFSwlSvbG6466VfPYLuqxzSgOM7dFuo0dFxq1Sbk	1	2026-03-03 03:49:51.628	2026-02-01 03:49:51.629	t
26	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijc5NzA0MjMxLTM2ZjEtNGJjMC05M2QwLTRmNWE3OTc5YjMzOCIsImlhdCI6MTc2OTkxOTYwMCwiZXhwIjoxNzcyNTExNjAwfQ.tRPmKBbq1Q2tjnlWpvJy_aXLNnPFuN9IwnC0dRPu9Pw	1	2026-03-03 04:20:00.52	2026-02-01 04:20:00.52	t
27	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImFjZjcwYzA3LWM5MWQtNDBkNS05MDA2LTlmMmZjNTlhMzU2ZiIsImlhdCI6MTc2OTkyMTQwMCwiZXhwIjoxNzcyNTEzNDAwfQ.Y_M2_4F9pkH_wGaVip-P6DbzhGoNk99aG0DFrl5L830	1	2026-03-03 04:50:00.306	2026-02-01 04:50:00.306	t
28	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjAxMDg4ZDU3LWYwZGItNGIxMy1iMzA2LTRhNmRhOTZiNmVlMyIsImlhdCI6MTc2OTkyMzIwNCwiZXhwIjoxNzcyNTE1MjA0fQ.kYM0XBcp55ZklVUPEeO03wRXiBoghtLzfEdEi863qXo	1	2026-03-03 05:20:04.84	2026-02-01 05:20:04.84	t
29	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjkyODA3YzZiLTFiMWUtNDQ4Mi1iY2Q0LTRmNjgwOTRmZDk1ZCIsImlhdCI6MTc2OTkyNTA2MywiZXhwIjoxNzcyNTE3MDYzfQ.X-qXEYZGCohwxq5ksEjOK1UFxfD0t45OU2ambaFXAb4	1	2026-03-03 05:51:03.769	2026-02-01 05:51:03.769	t
30	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImYzOTExY2QzLTcxZmItNGUyNC1hZjY1LTg5MDEzNGVlZjBkYyIsImlhdCI6MTc2OTkyNjkzMywiZXhwIjoxNzcyNTE4OTMzfQ.rq4Wv-JVY9dnn2DDIVAHXmitw62STD7TwMm1o8FRpLM	1	2026-03-03 06:22:13.816	2026-02-01 06:22:13.816	t
31	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjU3MmUzMDc2LTYxMjYtNGMyOS05NThhLWQ3OTE2MGQ3NTYxOSIsImlhdCI6MTc2OTkyOTMyMywiZXhwIjoxNzcyNTIxMzIzfQ.nrsc30pizMj6ttKwicD-0-oeS7Jt_B1FdKgWE3OFWzs	1	2026-03-03 07:02:03.284	2026-02-01 07:02:03.284	t
32	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjI3OGRjMDA2LWQ4ODgtNDQ0Ni1iZmNhLTI3MGM5MzMzYjQwZSIsImlhdCI6MTc2OTkzMTI3MywiZXhwIjoxNzcyNTIzMjczfQ.qEMJapciTTaTRKPXz7rlM_80Yl-L5eBc41mhTm5PsYM	1	2026-03-03 07:34:33.165	2026-02-01 07:34:33.165	f
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Role" (id, name, "parentRoleId") FROM stdin;
1	user	\N
2	employee	1
3	department_manager	2
4	admin	3
\.


--
-- Data for Name: RolePermissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RolePermissions" ("roleId", "permissionId") FROM stdin;
1	1
1	2
1	3
2	16
2	17
2	20
2	21
2	22
2	23
3	18
3	19
3	24
4	1
4	2
4	3
4	4
4	5
4	6
4	7
4	8
4	9
4	10
4	11
4	12
4	13
4	14
4	15
4	16
4	17
4	18
4	19
4	20
4	21
4	22
4	23
4	24
4	25
\.


--
-- Data for Name: RoutePoint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RoutePoint" (id, "routeId", "userId", latitude, longitude, "recordedAt", "eventType", accuracy, speed, heading, "stayDurationSeconds", sequence, "createdAt") FROM stdin;
1	1	1	55.1067804	82.952315	2026-01-31 18:30:18.777	MOVE	32.34199905395508	0	0	\N	1	2026-01-31 18:32:14.917
2	1	1	55.1068347	82.9525492	2026-01-31 18:33:39.323	MOVE	49.5	5.559999942779541	275	\N	2	2026-01-31 18:33:40.737
3	1	1	55.1068094	82.9521735	2026-01-31 18:33:57.304	MOVE	21.27300071716309	2.345026969909668	289.0368957519531	\N	3	2026-01-31 18:34:01.541
4	1	1	55.1067822	82.952432	2026-01-31 18:34:14.548	MOVE	32.0099983215332	1.624506711959839	103.758674621582	\N	4	2026-01-31 18:34:17.411
5	1	1	55.1067813	82.9522236	2026-01-31 18:34:28.291	MOVE	45.5	0.7097352147102356	253.0186157226562	\N	5	2026-01-31 18:34:30.638
6	1	1	55.1068677	82.9519751	2026-01-31 18:34:48.592	MOVE	40.31000137329102	0	0	\N	6	2026-01-31 18:34:57.266
7	1	1	55.10686	82.952056	2026-01-31 18:35:05.499	MOVE	18.97500038146973	0.009505301713943481	0	\N	7	2026-01-31 18:35:08.337
8	1	1	55.1067665	82.9522499	2026-01-31 18:35:22.396	MOVE	21.86199951171875	0	0	\N	8	2026-01-31 18:35:25.376
9	1	1	55.1068038	82.9522039	2026-01-31 18:37:03.842	MOVE	24.69700050354004	0	0	\N	9	2026-01-31 18:37:06.843
10	1	1	55.1067804	82.9522821	2026-01-31 18:37:37.786	MOVE	31.48100090026855	0	0	\N	10	2026-01-31 18:37:40.848
11	1	1	55.1067579	82.9521811	2026-01-31 18:40:26.991	MOVE	22.48200035095215	2.547088146209717	245.0231475830078	\N	11	2026-01-31 18:40:29.956
12	1	1	55.1067711	82.9522644	2026-01-31 18:41:00.847	MOVE	20.1830005645752	0	0	\N	12	2026-01-31 18:41:03.853
13	1	1	55.1070828	82.9518576	2026-01-31 18:41:15.265	MOVE	134	2.492164134979248	313.2636108398438	\N	13	2026-01-31 18:41:18.196
14	1	1	55.1067832	82.9522366	2026-01-31 18:41:17.753	MOVE	23.7140007019043	2.466213941574097	312.9832153320312	\N	14	2026-01-31 18:41:35.655
15	1	1	55.1068135	82.9523214	2026-01-31 18:42:23.266	MOVE	49	2.871767520904541	273.0154418945312	\N	15	2026-01-31 18:42:26.172
16	1	1	55.106857	82.9521305	2026-01-31 18:42:27.292	MOVE	35.73099899291992	5.332225799560547	287.1360778808594	\N	16	2026-01-31 18:42:45.207
17	1	1	55.1067747	82.9523117	2026-01-31 18:42:42.352	MOVE	31.15800094604492	0	0	\N	17	2026-01-31 18:43:00.233
18	1	1	55.1069044	82.9521234	2026-01-31 18:42:57.287	MOVE	37.5	6.63052225112915	267.9819946289062	\N	18	2026-01-31 18:43:00.233
19	1	1	55.1069014	82.9519467	2026-01-31 18:42:59.253	MOVE	46.94300079345703	6.577614784240723	267.9765014648438	\N	19	2026-01-31 18:43:17.171
20	1	1	55.1067983	82.9522813	2026-01-31 18:43:16.16	MOVE	30.77899932861328	0	0	\N	20	2026-01-31 18:43:19.072
21	1	1	55.1069991	82.9519669	2026-01-31 18:43:33.083	MOVE	145.3849945068359	0.9503021240234375	292.0162963867188	\N	21	2026-01-31 18:43:36.058
22	1	1	55.1068004	82.9522785	2026-01-31 18:43:50.043	MOVE	31.30299949645996	0	0	\N	22	2026-01-31 18:43:53.025
23	1	1	55.1072316	82.9504367	2026-01-31 18:44:07.008	MOVE	171.1499938964844	12.17535305023193	286.3936157226562	\N	23	2026-01-31 18:44:09.995
24	1	1	55.1067736	82.9523021	2026-01-31 18:44:23.916	MOVE	23.9419994354248	0	0	\N	24	2026-01-31 18:44:26.874
25	1	1	55.1067438	82.9521105	2026-01-31 18:44:40.886	MOVE	30.88100051879883	8.220898628234863	268.7593383789062	\N	25	2026-01-31 18:44:43.883
26	1	1	55.1067805	82.9522556	2026-01-31 18:44:57.78	MOVE	23.43600082397461	1.006226658821106	258.369140625	\N	26	2026-01-31 18:45:00.759
27	1	1	55.106957	82.9515958	2026-01-31 18:45:12.266	MOVE	29.5	1.0501788854599	327.1939086914062	\N	27	2026-01-31 18:45:15.151
28	1	1	55.1067706	82.9522484	2026-01-31 18:45:31.584	MOVE	23.05299949645996	0	0	\N	28	2026-01-31 18:45:34.537
29	1	1	55.1067131	82.9528056	2026-01-31 18:45:46.267	MOVE	55	19.99742126464844	133.92529296875	\N	29	2026-01-31 18:45:49.168
30	1	1	55.1065	82.9532138	2026-01-31 18:45:48.501	MOVE	78.27300262451172	19.42607688903809	133.7977142333984	\N	30	2026-01-31 18:46:06.396
31	1	1	55.1067689	82.9522685	2026-01-31 18:46:05.416	MOVE	22.3799991607666	0	0	\N	31	2026-01-31 18:46:08.356
32	1	1	55.1068231	82.9523067	2026-01-31 18:46:22.316	MOVE	192.2740020751953	1.595034003257751	95.0837631225586	\N	32	2026-01-31 18:46:25.265
33	1	1	55.1067775	82.9522512	2026-01-31 18:46:56.107	MOVE	21.11199951171875	0.6079869866371155	319.3273315429688	\N	33	2026-01-31 18:46:59.069
34	1	1	55.1066716	82.9538616	2026-01-31 18:48:23.289	MOVE	165.5	0	0	\N	34	2026-01-31 18:48:26.36
35	1	1	55.1067802	82.9523926	2026-01-31 18:48:40.902	MOVE	32.625	0.4307666420936584	307.3108215332031	\N	35	2026-01-31 18:48:44.07
36	1	1	55.1067886	82.9522454	2026-01-31 18:48:57.897	MOVE	19.4109992980957	0	0	\N	36	2026-01-31 18:49:01.031
37	1	1	55.1067864	82.9521496	2026-01-31 18:49:31.267	MOVE	73	5.900000095367432	117	\N	37	2026-01-31 18:55:24.728
38	1	1	55.1067612	82.9523147	2026-01-31 18:50:15.517	MOVE	19.95999908447266	4.201371669769287	115.1215209960938	\N	38	2026-01-31 18:55:24.728
39	1	1	55.106787	82.9528762	2026-01-31 18:50:31.314	MOVE	92	3.519999980926514	94	\N	39	2026-01-31 18:55:24.728
40	1	1	55.1067746	82.9522073	2026-01-31 18:50:49.653	MOVE	26.36300086975098	0	0	\N	40	2026-01-31 18:55:24.728
41	1	1	55.10704	82.9517681	2026-01-31 18:51:31.34	MOVE	78.5	5.400000095367432	294	\N	41	2026-01-31 18:55:24.728
42	1	1	55.1067577	82.9522462	2026-01-31 18:51:49.245	MOVE	24.69000053405762	0	0	\N	42	2026-01-31 18:55:24.728
43	1	1	55.1067632	82.9526776	2026-01-31 18:52:01.322	MOVE	84.5	2.355393886566162	117.9621276855469	\N	43	2026-01-31 18:55:24.728
44	1	1	55.1067641	82.9522221	2026-01-31 18:52:16.385	MOVE	33.37699890136719	0	0	\N	44	2026-01-31 18:55:24.728
45	1	1	55.1067792	82.9525959	2026-01-31 18:52:31.307	MOVE	112.5	0.9802989363670349	49.20003128051758	\N	45	2026-01-31 18:55:24.728
46	1	1	55.106769	82.9522102	2026-01-31 18:52:51.414	MOVE	27.85099983215332	0	0	\N	46	2026-01-31 18:55:24.728
47	1	1	55.1068605	82.9522504	2026-01-31 18:54:01.267	MOVE	80.5	5.072478771209717	107.24853515625	\N	47	2026-01-31 18:55:24.728
48	1	1	55.1067637	82.9522614	2026-01-31 18:54:15.231	MOVE	21.68400001525879	2.583331108093262	122.0659713745117	\N	48	2026-01-31 18:55:24.728
49	1	1	55.106967	82.9520405	2026-01-31 18:54:31.292	MOVE	159	1.819999933242798	301	\N	49	2026-01-31 18:55:24.728
50	1	1	55.1067614	82.9522276	2026-01-31 18:54:49.309	MOVE	26.60199928283691	0	0	\N	50	2026-01-31 18:55:24.728
51	1	1	55.1068024	82.952323	2026-01-31 18:55:15.312	MOVE	35.16299819946289	2.62878680229187	104.2093276977539	\N	51	2026-01-31 18:55:24.728
52	1	1	55.1069029	82.9524417	2026-01-31 18:55:31.287	MOVE	113	0.5299999713897705	131	\N	52	2026-01-31 19:07:38.582
53	1	1	55.1067723	82.9522504	2026-01-31 18:55:49.432	MOVE	27.07200050354004	0	0	\N	53	2026-01-31 19:07:38.582
54	1	1	55.1069553	82.952046	2026-01-31 18:56:31.262	MOVE	70	3.199999809265137	304	\N	54	2026-01-31 19:07:38.582
55	1	1	55.1067646	82.9521823	2026-01-31 18:56:50.225	MOVE	37.58100128173828	0	0	\N	55	2026-01-31 19:07:38.582
56	1	1	55.1067648	82.9525475	2026-01-31 18:57:01.299	MOVE	90.5	0.9408352375030518	304.2814636230469	\N	56	2026-01-31 19:07:38.582
57	1	1	55.1067616	82.9522316	2026-01-31 18:57:16.482	MOVE	35.87400054931641	0	0	\N	57	2026-01-31 19:07:38.582
58	1	1	55.1068563	82.9524348	2026-01-31 18:57:31.303	MOVE	80.5	0.3029271364212036	91.89619445800781	\N	58	2026-01-31 19:07:38.582
59	1	1	55.1067766	82.9522551	2026-01-31 18:57:45.368	MOVE	36.29000091552734	0.0931115448474884	0	\N	59	2026-01-31 19:07:38.582
60	1	1	55.1069183	82.9521763	2026-01-31 18:58:01.29	MOVE	73.5	1.169999957084656	295	\N	60	2026-01-31 19:07:38.582
61	1	1	55.1067682	82.9522256	2026-01-31 18:58:19.416	MOVE	36.80099868774414	0	0	\N	61	2026-01-31 19:07:38.582
62	1	1	55.1069319	82.9522304	2026-01-31 18:59:01.286	MOVE	66	1.799999952316284	285	\N	62	2026-01-31 19:07:38.582
63	1	1	55.106766	82.9522187	2026-01-31 18:59:19.884	MOVE	36.29000091552734	0	0	\N	63	2026-01-31 19:07:38.582
64	1	1	55.1067722	82.9523005	2026-01-31 18:59:45.746	MOVE	17.16500091552734	0.4143889546394348	148.2273712158203	\N	64	2026-01-31 19:07:38.582
65	1	1	55.1069731	82.9522918	2026-01-31 19:00:01.299	MOVE	136	2.609999895095825	105	\N	65	2026-01-31 19:07:38.582
66	1	1	55.1067351	82.9522089	2026-01-31 19:00:19.811	MOVE	45.75899887084961	0	0	\N	66	2026-01-31 19:07:38.582
67	1	1	55.1067801	82.9522266	2026-01-31 19:00:46.175	MOVE	27.1560001373291	0.5965769290924072	293.7528991699219	\N	67	2026-01-31 19:07:38.582
68	1	1	55.1068402	82.9524624	2026-01-31 19:01:01.265	MOVE	103.5	0.2800000011920929	94	\N	68	2026-01-31 19:07:38.582
69	1	1	55.106766	82.9522228	2026-01-31 19:01:20.226	MOVE	35.54499816894531	0	0	\N	69	2026-01-31 19:07:38.582
70	1	1	55.1067704	82.9526974	2026-01-31 19:02:01.289	MOVE	106	1.120000004768372	97	\N	70	2026-01-31 19:07:38.582
71	1	1	55.1067727	82.9522161	2026-01-31 19:02:19.402	MOVE	37.63100051879883	0	0	\N	71	2026-01-31 19:07:38.582
72	1	1	55.1068385	82.9524306	2026-01-31 19:05:01.282	MOVE	133.5	1.669999957084656	112	\N	72	2026-01-31 19:07:38.582
73	1	1	55.1067833	82.9522268	2026-01-31 19:05:20.434	MOVE	23.46699905395508	0	0	\N	73	2026-01-31 19:07:38.582
74	1	1	55.1067957	82.9526507	2026-01-31 19:06:01.267	MOVE	169	1.049999952316284	305	\N	74	2026-01-31 19:07:38.582
75	1	1	55.1067941	82.9522395	2026-01-31 19:06:19.35	MOVE	31.28800010681152	0	0	\N	75	2026-01-31 19:07:38.582
76	1	1	55.1068934	82.9526857	2026-01-31 19:07:01.304	MOVE	52.5	0.8299999833106995	73	\N	76	2026-01-31 19:07:38.582
77	1	1	55.1067954	82.952242	2026-01-31 19:07:19.374	MOVE	36.45800018310547	0	0	\N	77	2026-01-31 19:07:38.582
78	1	1	55.1068316	82.9523313	2026-01-31 19:07:36.449	MOVE	192.4490051269531	1.126964449882507	299.3040771484375	\N	78	2026-01-31 19:07:39.449
79	1	1	55.1067907	82.9522664	2026-01-31 19:07:53.448	MOVE	33.75899887084961	0	0	\N	79	2026-01-31 19:07:56.568
80	1	1	55.1067982	82.9524169	2026-01-31 19:08:31.276	MOVE	39.17699813842773	0.6857903599739075	270.0035095214844	\N	80	2026-01-31 19:08:49.224
81	1	1	55.1067963	82.9522293	2026-01-31 19:08:46.188	MOVE	37.36600112915039	0.7352138757705688	269.9897155761719	\N	81	2026-01-31 19:09:04.339
82	1	1	55.1068895	82.9527033	2026-01-31 19:09:01.251	MOVE	70.5	3.629999876022339	298	\N	82	2026-01-31 19:09:04.339
83	1	1	55.1067853	82.9522052	2026-01-31 19:09:20.224	MOVE	36.70999908447266	0	0	\N	83	2026-01-31 19:09:23.304
84	1	1	55.1067926	82.9522944	2026-01-31 19:09:44.932	MOVE	32.74700164794922	0.3890503942966461	108.4889831542969	\N	84	2026-01-31 19:49:14.345
85	1	1	55.1069371	82.951809	2026-01-31 19:10:01.274	MOVE	88	0.7999999523162842	131	\N	85	2026-01-31 19:49:14.345
86	1	1	55.1067764	82.952235	2026-01-31 19:10:19.019	MOVE	23.12400054931641	0	0	\N	86	2026-01-31 19:49:14.345
87	1	1	55.1069674	82.9521176	2026-01-31 19:10:36.08	MOVE	186.2940063476562	1.133079051971436	280.1195373535156	\N	87	2026-01-31 19:49:14.345
88	1	1	55.1067757	82.9522424	2026-01-31 19:10:53.039	MOVE	22.66699981689453	0	0	\N	88	2026-01-31 19:49:14.345
89	1	1	55.1069025	82.9520186	2026-01-31 19:12:01.235	MOVE	85	0.9300000071525574	316	\N	89	2026-01-31 19:49:14.345
90	1	1	55.1067934	82.952208	2026-01-31 19:12:20.247	MOVE	24.33600044250488	0	0	\N	90	2026-01-31 19:49:14.345
91	1	1	55.1068594	82.9527303	2026-01-31 19:13:01.286	MOVE	59	4.949999809265137	126	\N	91	2026-01-31 19:49:14.345
92	1	1	55.106789	82.9522035	2026-01-31 19:13:19.43	MOVE	24.00699996948242	0	0	\N	92	2026-01-31 19:49:14.345
93	1	1	55.1067117	82.9525452	2026-01-31 19:14:01.236	MOVE	100	0.4899999797344208	60	\N	93	2026-01-31 19:49:14.345
94	1	1	55.1067796	82.9522649	2026-01-31 19:14:20.208	MOVE	31.0580005645752	0	0	\N	94	2026-01-31 19:49:14.345
95	1	1	55.1070239	82.9520018	2026-01-31 19:15:02.238	MOVE	79.5	12.72999954223633	299	\N	95	2026-01-31 19:49:14.345
96	1	1	55.1070736	82.9518455	2026-01-31 19:15:04.098	MOVE	98.0979995727539	12.66694450378418	299.0753784179688	\N	96	2026-01-31 19:49:14.345
97	1	1	55.1067906	82.9522162	2026-01-31 19:15:21.101	MOVE	22.74600028991699	0	0	\N	97	2026-01-31 19:49:14.345
98	1	1	55.1069677	82.9521905	2026-01-31 19:16:04.251	MOVE	88.5	2.109999895095825	308	\N	98	2026-01-31 19:49:14.345
99	1	1	55.1067823	82.9522417	2026-01-31 19:16:23.259	MOVE	22.13199996948242	0	0	\N	99	2026-01-31 19:49:14.345
100	1	1	55.1068595	82.9522962	2026-01-31 19:17:14.167	MOVE	395.5759887695312	1.072343945503235	51.55415725708008	\N	100	2026-01-31 19:49:14.345
101	1	1	55.1068026	82.9522102	2026-01-31 19:17:31.205	MOVE	40.39699935913086	0	0	\N	101	2026-01-31 19:49:14.345
102	1	1	55.1056167	82.9586883	2026-01-31 19:17:45.36	MOVE	75.83300018310547	34.43742370605469	106.1299819946289	\N	102	2026-01-31 19:49:14.345
103	1	1	55.1068659	82.9523061	2026-01-31 19:18:09.247	MOVE	75	1.059999942779541	83	\N	103	2026-01-31 19:49:14.345
104	1	1	55.1067985	82.9522361	2026-01-31 19:18:31.23	MOVE	18.67000007629395	0	0	\N	104	2026-01-31 19:49:14.345
105	1	1	55.1069333	82.9523435	2026-01-31 19:18:45.241	MOVE	56	4.972354412078857	277.3412475585938	\N	105	2026-01-31 19:49:14.345
106	1	1	55.1068285	82.9522131	2026-01-31 19:18:58.225	MOVE	22.63599967956543	1.713366985321045	285.5112609863281	\N	106	2026-01-31 19:49:14.345
107	1	1	55.1069484	82.9519191	2026-01-31 19:19:14.255	MOVE	76	0.6800000071525574	321	\N	107	2026-01-31 19:49:14.345
108	1	1	55.1067726	82.952246	2026-01-31 19:19:32.214	MOVE	23.03499984741211	0	0	\N	108	2026-01-31 19:49:14.345
109	1	1	55.1068495	82.9522244	2026-01-31 19:20:14.233	MOVE	61	0.8390747904777527	111.0488510131836	\N	109	2026-01-31 19:49:14.345
110	1	1	55.1067929	82.9522341	2026-01-31 19:20:30.831	MOVE	33.91500091552734	0	0	\N	110	2026-01-31 19:49:14.345
111	1	1	55.1069011	82.9522823	2026-01-31 19:21:22.483	MOVE	329.1690063476562	1.633522748947144	37.64657974243164	\N	111	2026-01-31 19:49:14.345
112	1	1	55.1067723	82.9522373	2026-01-31 19:21:39.445	MOVE	42.07199859619141	0	0	\N	112	2026-01-31 19:49:14.345
113	1	1	55.1068213	82.9521225	2026-01-31 19:22:14.281	MOVE	73.5	2.187945127487183	320.8595275878906	\N	113	2026-01-31 19:49:14.345
114	1	1	55.1067827	82.9522465	2026-01-31 19:22:30.186	MOVE	30.14699935913086	0	0	\N	114	2026-01-31 19:49:14.345
115	1	1	55.1068474	82.952512	2026-01-31 19:22:44.255	MOVE	72.5	2.222326040267944	61.31353378295898	\N	115	2026-01-31 19:49:14.345
116	1	1	55.1067869	82.9522647	2026-01-31 19:23:00.193	MOVE	27.8390007019043	0	0	\N	116	2026-01-31 19:49:14.345
117	1	1	55.1068425	82.9520447	2026-01-31 19:23:14.241	MOVE	68.5	1.13027036190033	114.1530380249023	\N	117	2026-01-31 19:49:14.345
118	1	1	55.1067738	82.9522321	2026-01-31 19:23:32.2	MOVE	37.28099822998047	0	0	\N	118	2026-01-31 19:49:14.345
119	1	1	55.1068464	82.9522112	2026-01-31 19:24:14.224	MOVE	55.5	3.479134321212769	309.0774841308594	\N	119	2026-01-31 19:49:14.345
120	1	1	55.1067861	82.9522251	2026-01-31 19:24:30.12	MOVE	23.37599945068359	0	0	\N	120	2026-01-31 19:49:14.345
121	1	1	55.106784	82.9523616	2026-01-31 19:24:44.243	MOVE	78	3.917104721069336	311.0588073730469	\N	121	2026-01-31 19:49:14.345
122	1	1	55.1067831	82.9522227	2026-01-31 19:25:00.425	MOVE	23.67799949645996	0	0	\N	122	2026-01-31 19:49:14.345
123	1	1	55.1068421	82.9520626	2026-01-31 19:25:14.229	MOVE	67.5	3.264548301696777	299.2003479003906	\N	123	2026-01-31 19:49:14.345
124	1	1	55.1067765	82.952239	2026-01-31 19:25:29.44	MOVE	22.74600028991699	0	0	\N	124	2026-01-31 19:49:14.345
125	1	1	55.106838	82.9524126	2026-01-31 19:25:44.251	MOVE	82	2.693152666091919	311.2552795410156	\N	125	2026-01-31 19:49:14.345
126	1	1	55.1068101	82.9522097	2026-01-31 19:25:59.181	MOVE	22.64100074768066	1.749419093132019	302.6126403808594	\N	126	2026-01-31 19:49:14.345
127	1	1	55.1068009	82.952294	2026-01-31 19:26:17.209	MOVE	43.26499938964844	5.08620548248291	65.8900146484375	\N	127	2026-01-31 19:49:14.345
128	1	1	55.1070279	82.9516035	2026-01-31 19:27:10.229	MOVE	38.5	4.336557388305664	282.8895568847656	\N	128	2026-01-31 19:49:14.345
129	1	1	55.1067662	82.9522491	2026-01-31 19:27:27.829	MOVE	21.60499954223633	0	0	\N	129	2026-01-31 19:49:14.345
130	1	1	55.1067988	82.9524789	2026-01-31 19:27:44.214	MOVE	72.5	1.059999942779541	228	\N	130	2026-01-31 19:49:14.345
131	1	1	55.106772	82.9522515	2026-01-31 19:28:01.742	MOVE	21.61499977111816	0	0	\N	131	2026-01-31 19:49:14.345
132	1	1	55.1067274	82.9529113	2026-01-31 19:28:45.233	MOVE	121.5	0.6699999570846558	326	\N	132	2026-01-31 19:49:14.345
133	1	1	55.1067785	82.9522609	2026-01-31 19:29:02.23	MOVE	20.85300064086914	0	0	\N	133	2026-01-31 19:49:14.345
134	1	1	55.1068189	82.9524644	2026-01-31 19:29:19.286	MOVE	151.4199981689453	0.06730148196220398	0	\N	134	2026-01-31 19:49:14.345
135	1	1	55.1067755	82.9522568	2026-01-31 19:29:36.235	MOVE	31.19799995422363	0	0	\N	135	2026-01-31 19:49:14.345
136	1	1	55.1068174	82.9521754	2026-01-31 19:29:57.413	MOVE	31.6569995880127	1.147831678390503	287.922119140625	\N	136	2026-01-31 19:49:14.345
137	1	1	55.1069319	82.9525581	2026-01-31 19:30:14.252	MOVE	60.5	2.069999933242798	73	\N	137	2026-01-31 19:49:14.345
138	1	1	55.1067742	82.9522517	2026-01-31 19:30:31.425	MOVE	31.05200004577637	0	0	\N	138	2026-01-31 19:49:14.345
139	1	1	55.1068927	82.9521504	2026-01-31 19:31:14.254	MOVE	46	0.9799999594688416	111	\N	139	2026-01-31 19:49:14.345
140	1	1	55.1067951	82.9522403	2026-01-31 19:31:32.003	MOVE	18.5359992980957	0	0	\N	140	2026-01-31 19:49:14.345
141	1	1	55.1068805	82.9527118	2026-01-31 19:31:49.01	MOVE	146.0769958496094	0.152097687125206	270.0281066894531	\N	141	2026-01-31 19:49:14.345
142	1	1	55.1067796	82.9522378	2026-01-31 19:32:06.076	MOVE	22.01899909973145	0	0	\N	142	2026-01-31 19:49:14.345
143	1	1	55.1068278	82.9528036	2026-01-31 19:33:14.246	MOVE	161.5	1.961196303367615	82.06017303466797	\N	143	2026-01-31 19:49:14.345
144	1	1	55.1067925	82.9523005	2026-01-31 19:33:27.797	MOVE	28.09900093078613	2.169147491455078	263.0561828613281	\N	144	2026-01-31 19:49:14.345
145	1	1	55.1069014	82.9518177	2026-01-31 19:33:44.242	MOVE	146	12.69999980926514	94	\N	145	2026-01-31 19:49:14.345
146	1	1	55.1067672	82.9522211	2026-01-31 19:34:02.049	MOVE	33.88899993896484	0	0	\N	146	2026-01-31 19:49:14.345
147	1	1	55.1068049	82.9523014	2026-01-31 19:34:29.133	MOVE	40.39500045776367	0.03305279836058617	0	\N	147	2026-01-31 19:49:14.345
148	1	1	55.1070215	82.9517737	2026-01-31 19:34:45.247	MOVE	75	15.21000003814697	278	\N	148	2026-01-31 19:49:14.345
149	1	1	55.1067709	82.9522516	2026-01-31 19:35:03.163	MOVE	21.72200012207031	0	0	\N	149	2026-01-31 19:49:14.345
150	1	1	55.1069501	82.9522274	2026-01-31 19:35:44.229	MOVE	75.5	0.4599999785423279	283	\N	150	2026-01-31 19:49:14.345
151	1	1	55.1067922	82.9522845	2026-01-31 19:36:03.056	MOVE	42.80799865722656	0	0	\N	151	2026-01-31 19:49:14.345
152	1	1	55.1068007	82.952745	2026-01-31 19:36:45.229	MOVE	232	5.509999752044678	283	\N	152	2026-01-31 19:49:14.345
153	1	1	55.1067976	82.952254	2026-01-31 19:37:03.055	MOVE	41.3380012512207	0	0	\N	153	2026-01-31 19:49:14.345
154	1	1	55.1066537	82.9528102	2026-01-31 19:37:45.234	MOVE	72.5	6.259999752044678	145	\N	154	2026-01-31 19:49:14.345
155	1	1	55.1067744	82.9522673	2026-01-31 19:38:03.39	MOVE	20.33699989318848	0	0	\N	155	2026-01-31 19:49:14.345
156	1	1	55.1066622	82.9524778	2026-01-31 19:39:45.224	MOVE	120.5	4.839999675750732	312	\N	156	2026-01-31 19:49:14.345
157	1	1	55.106795	82.9522392	2026-01-31 19:40:02.579	MOVE	36.99700164794922	0	0	\N	157	2026-01-31 19:49:14.345
158	1	1	55.1067861	82.952384	2026-01-31 19:40:28.141	MOVE	28.67799949645996	1.211562037467957	152.8260955810547	\N	158	2026-01-31 19:49:14.345
159	1	1	55.1067793	82.9522533	2026-01-31 19:40:45.201	MOVE	22.56399917602539	0	0	\N	159	2026-01-31 19:49:14.345
160	1	1	55.1068067	82.9521806	2026-01-31 19:41:03.352	MOVE	37.98799896240234	0	0	\N	160	2026-01-31 19:49:14.345
161	1	1	55.1067825	82.9522791	2026-01-31 19:41:29.14	MOVE	31.97299957275391	0.7278210520744324	240.4758605957031	\N	161	2026-01-31 19:49:14.345
162	1	1	55.1068968	82.9526558	2026-01-31 19:41:45.233	MOVE	173.5	2.190000057220459	270	\N	162	2026-01-31 19:49:14.345
163	1	1	55.1067894	82.9522519	2026-01-31 19:42:03.369	MOVE	20.86899948120117	0	0	\N	163	2026-01-31 19:49:14.345
164	1	1	55.1068485	82.9526727	2026-01-31 19:42:44.229	MOVE	85	8.149999618530273	83	\N	164	2026-01-31 19:49:14.345
165	1	1	55.1067683	82.9522654	2026-01-31 19:43:02.716	MOVE	38.82799911499023	0	0	\N	165	2026-01-31 19:49:14.345
166	1	1	55.1069695	82.9523101	2026-01-31 19:43:44.216	MOVE	168.5	2.440000057220459	262	\N	166	2026-01-31 19:49:14.345
167	1	1	55.1067764	82.9522453	2026-01-31 19:44:01.387	MOVE	22.68400001525879	0	0	\N	167	2026-01-31 19:49:14.345
168	1	1	55.1069178	82.9522793	2026-01-31 19:45:18.252	MOVE	228.5	7.659999847412109	84	\N	168	2026-01-31 19:49:14.345
169	1	1	55.1067984	82.9522335	2026-01-31 19:45:42.181	MOVE	37.17300033569336	0	0	\N	169	2026-01-31 19:49:14.345
170	1	1	55.106896	82.9526594	2026-01-31 19:47:00.227	MOVE	150	1.449999928474426	78	\N	170	2026-01-31 19:49:14.345
171	1	1	55.1067799	82.9522373	2026-01-31 19:47:17.491	MOVE	22.89200019836426	0	0	\N	171	2026-01-31 19:49:14.345
172	1	1	55.1068893	82.9527489	2026-01-31 19:47:44.122	MOVE	47.99200057983398	5.769267082214355	73.23225402832031	\N	172	2026-01-31 19:49:14.345
173	1	1	55.106862	82.9524895	2026-01-31 19:47:59.222	MOVE	101	4	248	\N	173	2026-01-31 19:49:14.345
174	1	1	55.1068013	82.9522353	2026-01-31 19:48:20.381	MOVE	32.04800033569336	0	0	\N	174	2026-01-31 19:49:14.345
175	1	1	55.1068722	82.9525658	2026-01-31 19:49:29.18	MOVE	82.5	4.587444305419922	81.87248229980469	\N	175	2026-01-31 20:49:22.597
176	1	1	55.1067904	82.952314	2026-01-31 19:49:44.107	MOVE	22.26300048828125	1.428903818130493	66.1718521118164	\N	176	2026-01-31 20:49:22.597
177	1	1	55.1069217	82.9526237	2026-01-31 19:49:59.196	MOVE	78.5	2.089999914169312	267	\N	177	2026-01-31 20:49:22.597
178	1	1	55.1067735	82.9522548	2026-01-31 19:50:18.351	MOVE	34.10900115966797	0	0	\N	178	2026-01-31 20:49:22.597
179	1	1	55.1068119	82.9522114	2026-01-31 19:51:43.18	MOVE	38.99900054931641	0.3738274276256561	250.4691925048828	\N	179	2026-01-31 20:49:22.597
180	1	1	55.1068941	82.9529029	2026-01-31 19:51:59.221	MOVE	99.5	1.419999957084656	266	\N	180	2026-01-31 20:49:22.597
181	1	1	55.1067718	82.9522516	2026-01-31 19:52:17.817	MOVE	22.25799942016602	0	0	\N	181	2026-01-31 20:49:22.597
182	1	1	55.1069353	82.9525594	2026-01-31 19:53:59.218	MOVE	68.5	1.899999976158142	49	\N	182	2026-01-31 20:49:22.597
183	1	1	55.1067754	82.9522614	2026-01-31 19:54:17.114	MOVE	20.57099914550781	0	0	\N	183	2026-01-31 20:49:22.597
184	1	1	55.1068124	82.9524657	2026-01-31 19:54:43.095	MOVE	37.27799987792969	1.116198897361755	79.69657897949219	\N	184	2026-01-31 20:49:22.597
185	1	1	55.1069019	82.9520174	2026-01-31 19:54:59.203	MOVE	79	1.319999933242798	259	\N	185	2026-01-31 20:49:22.597
186	1	1	55.1067758	82.9522629	2026-01-31 19:55:17.635	MOVE	20.49900054931641	0	0	\N	186	2026-01-31 20:49:22.597
187	1	1	55.1067858	82.9523636	2026-01-31 19:55:44.187	MOVE	27.01700019836426	0.3681509494781494	178.3578491210938	\N	187	2026-01-31 20:49:22.597
188	1	1	55.1069162	82.951796	2026-01-31 19:55:58.19	MOVE	48	5.876004695892334	271.0030212402344	\N	188	2026-01-31 20:49:22.597
189	1	1	55.106919	82.9515476	2026-01-31 19:56:01.453	MOVE	113.2470016479492	5.844490051269531	271.0083923339844	\N	189	2026-01-31 20:49:22.597
190	1	1	55.1067712	82.9522524	2026-01-31 19:56:25.084	MOVE	20.99600028991699	0	0	\N	190	2026-01-31 20:49:22.597
191	1	1	55.1067843	82.9521572	2026-01-31 19:57:12.77	MOVE	23.67799949645996	3.918256282806396	260.3797607421875	\N	191	2026-01-31 20:49:22.597
192	1	1	55.1068414	82.95231	2026-01-31 19:57:29.203	MOVE	50.5	0.3499999940395355	90	\N	192	2026-01-31 20:49:22.597
193	1	1	55.1067879	82.9522572	2026-01-31 19:57:55.093	MOVE	22.26300048828125	0	0	\N	193	2026-01-31 20:49:22.597
194	1	1	55.1068229	82.9524459	2026-01-31 19:58:59.201	MOVE	67	1.02417266368866	252.9115753173828	\N	194	2026-01-31 20:49:22.597
195	1	1	55.1067863	82.9522489	2026-01-31 19:59:25.117	MOVE	18.93099975585938	0	0	\N	195	2026-01-31 20:49:22.597
196	1	1	55.1069269	82.9523828	2026-01-31 19:59:59.351	MOVE	60.5	0.1599999964237213	140	\N	196	2026-01-31 20:49:22.597
197	1	1	55.1067839	82.9522373	2026-01-31 20:00:25.077	MOVE	42.72600173950195	0	0	\N	197	2026-01-31 20:49:22.597
198	1	1	55.1069219	82.9518779	2026-01-31 20:00:59.195	MOVE	59.5	0.03999999910593033	0	\N	198	2026-01-31 20:49:22.597
199	1	1	55.1067832	82.9522446	2026-01-31 20:01:18.325	MOVE	21.66799926757812	0	0	\N	199	2026-01-31 20:49:22.597
200	1	1	55.1068261	82.9523451	2026-01-31 20:02:11.868	MOVE	21.5359992980957	1.471130132675171	55.39438247680664	\N	200	2026-01-31 20:49:22.597
201	1	1	55.106943	82.9526956	2026-01-31 20:02:29.203	MOVE	90	1.519999980926514	260	\N	201	2026-01-31 20:49:22.597
202	1	1	55.1068022	82.9522333	2026-01-31 20:02:53.254	MOVE	38.94100189208984	0	0	\N	202	2026-01-31 20:49:22.597
203	1	1	55.1068123	82.9523965	2026-01-31 20:03:43.094	MOVE	37.83399963378906	1.115727186203003	93.457275390625	\N	203	2026-01-31 20:49:22.597
204	1	1	55.1069524	82.9533896	2026-01-31 20:04:25.391	MOVE	45.75	3.23774528503418	83.04176330566406	\N	204	2026-01-31 20:49:22.597
205	1	1	55.1067842	82.9522906	2026-01-31 20:04:43.02	MOVE	32.80300140380859	0	0	\N	205	2026-01-31 20:49:22.597
206	1	1	55.1068623	82.9523635	2026-01-31 20:04:59.187	MOVE	72	0.5099999904632568	106	\N	206	2026-01-31 20:49:22.597
207	1	1	55.1067912	82.9522449	2026-01-31 20:05:17.415	MOVE	37.15599822998047	0	0	\N	207	2026-01-31 20:49:22.597
208	1	1	55.1068761	82.9524455	2026-01-31 20:06:29.186	MOVE	57.5	0.429999977350235	259	\N	208	2026-01-31 20:49:22.597
209	1	1	55.1067716	82.9522451	2026-01-31 20:06:47.249	MOVE	21.61599922180176	0	0	\N	209	2026-01-31 20:49:22.597
210	1	1	55.1068312	82.9521452	2026-01-31 20:07:12.22	MOVE	42.82199859619141	1.00437343120575	107.6745223999023	\N	210	2026-01-31 20:49:22.597
211	1	1	55.1067809	82.9522503	2026-01-31 20:07:41.192	MOVE	40.52199935913086	0	0	\N	211	2026-01-31 20:49:22.597
212	1	1	55.1070383	82.9522183	2026-01-31 20:07:55.33	MOVE	48.5	1.627725124359131	301.0705261230469	\N	212	2026-01-31 20:49:22.597
213	1	1	55.1071123	82.9520761	2026-01-31 20:08:02.498	MOVE	172.4869995117188	1.315057277679443	303.910400390625	\N	213	2026-01-31 20:49:22.597
214	1	1	55.1067824	82.9522706	2026-01-31 20:08:23.133	MOVE	21.76899909973145	0	0	\N	214	2026-01-31 20:49:22.597
215	1	1	55.1068303	82.9521651	2026-01-31 20:09:13.069	MOVE	21.27000045776367	4.794684886932373	312.1956481933594	\N	215	2026-01-31 20:49:22.597
216	1	1	55.1067645	82.9527178	2026-01-31 20:09:29.175	MOVE	68.5	1.490000009536743	344	\N	216	2026-01-31 20:49:22.597
217	1	1	55.1067829	82.952333	2026-01-31 20:09:52.338	MOVE	31.27099990844727	0	0	\N	217	2026-01-31 20:49:22.597
218	1	1	55.1067831	82.9522303	2026-01-31 20:10:13.445	MOVE	20.94300079345703	0.7738791704177856	254.7453918457031	\N	218	2026-01-31 20:49:22.597
219	1	1	55.1069291	82.9518337	2026-01-31 20:10:29.18	MOVE	52.5	2.690000057220459	9	\N	219	2026-01-31 20:49:22.597
220	1	1	55.106807	82.9520747	2026-01-31 20:10:47.676	MOVE	47.30099868774414	0	0	\N	220	2026-01-31 20:49:22.597
221	1	1	55.1067756	82.9522594	2026-01-31 20:11:15.034	MOVE	22.02799987792969	0	0	\N	221	2026-01-31 20:49:22.597
222	1	1	55.1068715	82.9521065	2026-01-31 20:11:29.321	MOVE	56	1.875422120094299	279.0238952636719	\N	222	2026-01-31 20:49:22.597
223	1	1	55.1068527	82.9524167	2026-01-31 20:11:52.376	MOVE	49	0.8969982266426086	288.0661010742188	\N	223	2026-01-31 20:49:22.597
224	1	1	55.1068468	82.9523031	2026-01-31 20:11:56.517	MOVE	54.83700180053711	0.2153297364711761	285.6163940429688	\N	224	2026-01-31 20:49:22.597
225	1	1	55.1068014	82.9522833	2026-01-31 20:12:23.097	MOVE	21.44700050354004	0	0	\N	225	2026-01-31 20:49:22.597
226	1	1	55.1069621	82.9522315	2026-01-31 20:12:59.188	MOVE	57.5	2.190000057220459	82	\N	226	2026-01-31 20:49:22.597
227	1	1	55.1067709	82.9522515	2026-01-31 20:13:23.125	MOVE	22.19700050354004	0	0	\N	227	2026-01-31 20:49:22.597
228	1	1	55.1068175	82.9522322	2026-01-31 20:14:42.147	MOVE	34.90999984741211	1.177339553833008	299.2871704101562	\N	228	2026-01-31 20:49:22.597
229	1	1	55.1068687	82.9521768	2026-01-31 20:15:03.143	MOVE	194.7539978027344	1.367183804512024	271.0213928222656	\N	229	2026-01-31 20:49:22.597
230	1	1	55.1067823	82.9522086	2026-01-31 20:15:24.314	MOVE	35.93500137329102	0	0	\N	230	2026-01-31 20:49:22.597
231	1	1	55.1068077	82.9525849	2026-01-31 20:16:29.352	MOVE	84	0.5276336669921875	153.687255859375	\N	231	2026-01-31 20:49:22.597
232	1	1	55.1067825	82.9523448	2026-01-31 20:16:44.107	MOVE	36.90200042724609	0.4234292507171631	164.4731597900391	\N	232	2026-01-31 20:49:22.597
233	1	1	55.1069147	82.9527014	2026-01-31 20:16:59.144	MOVE	80.5	0.550000011920929	233	\N	233	2026-01-31 20:49:22.597
234	1	1	55.1067889	82.9522708	2026-01-31 20:17:14.053	MOVE	34.82899856567383	0.6841033101081848	237.3109588623047	\N	234	2026-01-31 20:49:22.597
235	1	1	55.1068342	82.9528421	2026-01-31 20:17:29.346	MOVE	73.5	0.5999999642372131	110	\N	235	2026-01-31 20:49:22.597
236	1	1	55.1067916	82.9523166	2026-01-31 20:17:43.085	MOVE	27.47400093078613	0.2791429460048676	138.3221893310547	\N	236	2026-01-31 20:49:22.597
237	1	1	55.10705	82.9517424	2026-01-31 20:17:59.159	MOVE	63.5	1.709999918937683	280	\N	237	2026-01-31 20:49:22.597
238	1	1	55.106853	82.9524625	2026-01-31 20:18:25.141	MOVE	46.5	8.260000228881836	99	\N	238	2026-01-31 20:49:22.597
239	1	1	55.1067823	82.9523076	2026-01-31 20:18:44.967	MOVE	31.78000068664551	0	0	\N	239	2026-01-31 20:49:22.597
240	1	1	55.1069047	82.9526592	2026-01-31 20:18:59.306	MOVE	57	0.06263799965381622	0	\N	240	2026-01-31 20:49:22.597
241	1	1	55.1068465	82.9528262	2026-01-31 20:19:21.33	MOVE	46	3	73	\N	241	2026-01-31 20:49:22.597
242	1	1	55.1067851	82.9522607	2026-01-31 20:19:53.073	MOVE	40.35699844360352	0	0	\N	242	2026-01-31 20:49:22.597
243	1	1	55.1068744	82.951791	2026-01-31 20:21:13.091	MOVE	36.61100006103516	9.953685760498047	283.5340881347656	\N	243	2026-01-31 20:49:22.597
244	1	1	55.1070239	82.9521596	2026-01-31 20:21:29.143	MOVE	150.5	0.5600000023841858	88	\N	244	2026-01-31 20:49:22.597
245	1	1	55.1067733	82.9522511	2026-01-31 20:21:47.449	MOVE	21.90900039672852	0	0	\N	245	2026-01-31 20:49:22.597
246	1	1	55.106904	82.9526329	2026-01-31 20:22:29.125	MOVE	66	1.009999990463257	261	\N	246	2026-01-31 20:49:22.597
247	1	1	55.1067872	82.9522884	2026-01-31 20:22:46.086	MOVE	36.47800064086914	0	0	\N	247	2026-01-31 20:49:22.597
248	1	1	55.1068944	82.9524067	2026-01-31 20:23:03.196	MOVE	148.9859924316406	0.5349803566932678	260.9423828125	\N	248	2026-01-31 20:49:22.597
249	1	1	55.1068097	82.9522218	2026-01-31 20:23:20.321	MOVE	39.57500076293945	0	0	\N	249	2026-01-31 20:49:22.597
250	1	1	55.1067848	82.9523608	2026-01-31 20:23:54.588	MOVE	29.29999923706055	0	0	\N	250	2026-01-31 20:49:22.597
251	1	1	55.1067687	82.9522555	2026-01-31 20:24:28.851	MOVE	22.01300048828125	0	0	\N	251	2026-01-31 20:49:22.597
252	1	1	55.1068698	82.9525845	2026-01-31 20:25:03.063	MOVE	149.8309936523438	0.2749110162258148	238.6690368652344	\N	252	2026-01-31 20:49:22.597
253	1	1	55.1067677	82.9522673	2026-01-31 20:25:20.167	MOVE	36.9739990234375	0	0	\N	253	2026-01-31 20:49:22.597
254	1	1	55.106805	82.9524731	2026-01-31 20:25:37.307	MOVE	32.2859992980957	1.687585949897766	88.7199478149414	\N	254	2026-01-31 20:49:22.597
255	1	1	55.1067747	82.9522583	2026-01-31 20:25:54.453	MOVE	31.20800018310547	0	0	\N	255	2026-01-31 20:49:22.597
256	1	1	55.106907	82.9527445	2026-01-31 20:26:59.155	MOVE	128	2.859999895095825	276	\N	256	2026-01-31 20:49:22.597
257	1	1	55.106769	82.952253	2026-01-31 20:27:17.399	MOVE	22.30299949645996	0	0	\N	257	2026-01-31 20:49:22.597
258	1	1	55.1067854	82.9523394	2026-01-31 20:27:44.006	MOVE	33.19699859619141	0.6611502170562744	115.1650161743164	\N	258	2026-01-31 20:49:22.597
259	1	1	55.1068719	82.9526985	2026-01-31 20:27:59.286	MOVE	84	1.610000014305115	82	\N	259	2026-01-31 20:49:22.597
260	1	1	55.1067951	82.9522921	2026-01-31 20:28:24.203	MOVE	27.35600090026855	0	0	\N	260	2026-01-31 20:49:22.597
261	1	1	55.1068285	82.9522309	2026-01-31 20:30:00.289	MOVE	68.447998046875	0.9994944930076599	280.0047302246094	\N	261	2026-01-31 20:49:22.597
262	1	1	55.1067759	82.9522547	2026-01-31 20:30:25.2	MOVE	22.13599967956543	0	0	\N	262	2026-01-31 20:49:22.597
263	1	1	55.1068935	82.952487	2026-01-31 20:31:06.314	MOVE	222.72900390625	1.703203082084656	92.00617980957031	\N	263	2026-01-31 20:49:22.597
264	1	1	55.1067721	82.9522568	2026-01-31 20:31:25.241	MOVE	21.7450008392334	0	0	\N	264	2026-01-31 20:49:22.597
265	1	1	55.1067819	82.9521701	2026-01-31 20:32:41.109	MOVE	23.07999992370605	3.710431098937988	262.6717834472656	\N	265	2026-01-31 20:49:22.597
266	1	1	55.1067893	82.9522646	2026-01-31 20:32:58.279	MOVE	33.14199829101562	0	0	\N	266	2026-01-31 20:49:22.597
267	1	1	55.1067971	82.9525654	2026-01-31 20:33:29.295	MOVE	69.5	0.8545770645141602	258.9325866699219	\N	267	2026-01-31 20:49:22.597
268	1	1	55.1067976	82.9522602	2026-01-31 20:33:41.983	MOVE	37.5629997253418	0.9456618428230286	260.1221313476562	\N	268	2026-01-31 20:49:22.597
269	1	1	55.1069641	82.9521536	2026-01-31 20:34:44.122	MOVE	170	1.5	65	\N	269	2026-01-31 20:49:22.597
270	1	1	55.1067922	82.9521873	2026-01-31 20:35:02.431	MOVE	38.54499816894531	0	0	\N	270	2026-01-31 20:49:22.597
271	1	1	55.1068753	82.9520183	2026-01-31 20:35:44.119	MOVE	68	4.059999942779541	267	\N	271	2026-01-31 20:49:22.597
272	1	1	55.1067823	82.9522249	2026-01-31 20:36:02.456	MOVE	23.52000045776367	0	0	\N	272	2026-01-31 20:49:22.597
273	1	1	55.1068941	82.9518556	2026-01-31 20:36:44.141	MOVE	70	5.329999923706055	278	\N	273	2026-01-31 20:49:22.597
274	1	1	55.1067744	82.9522403	2026-01-31 20:37:02.294	MOVE	35.70500183105469	0	0	\N	274	2026-01-31 20:49:22.597
275	1	1	55.1067936	82.9523175	2026-01-31 20:39:16.271	MOVE	249	0.3078335523605347	64.77597045898438	\N	275	2026-01-31 20:49:22.597
276	1	1	55.106838	82.9524822	2026-01-31 20:39:23.764	MOVE	398.8460083007812	1.374834775924683	64.77597045898438	\N	276	2026-01-31 20:49:22.597
277	1	1	55.106792	82.9521772	2026-01-31 20:39:41.263	MOVE	48.88100051879883	0	0	\N	277	2026-01-31 20:49:22.597
278	1	1	55.1067771	82.9522547	2026-01-31 20:39:58.937	MOVE	20.88699913024902	0.5159613490104675	272.5592346191406	\N	278	2026-01-31 20:49:22.597
279	1	1	55.1069111	82.9527602	2026-01-31 20:40:59.127	MOVE	48.5	4.809999942779541	81	\N	279	2026-01-31 20:49:22.597
280	1	1	55.1067826	82.9522352	2026-01-31 20:41:17.182	MOVE	21.70899963378906	0	0	\N	280	2026-01-31 20:49:22.597
281	1	1	55.1068019	82.952384	2026-01-31 20:41:31.118	MOVE	197	7.190710067749023	101.0550765991211	\N	281	2026-01-31 20:49:22.597
282	1	1	55.1067752	82.9522963	2026-01-31 20:41:42.163	MOVE	42.29999923706055	2.107070922851562	121.8306121826172	\N	282	2026-01-31 20:49:22.597
283	1	1	55.107019	82.952054	2026-01-31 20:41:59.126	MOVE	115.5	0.9099999666213989	295	\N	283	2026-01-31 20:49:22.597
284	1	1	55.1067837	82.9522231	2026-01-31 20:42:17.243	MOVE	29.04500007629395	0	0	\N	284	2026-01-31 20:49:22.597
285	1	1	55.1069806	82.9526138	2026-01-31 20:42:59.111	MOVE	109.5	3.509999990463257	272	\N	285	2026-01-31 20:49:22.597
286	1	1	55.1067941	82.9522793	2026-01-31 20:43:16.405	MOVE	34.45500183105469	0	0	\N	286	2026-01-31 20:49:22.597
287	1	1	55.1068706	82.9520077	2026-01-31 20:44:41.579	MOVE	40.29399871826172	3.710165500640869	276.90576171875	\N	287	2026-01-31 20:49:22.597
288	1	1	55.1069182	82.952708	2026-01-31 20:44:59.118	MOVE	132	1.679999947547913	302	\N	288	2026-01-31 20:49:22.597
289	1	1	55.1067936	82.952268	2026-01-31 20:45:16.334	MOVE	30.28899955749512	0	0	\N	289	2026-01-31 20:49:22.597
290	1	1	55.1069531	82.952576	2026-01-31 20:45:59.106	MOVE	218	2.240000009536743	305	\N	290	2026-01-31 20:49:22.597
291	1	1	55.1067686	82.9522533	2026-01-31 20:46:16.457	MOVE	21.63999938964844	0	0	\N	291	2026-01-31 20:49:22.597
292	1	1	55.1070504	82.9518829	2026-01-31 20:46:34.107	MOVE	154.5	1.100000023841858	93	\N	292	2026-01-31 20:49:22.597
293	1	1	55.1067746	82.9522589	2026-01-31 20:47:00.169	MOVE	20.9950008392334	0	0	\N	293	2026-01-31 20:49:22.597
294	1	1	55.1068622	82.9524319	2026-01-31 20:47:14.102	MOVE	144	4.031574726104736	95.0305404663086	\N	294	2026-01-31 20:49:22.597
295	1	1	55.1067762	82.9522811	2026-01-31 20:47:27.681	MOVE	21.32799911499023	2.968671321868896	96.92539978027344	\N	295	2026-01-31 20:49:22.597
296	1	1	55.1067903	82.952197	2026-01-31 20:47:44.938	MOVE	39.05300140380859	0	0	\N	296	2026-01-31 20:49:22.597
297	1	1	55.1068421	82.9527637	2026-01-31 20:48:44.114	MOVE	176.5	2.759999990463257	91	\N	297	2026-01-31 20:49:22.597
298	1	1	55.1067809	82.9522502	2026-01-31 20:49:01.862	MOVE	21.67099952697754	0	0	\N	298	2026-01-31 20:49:22.597
299	1	1	55.1068685	82.9527054	2026-01-31 20:50:14.098	MOVE	59.5	4.995705604553223	104.0338745117188	\N	299	2026-01-31 22:50:09.841
300	1	1	55.1068372	82.9529425	2026-01-31 20:50:17.382	MOVE	190.7989959716797	4.989573955535889	104.0475845336914	\N	300	2026-01-31 22:50:09.841
301	1	1	55.1067846	82.9522387	2026-01-31 20:50:39.517	MOVE	22.79299926757812	0	0	\N	301	2026-01-31 22:50:09.841
302	1	1	55.1068641	82.9523218	2026-01-31 20:51:14.092	MOVE	134	1.629999995231628	275	\N	302	2026-01-31 22:50:09.841
303	1	1	55.1067736	82.9522429	2026-01-31 20:51:32.238	MOVE	22.57099914550781	0	0	\N	303	2026-01-31 22:50:09.841
304	1	1	55.1069924	82.9518574	2026-01-31 20:53:15.075	MOVE	142	3.349999904632568	289	\N	304	2026-01-31 22:50:09.841
305	1	1	55.1067926	82.9521944	2026-01-31 20:53:32.254	MOVE	25.89599990844727	0	0	\N	305	2026-01-31 22:50:09.841
306	1	1	55.1069092	82.9521178	2026-01-31 20:53:49.279	MOVE	245.4819946289062	3.716026067733765	298.0932922363281	\N	306	2026-01-31 22:50:09.841
307	1	1	55.1067606	82.9522537	2026-01-31 20:54:06.351	MOVE	23.91699981689453	0	0	\N	307	2026-01-31 22:50:09.841
308	1	1	55.1067036	82.9523436	2026-01-31 20:54:25.266	MOVE	87	3.835837841033936	133.5947570800781	\N	308	2026-01-31 22:50:09.841
309	1	1	55.1067543	82.9522597	2026-01-31 20:54:42.884	MOVE	36.85400009155273	0	0	\N	309	2026-01-31 22:50:09.841
310	1	1	55.1069084	82.9523853	2026-01-31 20:56:00.084	MOVE	156	0.8199999928474426	288	\N	310	2026-01-31 22:50:09.841
311	1	1	55.1067738	82.952248	2026-01-31 20:56:17.223	MOVE	22.77799987792969	0	0	\N	311	2026-01-31 22:50:09.841
312	1	1	55.1067654	82.9528375	2026-01-31 20:56:59.101	MOVE	133.5	2.269999980926514	108	\N	312	2026-01-31 22:50:09.841
313	1	1	55.1067884	82.9522642	2026-01-31 20:57:16.456	MOVE	38.98699951171875	0	0	\N	313	2026-01-31 22:50:09.841
314	1	1	55.1068479	82.9530469	2026-01-31 20:57:59.077	MOVE	162.5	0	0	\N	314	2026-01-31 22:50:09.841
315	1	1	55.1067746	82.9522448	2026-01-31 20:58:17.227	MOVE	22.76499938964844	0	0	\N	315	2026-01-31 22:50:09.841
316	1	1	55.1067368	82.9529561	2026-01-31 20:59:20.097	MOVE	46	15.11999988555908	119	\N	316	2026-01-31 22:50:09.841
317	1	1	55.1067877	82.9523244	2026-01-31 20:59:42.137	MOVE	31.69400024414062	0	0	\N	317	2026-01-31 22:50:09.841
318	1	1	55.1069613	82.9520667	2026-01-31 20:59:59.091	MOVE	93.5	2.359999895095825	270	\N	318	2026-01-31 22:50:09.841
319	1	1	55.1067771	82.9522982	2026-01-31 21:00:16.735	MOVE	31.49300003051758	0	0	\N	319	2026-01-31 22:50:09.841
320	1	1	55.1068363	82.9521113	2026-01-31 21:00:42.181	MOVE	52.35599899291992	0.4308586418628693	265.7720947265625	\N	320	2026-01-31 22:50:09.841
321	1	1	55.107052	82.9517834	2026-01-31 21:00:59.082	MOVE	97.5	2.730000019073486	101	\N	321	2026-01-31 22:50:09.841
322	1	1	55.1068245	82.9520945	2026-01-31 21:01:17.22	MOVE	56.02199935913086	0	0	\N	322	2026-01-31 22:50:09.841
323	1	1	55.1067805	82.9522191	2026-01-31 21:01:43.221	MOVE	23.05999946594238	0.5907383561134338	75.83576202392578	\N	323	2026-01-31 22:50:09.841
324	1	1	55.1068726	82.9523443	2026-01-31 21:01:59.078	MOVE	92	2.210000038146973	279	\N	324	2026-01-31 22:50:09.841
325	1	1	55.1068583	82.9525085	2026-01-31 21:02:25.047	MOVE	49.5	12.26999950408936	83	\N	325	2026-01-31 22:50:09.841
326	1	1	55.1067896	82.9522614	2026-01-31 21:02:43.499	MOVE	40.75199890136719	0	0	\N	326	2026-01-31 22:50:09.841
327	1	1	55.1068908	82.9520345	2026-01-31 21:03:29.091	MOVE	124.5	0.9099999666213989	125	\N	327	2026-01-31 22:50:09.841
328	1	1	55.1067816	82.9522477	2026-01-31 21:03:47.204	MOVE	44.29800033569336	0	0	\N	328	2026-01-31 22:50:09.841
329	1	1	55.1068233	82.9521544	2026-01-31 21:04:18.085	MOVE	248.5	1.72874927520752	300.013427734375	\N	329	2026-01-31 22:50:09.841
330	1	1	55.1067837	82.9522707	2026-01-31 21:04:45.961	MOVE	35.37200164794922	0	0	\N	330	2026-01-31 22:50:09.841
331	1	1	55.1068512	82.9523613	2026-01-31 21:05:00.089	MOVE	103.5	1.358542919158936	261.9388732910156	\N	331	2026-01-31 22:50:09.841
332	1	1	55.1067944	82.9522383	2026-01-31 21:05:12.064	MOVE	23.83399963378906	1.22563910484314	260.9055786132812	\N	332	2026-01-31 22:50:09.841
333	1	1	55.1065949	82.9479523	2026-01-31 21:06:01.24	MOVE	200.5	0	0	\N	333	2026-01-31 22:50:09.841
334	1	1	55.1067707	82.9522622	2026-01-31 21:06:25.584	MOVE	22.58600044250488	0	0	\N	334	2026-01-31 22:50:09.841
335	1	1	55.1068904	82.9522219	2026-01-31 21:07:00.081	MOVE	104	6.639999866485596	88	\N	335	2026-01-31 22:50:09.841
336	1	1	55.1067755	82.9522504	2026-01-31 21:07:18.524	MOVE	23.42700004577637	0	0	\N	336	2026-01-31 22:50:09.841
337	1	1	55.106762	82.9519487	2026-01-31 21:08:01.07	MOVE	184.5	0.3618844747543335	275.2065734863281	\N	337	2026-01-31 22:50:09.841
338	1	1	55.1067734	82.9522766	2026-01-31 21:08:16.37	MOVE	32.22800064086914	0	0	\N	338	2026-01-31 22:50:09.841
339	1	1	55.1068739	82.9519979	2026-01-31 21:08:59.094	MOVE	155.5	1.129999995231628	237	\N	339	2026-01-31 22:50:09.841
340	1	1	55.1067884	82.9522495	2026-01-31 21:09:17.235	MOVE	38.06800079345703	0	0	\N	340	2026-01-31 22:50:09.841
341	1	1	55.1069216	82.9519848	2026-01-31 21:10:14.069	MOVE	76	0.8899999856948853	285	\N	341	2026-01-31 22:50:09.841
342	1	1	55.1067848	82.9522319	2026-01-31 21:10:32.373	MOVE	23.86700057983398	0	0	\N	342	2026-01-31 22:50:09.841
343	1	1	55.1069298	82.9525905	2026-01-31 21:10:48.047	MOVE	187.5	4.299999713897705	93	\N	343	2026-01-31 22:50:09.841
344	1	1	55.1067581	82.9522659	2026-01-31 21:11:12.043	MOVE	48.03300094604492	0	0	\N	344	2026-01-31 22:50:09.841
345	1	1	55.1070231	82.9511084	2026-01-31 21:11:29.063	MOVE	151.5	0	0	\N	345	2026-01-31 22:50:09.841
346	1	1	55.1067719	82.9522554	2026-01-31 21:11:50.073	MOVE	22.02700042724609	0	0	\N	346	2026-01-31 22:50:09.841
347	1	1	55.1068625	82.9517113	2026-01-31 21:13:29.06	MOVE	138.5	1.71999990940094	113	\N	347	2026-01-31 22:50:09.841
348	1	1	55.1067892	82.95234	2026-01-31 21:13:47.142	MOVE	30.51199913024902	0	0	\N	348	2026-01-31 22:50:09.841
349	1	1	55.1069083	82.9524055	2026-01-31 21:14:29.068	MOVE	101.5	5.279999732971191	298	\N	349	2026-01-31 22:50:09.841
350	1	1	55.1067573	82.9522908	2026-01-31 21:14:46.27	MOVE	40.58700180053711	0	0	\N	350	2026-01-31 22:50:09.841
351	1	1	55.1069688	82.9520641	2026-01-31 21:15:29.079	MOVE	59.5	0.1599999964237213	7	\N	351	2026-01-31 22:50:09.841
352	1	1	55.1067891	82.9523263	2026-01-31 21:15:53.956	MOVE	30.21299934387207	0	0	\N	352	2026-01-31 22:50:09.841
353	1	1	55.106742	82.9523335	2026-01-31 21:16:13.316	MOVE	43.63700103759766	0.3515543937683105	143.4240112304688	\N	353	2026-01-31 22:50:09.841
354	1	1	55.1069302	82.9511784	2026-01-31 21:16:29.202	MOVE	115.5	0	0	\N	354	2026-01-31 22:50:09.841
355	1	1	55.1067705	82.9522556	2026-01-31 21:16:48.283	MOVE	22.29800033569336	0	0	\N	355	2026-01-31 22:50:09.841
356	1	1	55.106939	82.9519637	2026-01-31 21:17:29.059	MOVE	104	1.429999947547913	261	\N	356	2026-01-31 22:50:09.841
357	1	1	55.1067689	82.9522691	2026-01-31 21:17:46.444	MOVE	20.89900016784668	0	0	\N	357	2026-01-31 22:50:09.841
358	1	1	55.1067925	82.9521832	2026-01-31 21:18:12.016	MOVE	25.95899963378906	1.910335302352905	286.7178344726562	\N	358	2026-01-31 22:50:09.841
359	1	1	55.1071783	82.9498887	2026-01-31 21:18:29.047	MOVE	143.5	0	0	\N	359	2026-01-31 22:50:09.841
360	1	1	55.1067786	82.952262	2026-01-31 21:18:46.196	MOVE	19.26000022888184	0	0	\N	360	2026-01-31 22:50:09.841
361	1	1	55.1069224	82.9515628	2026-01-31 21:19:30.056	MOVE	184.5	0	0	\N	361	2026-01-31 22:50:09.841
362	1	1	55.1067702	82.9522489	2026-01-31 21:19:47.402	MOVE	33.5629997253418	0	0	\N	362	2026-01-31 22:50:09.841
363	1	1	55.1067736	82.9521669	2026-01-31 21:20:12.098	MOVE	26.53300094604492	2.834284067153931	264.6310424804688	\N	363	2026-01-31 22:50:09.841
364	1	1	55.1069071	82.9524141	2026-01-31 21:20:29.049	MOVE	79.5	2.139999866485596	89	\N	364	2026-01-31 22:50:09.841
365	1	1	55.1067712	82.9522562	2026-01-31 21:20:47.174	MOVE	31.91300010681152	0	0	\N	365	2026-01-31 22:50:09.841
366	1	1	55.1068313	82.9525646	2026-01-31 21:21:11.998	MOVE	41.02999877929688	2.89188289642334	78.20439147949219	\N	366	2026-01-31 22:50:09.841
367	1	1	55.1068409	82.9522299	2026-01-31 21:21:29.047	MOVE	56	2.009999990463257	246	\N	367	2026-01-31 22:50:09.841
368	1	1	55.1067705	82.9522333	2026-01-31 21:21:54.556	MOVE	33.26599884033203	0	0	\N	368	2026-01-31 22:50:09.841
369	1	1	55.1068583	82.9527048	2026-01-31 21:22:29.143	MOVE	98	3.973542451858521	179.8062896728516	\N	369	2026-01-31 22:50:09.841
370	1	1	55.1068055	82.9527683	2026-01-31 21:22:31.67	MOVE	148.5350036621094	3.965963840484619	177.4762573242188	\N	370	2026-01-31 22:50:09.841
371	1	1	55.1067691	82.9522317	2026-01-31 21:22:53.844	MOVE	32.61600112915039	0	0	\N	371	2026-01-31 22:50:09.841
372	1	1	55.1068721	82.9520891	2026-01-31 21:23:59.037	MOVE	54	0.8799999952316284	79	\N	372	2026-01-31 22:50:09.841
373	1	1	55.1067687	82.952229	2026-01-31 21:24:24.27	MOVE	33.12300109863281	0	0	\N	373	2026-01-31 22:50:09.841
374	1	1	55.1067502	82.9526948	2026-01-31 21:24:59.039	MOVE	176.5	0	0	\N	374	2026-01-31 22:50:09.841
375	1	1	55.1067623	82.9522283	2026-01-31 21:25:12.637	MOVE	32.31600189208984	0.2769454121589661	272.6060485839844	\N	375	2026-01-31 22:50:09.841
376	1	1	55.1068154	82.9531419	2026-01-31 21:25:29.035	MOVE	67	2.25	257	\N	376	2026-01-31 22:50:09.841
377	1	1	55.1067678	82.9522211	2026-01-31 21:25:47.228	MOVE	32.8380012512207	0	0	\N	377	2026-01-31 22:50:09.841
378	1	1	55.1068367	82.9523493	2026-01-31 21:26:29.055	MOVE	104.5	0.7799999713897705	43	\N	378	2026-01-31 22:50:09.841
379	1	1	55.1067749	82.9522627	2026-01-31 21:26:46.271	MOVE	17.76600074768066	0	0	\N	379	2026-01-31 22:50:09.841
380	1	1	55.1069151	82.9520776	2026-01-31 21:27:29.065	MOVE	141.5	2.970000028610229	292	\N	380	2026-01-31 22:50:09.841
381	1	1	55.1067629	82.9522724	2026-01-31 21:27:46.237	MOVE	21.5049991607666	0	0	\N	381	2026-01-31 22:50:09.841
382	1	1	55.1068624	82.952681	2026-01-31 21:28:03.368	MOVE	142.2330017089844	0.2405522912740707	162.8533172607422	\N	382	2026-01-31 22:50:09.841
383	1	1	55.1067777	82.9522237	2026-01-31 21:28:20.461	MOVE	24.90999984741211	0	0	\N	383	2026-01-31 22:50:09.841
384	1	1	55.1068882	82.9520354	2026-01-31 21:28:37.585	MOVE	36.86199951171875	3.024530172348022	282.1612854003906	\N	384	2026-01-31 22:50:09.841
385	1	1	55.1067755	82.9522541	2026-01-31 21:28:54.684	MOVE	34.14799880981445	0	0	\N	385	2026-01-31 22:50:09.841
386	1	1	55.1067913	82.9523387	2026-01-31 21:29:12.718	MOVE	37.86100006103516	0.7776498794555664	96.59622955322266	\N	386	2026-01-31 22:50:09.841
387	1	1	55.1069233	82.9520574	2026-01-31 21:29:29.04	MOVE	84	1.199999928474426	289	\N	387	2026-01-31 22:50:09.841
388	1	1	55.1067831	82.9522575	2026-01-31 21:29:46.863	MOVE	19.23200035095215	0	0	\N	388	2026-01-31 22:50:09.841
389	1	1	55.1068217	82.9531753	2026-01-31 21:29:55.038	MOVE	34	6.382963180541992	97.9723129272461	\N	389	2026-01-31 22:50:09.841
390	1	1	55.1068078	82.9521968	2026-01-31 21:30:12.088	MOVE	39.54000091552734	0	0	\N	390	2026-01-31 22:50:09.841
391	1	1	55.1067955	82.9524266	2026-01-31 21:30:29.056	MOVE	68.5	0.6100000143051147	248	\N	391	2026-01-31 22:50:09.841
392	1	1	55.1067779	82.9522457	2026-01-31 21:30:52.333	MOVE	24.83499908447266	0	0	\N	392	2026-01-31 22:50:09.841
393	1	1	55.1068293	82.9521652	2026-01-31 21:31:30.749	MOVE	39.19800186157227	0	0	\N	393	2026-01-31 22:50:09.841
394	1	1	55.1067695	82.952243	2026-01-31 21:32:12.138	MOVE	23.86700057983398	1.168464183807373	275.6223754882812	\N	394	2026-01-31 22:50:09.841
395	1	1	55.106823	82.9527704	2026-01-31 21:32:29.034	MOVE	75.5	4.579999923706055	115	\N	395	2026-01-31 22:50:09.841
396	1	1	55.1067721	82.9522538	2026-01-31 21:32:46.297	MOVE	24.65999984741211	0	0	\N	396	2026-01-31 22:50:09.841
397	1	1	55.1069199	82.9524022	2026-01-31 21:33:03.443	MOVE	139.8950042724609	0.3626612424850464	281.6491394042969	\N	397	2026-01-31 22:50:09.841
398	1	1	55.1067764	82.9522675	2026-01-31 21:33:22.136	MOVE	32.86399841308594	0	0	\N	398	2026-01-31 22:50:09.841
399	1	1	55.1069393	82.9521247	2026-01-31 21:33:59.049	MOVE	75.5	2.230000019073486	307	\N	399	2026-01-31 22:50:09.841
400	1	1	55.1067854	82.9522272	2026-01-31 21:34:23.92	MOVE	24.62899971008301	0	0	\N	400	2026-01-31 22:50:09.841
401	1	1	55.1068396	82.9521407	2026-01-31 21:34:42.965	MOVE	45.84700012207031	1.316002488136292	298.7369689941406	\N	401	2026-01-31 22:50:09.841
402	1	1	55.1067698	82.9522992	2026-01-31 21:34:59.18	MOVE	76.5	0.1299999952316284	259	\N	402	2026-01-31 22:50:09.841
403	1	1	55.1068211	82.9521782	2026-01-31 21:35:23.982	MOVE	38.67200088500977	0	0	\N	403	2026-01-31 22:50:09.841
404	1	1	55.1067828	82.9522483	2026-01-31 21:35:45.19	MOVE	35.57400131225586	0	0	\N	404	2026-01-31 22:50:09.841
405	1	1	55.1065368	82.9546361	2026-01-31 21:36:01.219	MOVE	225.5	0	0	\N	405	2026-01-31 22:50:09.841
406	1	1	55.1068211	82.952189	2026-01-31 21:36:20.479	MOVE	45.95500183105469	0	0	\N	406	2026-01-31 22:50:09.841
407	1	1	55.1067917	82.9520545	2026-01-31 21:36:35.179	MOVE	241	0.4084185063838959	249.1188812255859	\N	407	2026-01-31 22:50:09.841
408	1	1	55.1068537	82.9519737	2026-01-31 21:36:58.742	MOVE	46.74200057983398	0	0	\N	408	2026-01-31 22:50:09.841
409	1	1	55.1068418	82.9520603	2026-01-31 21:37:16.022	MOVE	222	1.879999995231628	107	\N	409	2026-01-31 22:50:09.841
410	1	1	55.1067768	82.9522561	2026-01-31 21:37:42.94	MOVE	33.95800018310547	0	0	\N	410	2026-01-31 22:50:09.841
411	1	1	55.1068337	82.9520975	2026-01-31 21:38:00.236	MOVE	25.71100044250488	0	0	\N	411	2026-01-31 22:50:09.841
412	1	1	55.1067772	82.9522362	2026-01-31 21:38:18.134	MOVE	48.02199935913086	0	0	\N	412	2026-01-31 22:50:09.841
413	1	1	55.1068525	82.9519691	2026-01-31 21:38:36.146	MOVE	47.7130012512207	0	0	\N	413	2026-01-31 22:50:09.841
414	1	1	55.1070187	82.9520318	2026-01-31 21:38:55.184	MOVE	106	6.922497272491455	300.5018615722656	\N	414	2026-01-31 22:50:09.841
415	1	1	55.1067797	82.9522305	2026-01-31 21:39:14.063	MOVE	24.96100044250488	0	0	\N	415	2026-01-31 22:50:09.841
416	1	1	55.1069927	82.9520892	2026-01-31 21:39:29.023	MOVE	94	5.656423091888428	312.0486450195312	\N	416	2026-01-31 22:50:09.841
417	1	1	55.1068669	82.9521169	2026-01-31 21:39:42.13	MOVE	35.44300079345703	4.3858642578125	311.1703491210938	\N	417	2026-01-31 22:50:09.841
418	1	1	55.1067656	82.9522501	2026-01-31 21:40:00.123	MOVE	24.59799957275391	0	0	\N	418	2026-01-31 22:50:09.841
419	1	1	55.1068182	82.952185	2026-01-31 21:40:17.427	MOVE	45.95500183105469	0	0	\N	419	2026-01-31 22:50:09.841
420	1	1	55.1067826	82.9523008	2026-01-31 21:40:42.632	MOVE	33.15000152587891	0.4049935340881348	220.4376525878906	\N	420	2026-01-31 22:50:09.841
421	1	1	55.1068693	82.9526578	2026-01-31 21:40:59.029	MOVE	60	1.730000019073486	55	\N	421	2026-01-31 22:50:09.841
422	1	1	55.1068007	82.9522092	2026-01-31 21:41:17.161	MOVE	37.84400177001953	0	0	\N	422	2026-01-31 22:50:09.841
423	1	1	55.1068566	82.9523969	2026-01-31 21:41:59.13	MOVE	66	0.9699999690055847	255	\N	423	2026-01-31 22:50:09.841
424	1	1	55.106788	82.9522201	2026-01-31 21:42:18.321	MOVE	24.62199974060059	0	0	\N	424	2026-01-31 22:50:09.841
425	1	1	55.1069882	82.9524228	2026-01-31 21:42:59.02	MOVE	62	1.299999952316284	290	\N	425	2026-01-31 22:50:09.841
426	1	1	55.1068012	82.9521978	2026-01-31 21:43:24.869	MOVE	25.24099922180176	0	0	\N	426	2026-01-31 22:50:09.841
427	1	1	55.1067986	82.9523079	2026-01-31 21:44:12.647	MOVE	23.11800003051758	1.731010913848877	45.17999649047852	\N	427	2026-01-31 22:50:09.841
428	1	1	55.1069016	82.9525629	2026-01-31 21:44:29.032	MOVE	121	0.4899999797344208	261	\N	428	2026-01-31 22:50:09.841
429	1	1	55.1067775	82.9522481	2026-01-31 21:44:47.107	MOVE	24.47699928283691	0	0	\N	429	2026-01-31 22:50:09.841
430	1	1	55.1068148	82.9521746	2026-01-31 21:45:12.223	MOVE	46.4640007019043	1.557939291000366	231.3957824707031	\N	430	2026-01-31 22:50:09.841
431	1	1	55.1069048	82.952343	2026-01-31 21:45:28.998	MOVE	103	1.909999966621399	220	\N	431	2026-01-31 22:50:09.841
432	1	1	55.1067753	82.952253	2026-01-31 21:45:46.699	MOVE	24.28800010681152	0	0	\N	432	2026-01-31 22:50:09.841
433	1	1	55.1068401	82.9520785	2026-01-31 21:46:29.313	MOVE	48.49800109863281	0	0	\N	433	2026-01-31 22:50:09.841
434	1	1	55.1068148	82.9521963	2026-01-31 21:47:28.17	MOVE	45.49300003051758	0	0	\N	434	2026-01-31 22:50:09.841
435	1	1	55.1067769	82.9522569	2026-01-31 21:47:45.58	MOVE	34.26800155639648	0	0	\N	435	2026-01-31 22:50:09.841
436	1	1	55.1070358	82.9528002	2026-01-31 21:48:02.011	MOVE	185.5	0.699999988079071	294	\N	436	2026-01-31 22:50:09.841
437	1	1	55.1067906	82.9522258	2026-01-31 21:48:20.379	MOVE	24.69700050354004	0	0	\N	437	2026-01-31 22:50:09.841
438	1	1	55.106831	82.9521502	2026-01-31 21:48:42.917	MOVE	52.59199905395508	0.6345760822296143	134.5877838134766	\N	438	2026-01-31 22:50:09.841
439	1	1	55.1069323	82.9519712	2026-01-31 21:49:00.013	MOVE	72	0.4399999976158142	323	\N	439	2026-01-31 22:50:09.841
440	1	1	55.1067888	82.9522121	2026-01-31 21:49:24.882	MOVE	49.51300048828125	0	0	\N	440	2026-01-31 22:50:09.841
441	1	1	55.1068951	82.9526764	2026-01-31 21:50:00.193	MOVE	84.5	2.819999933242798	295	\N	441	2026-01-31 22:50:09.841
442	1	1	55.1068529	82.9519712	2026-01-31 21:50:19.205	MOVE	46.73400115966797	0	0	\N	442	2026-01-31 22:50:09.841
443	1	1	55.1067806	82.9522372	2026-01-31 21:50:42.891	MOVE	24.45800018310547	1.412545442581177	149.0993957519531	\N	443	2026-01-31 22:50:09.841
444	1	1	55.1070021	82.9520463	2026-01-31 21:50:58.998	MOVE	56.5	1.110000014305115	92	\N	444	2026-01-31 22:50:09.841
445	1	1	55.1068334	82.9521043	2026-01-31 21:51:17.413	MOVE	25.76600074768066	0	0	\N	445	2026-01-31 22:50:09.841
446	1	1	55.1067707	82.95229	2026-01-31 21:51:43.85	MOVE	25.31100082397461	0.8365007638931274	123.5787353515625	\N	446	2026-01-31 22:50:09.841
447	1	1	55.106858	82.9522413	2026-01-31 21:51:59.168	MOVE	72	1.019999980926514	296	\N	447	2026-01-31 22:50:09.841
448	1	1	55.1067664	82.952263	2026-01-31 21:52:15.914	MOVE	21.92700004577637	0	0	\N	448	2026-01-31 22:50:09.841
449	1	1	55.1067784	82.952361	2026-01-31 21:52:44.07	MOVE	30.87100028991699	0	0	\N	449	2026-01-31 22:50:09.841
450	1	1	55.1068475	82.9524662	2026-01-31 21:52:59.019	MOVE	75.5	3.42303466796875	80.9306869506836	\N	450	2026-01-31 22:50:09.841
451	1	1	55.1067805	82.9522567	2026-01-31 21:53:18.248	MOVE	18.79199981689453	0	0	\N	451	2026-01-31 22:50:09.841
452	1	1	55.1067638	82.9523379	2026-01-31 21:53:42.662	MOVE	33.37799835205078	2.144781589508057	122.5307464599609	\N	452	2026-01-31 22:50:09.841
453	1	1	55.1068923	82.9518463	2026-01-31 21:53:59.009	MOVE	77.5	0.1899999976158142	121	\N	453	2026-01-31 22:50:09.841
454	1	1	55.1067779	82.9522415	2026-01-31 21:54:16.682	MOVE	21.57299995422363	0	0	\N	454	2026-01-31 22:50:09.841
455	1	1	55.1069559	82.9521287	2026-01-31 21:54:59.811	MOVE	137.6069946289062	0.172423928976059	109.6708755493164	\N	455	2026-01-31 22:50:09.841
456	1	1	55.1067723	82.9522271	2026-01-31 21:55:16.85	MOVE	27.66699981689453	0	0	\N	456	2026-01-31 22:50:09.841
457	1	1	55.1068247	82.9521482	2026-01-31 21:55:41.986	MOVE	34.38199996948242	0.8463951945304871	303.718505859375	\N	457	2026-01-31 22:50:09.841
458	1	1	55.1068662	82.9524801	2026-01-31 21:55:59.005	MOVE	67.5	0.550000011920929	233	\N	458	2026-01-31 22:50:09.841
459	1	1	55.1067814	82.9522363	2026-01-31 21:56:18.129	MOVE	21.72699928283691	0	0	\N	459	2026-01-31 22:50:09.841
460	1	1	55.1069336	82.9522602	2026-01-31 21:57:28.967	MOVE	65	0.8499999642372131	253	\N	460	2026-01-31 22:50:09.841
461	1	1	55.1067583	82.9522716	2026-01-31 21:57:47.424	MOVE	24.22900009155273	0	0	\N	461	2026-01-31 22:50:09.841
462	1	1	55.1068914	82.9520004	2026-01-31 21:58:29.008	MOVE	57	0.5699999928474426	319	\N	462	2026-01-31 22:50:09.841
463	1	1	55.106783	82.9522866	2026-01-31 21:58:48.135	MOVE	52.30899810791016	0	0	\N	463	2026-01-31 22:50:09.841
464	1	1	55.1068416	82.9527173	2026-01-31 21:59:29.993	MOVE	77.5	1.870000004768372	115	\N	464	2026-01-31 22:50:09.841
465	1	1	55.1067654	82.9522759	2026-01-31 21:59:48.356	MOVE	26.18099975585938	0	0	\N	465	2026-01-31 22:50:09.841
466	1	1	55.1068429	82.952698	2026-01-31 22:00:28.979	MOVE	70	1.079999923706055	270	\N	466	2026-01-31 22:50:09.841
467	1	1	55.1067984	82.9522178	2026-01-31 22:00:47.145	MOVE	25.27000045776367	0	0	\N	467	2026-01-31 22:50:09.841
468	1	1	55.1068807	82.9523757	2026-01-31 22:01:28.978	MOVE	95	1.339999914169312	84	\N	468	2026-01-31 22:50:09.841
469	1	1	55.1067786	82.9522737	2026-01-31 22:01:46.422	MOVE	27.49399948120117	0	0	\N	469	2026-01-31 22:50:09.841
470	1	1	55.1068061	82.9524144	2026-01-31 22:02:00.145	MOVE	127.5	0.6179111003875732	270.0040893554688	\N	470	2026-01-31 22:50:09.841
471	1	1	55.1067717	82.9522346	2026-01-31 22:02:12.737	MOVE	23.52499961853027	0.692289412021637	269.7947082519531	\N	471	2026-01-31 22:50:09.841
472	1	1	55.1069519	82.9520174	2026-01-31 22:02:29.967	MOVE	78.5	2.169999837875366	277	\N	472	2026-01-31 22:50:09.841
473	1	1	55.1068639	82.9529727	2026-01-31 22:02:47.98	MOVE	44	0.4399999976158142	120	\N	473	2026-01-31 22:50:09.841
474	1	1	55.1067791	82.9522145	2026-01-31 22:03:14.829	MOVE	26.98399925231934	0	0	\N	474	2026-01-31 22:50:09.841
475	1	1	55.1067858	82.9526011	2026-01-31 22:03:30.132	MOVE	87	0.5699999928474426	313	\N	475	2026-01-31 22:50:09.841
476	1	1	55.1067844	82.952295	2026-01-31 22:03:45.858	MOVE	45.37900161743164	0	0	\N	476	2026-01-31 22:50:09.841
477	1	1	55.1070136	82.9518713	2026-01-31 22:04:00.056	MOVE	60.5	4.735273838043213	314.00341796875	\N	477	2026-01-31 22:50:09.841
478	1	1	55.1067866	82.9523075	2026-01-31 22:04:15.505	MOVE	38.07799911499023	0	0	\N	478	2026-01-31 22:50:09.841
479	1	1	55.1066182	82.9526928	2026-01-31 22:04:30.141	MOVE	125.5	1.499178647994995	127.3829193115234	\N	479	2026-01-31 22:50:09.841
480	1	1	55.1067809	82.9522621	2026-01-31 22:04:44.165	MOVE	42.10100173950195	2.191009759902954	303.329833984375	\N	480	2026-01-31 22:50:09.841
481	1	1	55.1068248	82.95257	2026-01-31 22:05:28.134	MOVE	46	0.1604227125644684	128.7150115966797	\N	481	2026-01-31 22:50:09.841
482	1	1	55.1068828	82.9522523	2026-01-31 22:05:54.991	MOVE	47.5	0.6065582633018494	160.2215881347656	\N	482	2026-01-31 22:50:09.841
483	1	1	55.1068016	82.9528658	2026-01-31 22:06:23.962	MOVE	33	0.9599999785423279	255	\N	483	2026-01-31 22:50:09.841
484	1	1	55.1067647	82.9530174	2026-01-31 22:06:24.995	MOVE	37.17800140380859	1.167115807533264	259.5088806152344	\N	484	2026-01-31 22:50:09.841
485	1	1	55.1067781	82.9522815	2026-01-31 22:06:51.87	MOVE	35.67200088500977	0	0	\N	485	2026-01-31 22:50:09.841
486	1	1	55.106981	82.9518868	2026-01-31 22:08:00.105	MOVE	70.5	0.6599999666213989	281	\N	486	2026-01-31 22:50:09.841
487	1	1	55.1067689	82.9522438	2026-01-31 22:08:22.099	MOVE	34.13399887084961	0	0	\N	487	2026-01-31 22:50:09.841
488	1	1	55.106854	82.9523552	2026-01-31 22:08:51.132	MOVE	48.5	0.3700000047683716	321	\N	488	2026-01-31 22:50:09.841
489	1	1	55.1068529	82.9521672	2026-01-31 22:09:18.98	MOVE	48.5	2.690000057220459	130	\N	489	2026-01-31 22:50:09.841
490	1	1	55.1067678	82.9522278	2026-01-31 22:09:47.829	MOVE	32.86000061035156	0	0	\N	490	2026-01-31 22:50:09.841
491	1	1	55.1068105	82.952448	2026-01-31 22:10:28.973	MOVE	72.5	0.4058351814746857	267.0191650390625	\N	491	2026-01-31 22:50:09.841
492	1	1	55.1069469	82.9522183	2026-01-31 22:10:49.099	MOVE	45.5	4.630000114440918	301	\N	492	2026-01-31 22:50:09.841
493	1	1	55.1070031	82.9518183	2026-01-31 22:10:55.944	MOVE	32.44499969482422	3.342524290084839	302.9568786621094	\N	493	2026-01-31 22:50:09.841
494	1	1	55.1067639	82.952251	2026-01-31 22:11:23.847	MOVE	33.66799926757812	0	0	\N	494	2026-01-31 22:50:09.841
495	1	1	55.1068062	82.9521364	2026-01-31 22:13:11.206	MOVE	33.79600143432617	1.669740796089172	289.2818603515625	\N	495	2026-01-31 22:50:09.841
496	1	1	55.1069146	82.9523325	2026-01-31 22:13:28.954	MOVE	82.5	1.949999928474426	300	\N	496	2026-01-31 22:50:09.841
497	1	1	55.1067706	82.9522721	2026-01-31 22:13:46.081	MOVE	17.17499923706055	0	0	\N	497	2026-01-31 22:50:09.841
498	1	1	55.1069052	82.9524693	2026-01-31 22:14:57.951	MOVE	48	1.629999995231628	277	\N	498	2026-01-31 22:50:09.841
499	1	1	55.1068934	82.9523439	2026-01-31 22:15:18.113	MOVE	47.5	1.069999933242798	141	\N	499	2026-01-31 22:50:09.841
500	1	1	55.1067637	82.9522081	2026-01-31 22:15:53.306	MOVE	32.98600006103516	0	0	\N	500	2026-01-31 22:50:09.841
501	1	1	55.1067537	82.9528079	2026-01-31 22:17:55.958	MOVE	45.5	3.781919717788696	132.8638763427734	\N	501	2026-01-31 22:50:09.841
502	1	1	55.1067786	82.952212	2026-01-31 22:18:11.62	MOVE	27.01399993896484	0	0	\N	502	2026-01-31 22:50:09.841
503	1	1	55.1069441	82.9517497	2026-01-31 22:18:27.938	MOVE	49.5	2.740000009536743	287	\N	503	2026-01-31 22:50:09.841
504	1	1	55.1067713	82.9522224	2026-01-31 22:18:47.049	MOVE	26.57099914550781	0	0	\N	504	2026-01-31 22:50:09.841
505	1	1	55.1068522	82.9526091	2026-01-31 22:19:29.945	MOVE	51.5	2.409999847412109	287	\N	505	2026-01-31 22:50:09.841
506	1	1	55.1067798	82.9522217	2026-01-31 22:19:54.814	MOVE	26.17099952697754	0	0	\N	506	2026-01-31 22:50:09.841
507	1	1	55.1069812	82.9519036	2026-01-31 22:20:58.925	MOVE	54.5	0.3581851720809937	143.9461975097656	\N	507	2026-01-31 22:50:09.841
508	1	1	55.1068468	82.9520404	2026-01-31 22:21:19.906	MOVE	49.5	4.003366470336914	325.8785705566406	\N	508	2026-01-31 22:50:09.841
509	1	1	55.1070841	82.9517469	2026-01-31 22:21:31.34	MOVE	169.1940002441406	2.712022066116333	322.9872741699219	\N	509	2026-01-31 22:50:09.841
510	1	1	55.1067777	82.9522297	2026-01-31 22:21:54.848	MOVE	26.48800086975098	0	0	\N	510	2026-01-31 22:50:09.841
511	1	1	55.1067382	82.95278	2026-01-31 22:22:29.928	MOVE	67.5	0.25	108	\N	511	2026-01-31 22:50:09.841
512	1	1	55.1067665	82.9522107	2026-01-31 22:22:54.787	MOVE	32.90399932861328	0	0	\N	512	2026-01-31 22:50:09.841
513	1	1	55.1068318	82.9526493	2026-01-31 22:24:00.098	MOVE	46.5	0.7999999523162842	101	\N	513	2026-01-31 22:50:09.841
514	1	1	55.1067647	82.9522499	2026-01-31 22:24:24.238	MOVE	23.47800064086914	0	0	\N	514	2026-01-31 22:50:09.841
515	1	1	55.1068283	82.9521382	2026-01-31 22:24:59.219	MOVE	25.49799919128418	0	0	\N	515	2026-01-31 22:50:09.841
516	1	1	55.1067812	82.9522201	2026-01-31 22:25:16.351	MOVE	36.4119987487793	0	0	\N	516	2026-01-31 22:50:09.841
517	1	1	55.1067453	82.952593	2026-01-31 22:25:30.053	MOVE	211	1.230555534362793	99.55953979492188	\N	517	2026-01-31 22:50:09.841
518	1	1	55.1067072	82.9529878	2026-01-31 22:25:33.499	MOVE	279.906005859375	5.109315872192383	99.55953979492188	\N	518	2026-01-31 22:50:09.841
519	1	1	55.1067914	82.9521994	2026-01-31 22:25:50.559	MOVE	26.21100044250488	0	0	\N	519	2026-01-31 22:50:09.841
520	1	1	55.1068159	82.9526656	2026-01-31 22:26:29.071	MOVE	47	0.3552417755126953	98.85907745361328	\N	520	2026-01-31 22:50:09.841
521	1	1	55.1067603	82.9522484	2026-01-31 22:26:49.592	MOVE	23.4689998626709	0	0	\N	521	2026-01-31 22:50:09.841
522	1	1	55.1068423	82.9525837	2026-01-31 22:27:31.997	MOVE	107.1949996948242	0.8259707689285278	76.26590728759766	\N	522	2026-01-31 22:50:09.841
523	1	1	55.1067787	82.9523337	2026-01-31 22:27:50.21	MOVE	24.26399993896484	0	0	\N	523	2026-01-31 22:50:09.841
524	1	1	55.1067953	82.9522377	2026-01-31 22:28:16.91	MOVE	20.22400093078613	1.005305051803589	312.1269226074219	\N	524	2026-01-31 22:50:09.841
525	1	1	55.1068307	82.9525086	2026-01-31 22:28:32.218	MOVE	64.5	1.5	281	\N	525	2026-01-31 22:50:09.841
526	1	1	55.1067932	82.9521941	2026-01-31 22:28:57.946	MOVE	36.44100189208984	0	0	\N	526	2026-01-31 22:50:09.841
527	1	1	55.1067766	82.9522932	2026-01-31 22:29:45.115	MOVE	31.76600074768066	0.6453158259391785	254.8596649169922	\N	527	2026-01-31 22:50:09.841
528	1	1	55.1067787	82.9522127	2026-01-31 22:30:31.914	MOVE	26.67099952697754	0	0	\N	528	2026-01-31 22:50:09.841
529	1	1	55.1068462	82.9524036	2026-01-31 22:30:48.056	MOVE	77.5	13.47999954223633	282	\N	529	2026-01-31 22:50:09.841
530	1	1	55.1067757	82.9522593	2026-01-31 22:31:07.193	MOVE	17.69899940490723	0	0	\N	530	2026-01-31 22:50:09.841
531	1	1	55.1068567	82.9524127	2026-01-31 22:32:47.053	MOVE	86.5	0.119999997317791	255	\N	531	2026-01-31 22:50:09.841
532	1	1	55.1067856	82.9522213	2026-01-31 22:33:05.011	MOVE	26.06800079345703	0	0	\N	532	2026-01-31 22:50:09.841
533	1	1	55.106736	82.9523817	2026-01-31 22:33:31.046	MOVE	32.18399810791016	2.416833639144897	135.6782684326172	\N	533	2026-01-31 22:50:09.841
534	1	1	55.1068737	82.9525767	2026-01-31 22:33:47.056	MOVE	118.5	1.96999990940094	257	\N	534	2026-01-31 22:50:09.841
535	1	1	55.1067756	82.9522587	2026-01-31 22:34:05.177	MOVE	17.93000030517578	0	0	\N	535	2026-01-31 22:50:09.841
536	1	1	55.1067156	82.952436	2026-01-31 22:34:22.286	MOVE	182.1490020751953	3.073693513870239	203.4781951904297	\N	536	2026-01-31 22:50:09.841
537	1	1	55.1067734	82.9522803	2026-01-31 22:34:39.413	MOVE	17.79199981689453	0	0	\N	537	2026-01-31 22:50:09.841
538	1	1	55.1068097	82.9527582	2026-01-31 22:35:17.045	MOVE	111	1.659999966621399	140	\N	538	2026-01-31 22:50:09.841
539	1	1	55.1067639	82.9522249	2026-01-31 22:35:34.449	MOVE	33.67200088500977	0	0	\N	539	2026-01-31 22:50:09.841
540	1	1	55.1068374	82.9526792	2026-01-31 22:35:51.562	MOVE	142.3600006103516	1.050590753555298	189.9909973144531	\N	540	2026-01-31 22:50:09.841
541	1	1	55.106765	82.9522176	2026-01-31 22:36:09.172	MOVE	32.74200057983398	0	0	\N	541	2026-01-31 22:50:09.841
542	1	1	55.1068336	82.9519232	2026-01-31 22:37:00.035	MOVE	33.14199829101562	7.143816947937012	286.6275939941406	\N	542	2026-01-31 22:50:09.841
543	1	1	55.1068348	82.9526058	2026-01-31 22:37:17.062	MOVE	56.5	0.1599999964237213	293	\N	543	2026-01-31 22:50:09.841
544	1	1	55.1067604	82.9522168	2026-01-31 22:37:40.905	MOVE	34.00199890136719	0	0	\N	544	2026-01-31 22:50:09.841
545	1	1	55.1068559	82.9521843	2026-01-31 22:38:17.208	MOVE	91	5.190000057220459	304	\N	545	2026-01-31 22:50:09.841
546	1	1	55.1067614	82.952216	2026-01-31 22:38:37.164	MOVE	34.00199890136719	0	0	\N	546	2026-01-31 22:50:09.841
547	1	1	55.1067552	82.9523101	2026-01-31 22:39:00.656	MOVE	17.66900062561035	3.726525068283081	137.1744995117188	\N	547	2026-01-31 22:50:09.841
548	1	1	55.1068759	82.9522373	2026-01-31 22:39:18.053	MOVE	76	5.539999961853027	122	\N	548	2026-01-31 22:50:09.841
549	1	1	55.1067795	82.952276	2026-01-31 22:39:35.216	MOVE	16.8700008392334	0	0	\N	549	2026-01-31 22:50:09.841
550	1	1	55.1069545	82.9521195	2026-01-31 22:40:17.042	MOVE	86	6.559999942779541	124	\N	550	2026-01-31 22:50:09.841
551	1	1	55.1067657	82.9522194	2026-01-31 22:40:35.435	MOVE	32.62900161743164	0	0	\N	551	2026-01-31 22:50:09.841
552	1	1	55.1067777	82.9521147	2026-01-31 22:42:31.903	MOVE	34.12900161743164	4.019913673400879	270.8586120605469	\N	552	2026-01-31 22:50:09.841
553	1	1	55.1068227	82.9524331	2026-01-31 22:42:48.04	MOVE	92.5	1.709999918937683	257	\N	553	2026-01-31 22:50:09.841
554	1	1	55.1067748	82.9522705	2026-01-31 22:43:06.45	MOVE	17.94300079345703	0	0	\N	554	2026-01-31 22:50:09.841
555	1	1	55.1068593	82.9522023	2026-01-31 22:43:47.193	MOVE	98.5	4.309999942779541	266	\N	555	2026-01-31 22:50:09.841
556	1	1	55.1067773	82.9522126	2026-01-31 22:44:06.113	MOVE	27.42600059509277	0	0	\N	556	2026-01-31 22:50:09.841
557	1	1	55.1069103	82.9522311	2026-01-31 22:44:48.029	MOVE	68.5	6.75	283	\N	557	2026-01-31 22:50:09.841
558	1	1	55.1067665	82.9522338	2026-01-31 22:45:05.823	MOVE	32.14500045776367	0	0	\N	558	2026-01-31 22:50:09.841
559	1	1	55.1068048	82.9522767	2026-01-31 22:45:31.992	MOVE	27.97999954223633	0.5978361964225769	104.1379547119141	\N	559	2026-01-31 22:50:09.841
560	1	1	55.10683	82.9526877	2026-01-31 22:45:48.026	MOVE	73	0.4099999964237213	268	\N	560	2026-01-31 22:50:09.841
561	1	1	55.106809	82.9522288	2026-01-31 22:46:06.464	MOVE	21.95899963378906	0	0	\N	561	2026-01-31 22:50:09.841
562	1	1	55.1069686	82.952169	2026-01-31 22:46:49.018	MOVE	200	1.559999942779541	92	\N	562	2026-01-31 22:50:09.841
563	1	1	55.1067801	82.9522643	2026-01-31 22:47:12.898	MOVE	27.07500076293945	0	0	\N	563	2026-01-31 22:50:09.841
564	1	1	55.1068051	82.9520493	2026-01-31 22:47:33.197	MOVE	45.09799957275391	0.1529329568147659	210.0837097167969	\N	564	2026-01-31 22:50:09.841
565	1	1	55.106898	82.9527343	2026-01-31 22:47:50.021	MOVE	118	0	0	\N	565	2026-01-31 22:50:09.841
566	1	1	55.1068089	82.9522368	2026-01-31 22:48:09.148	MOVE	21.2859992980957	0	0	\N	566	2026-01-31 22:50:09.841
567	1	1	55.1068342	82.952129	2026-01-31 22:49:20.19	MOVE	172	1.151564359664917	140.07275390625	\N	567	2026-01-31 22:50:09.841
568	1	1	55.1068126	82.952217	2026-01-31 22:49:41.934	MOVE	45.24499893188477	0	0	\N	568	2026-01-31 22:50:09.841
569	1	1	55.10691	82.9521436	2026-01-31 22:49:58.195	MOVE	131	0.1347115635871887	0.1338835209608078	\N	569	2026-01-31 22:50:09.841
570	1	1	55.1067916	82.9522424	2026-01-31 22:50:10.385	MOVE	18.88599967956543	1.113676905632019	154.1900634765625	\N	570	2026-01-31 22:50:25.209
571	1	1	55.10696	82.9526397	2026-01-31 22:51:19.019	MOVE	199.5	0.7199999690055847	1	\N	571	2026-02-01 01:49:40.601
572	1	1	55.106777	82.952281	2026-01-31 22:51:37.072	MOVE	33.43299865722656	0	0	\N	572	2026-02-01 01:49:40.601
573	1	1	55.1067937	82.9521871	2026-01-31 22:52:11.394	MOVE	36.14799880981445	0	0	\N	573	2026-02-01 01:49:40.601
574	1	1	55.1068029	82.9523327	2026-01-31 22:52:46.982	MOVE	125.5	0.1930743902921677	79.98242950439453	\N	574	2026-02-01 01:49:40.601
575	1	1	55.1068076	82.9522348	2026-01-31 22:53:02.737	MOVE	21.66200065612793	0	0	\N	575	2026-02-01 01:49:40.601
576	1	1	55.106932	82.9521869	2026-01-31 22:53:17.022	MOVE	62	0.9475792050361633	96.0057144165039	\N	576	2026-02-01 01:49:40.601
577	1	1	55.1067914	82.9522408	2026-01-31 22:53:36.851	MOVE	18.72900009155273	0	0	\N	577	2026-02-01 01:49:40.601
578	1	1	55.1069109	82.9519656	2026-01-31 22:53:59.615	MOVE	42.52799987792969	1.716794490814209	290.6241149902344	\N	578	2026-02-01 01:49:40.601
579	1	1	55.1068341	82.9527042	2026-01-31 22:54:16.532	MOVE	111.2050018310547	0.2392434775829315	209.0871429443359	\N	579	2026-02-01 01:49:40.601
580	1	1	55.1067842	82.9521992	2026-01-31 22:54:33.527	MOVE	35.48899841308594	0	0	\N	580	2026-02-01 01:49:40.601
581	1	1	55.1068281	82.9526358	2026-01-31 22:54:50.644	MOVE	161.6159973144531	0.415934294462204	92.94194793701172	\N	581	2026-02-01 01:49:40.601
582	1	1	55.1067945	82.9522523	2026-01-31 22:55:07.653	MOVE	19.32200050354004	0	0	\N	582	2026-02-01 01:49:40.601
583	1	1	55.106963	82.9520102	2026-01-31 22:55:25.056	MOVE	211.0099945068359	1.026695609092712	282.0686950683594	\N	583	2026-02-01 01:49:40.601
584	1	1	55.1067864	82.9522027	2026-01-31 22:55:43.903	MOVE	36.16500091552734	0	0	\N	584	2026-02-01 01:49:40.601
585	1	1	55.1068065	82.9526885	2026-01-31 22:56:17.009	MOVE	74.5	3.857729434967041	277.0375061035156	\N	585	2026-02-01 01:49:40.601
586	1	1	55.1068193	82.9525315	2026-01-31 22:56:20.798	MOVE	150.2449951171875	3.829438924789429	277.0862731933594	\N	586	2026-02-01 01:49:40.601
587	1	1	55.1068098	82.9522193	2026-01-31 22:56:41.916	MOVE	26.54400062561035	0	0	\N	587	2026-02-01 01:49:40.601
588	1	1	55.1068391	82.952031	2026-01-31 22:57:30.859	MOVE	45.1510009765625	0.7793310284614563	202.0410919189453	\N	588	2026-02-01 01:49:40.601
589	1	1	55.1068161	82.9526742	2026-01-31 22:57:48.02	MOVE	66.5	0.1799999922513962	281	\N	589	2026-02-01 01:49:40.601
590	1	1	55.106819	82.952229	2026-01-31 22:58:12.092	MOVE	26.28899955749512	0	0	\N	590	2026-02-01 01:49:40.601
591	1	1	55.1068299	82.9526801	2026-01-31 22:58:26.202	MOVE	76.5	8.14966106414795	87.96910095214844	\N	591	2026-02-01 01:49:40.601
592	1	1	55.106793	82.9521903	2026-01-31 22:58:46.916	MOVE	38.82300186157227	0	0	\N	592	2026-02-01 01:49:40.601
593	1	1	55.1068316	82.9522586	2026-01-31 22:59:32.991	MOVE	89.5	1.549313306808472	267.9001770019531	\N	593	2026-02-01 01:49:40.601
594	1	1	55.1068441	82.9519857	2026-01-31 23:00:19.878	MOVE	46.89500045776367	0	0	\N	594	2026-02-01 01:49:40.601
595	1	1	55.1067778	82.9521844	2026-01-31 23:00:57.734	MOVE	35.9900016784668	0	0	\N	595	2026-02-01 01:49:40.601
596	1	1	55.1068071	82.9520465	2026-01-31 23:01:19.931	MOVE	48.1510009765625	0	0	\N	596	2026-02-01 01:49:40.601
597	1	1	55.1068081	82.9521815	2026-01-31 23:01:45.696	MOVE	26.5930004119873	3.915101528167725	277.4659118652344	\N	597	2026-02-01 01:49:40.601
598	1	1	55.1068166	82.9522831	2026-01-31 23:02:45.657	MOVE	21.45100021362305	1.259389996528625	82.59488677978516	\N	598	2026-02-01 01:49:40.601
599	1	1	55.1068497	82.9526411	2026-01-31 23:03:03.022	MOVE	62.5	2.509999990463257	277	\N	599	2026-02-01 01:49:40.601
600	1	1	55.1067922	82.952236	2026-01-31 23:03:20.115	MOVE	19.91699981689453	0	0	\N	600	2026-02-01 01:49:40.601
601	1	1	55.1068651	82.9524827	2026-01-31 23:03:34.158	MOVE	46.5	0.7314413189888	273.0870971679688	\N	601	2026-02-01 01:49:40.601
602	1	1	55.1068539	82.9523184	2026-01-31 23:04:02.036	MOVE	61.5	6.458956718444824	265.9521484375	\N	602	2026-02-01 01:49:40.601
603	1	1	55.1067789	82.9522145	2026-01-31 23:04:19.93	MOVE	24.45400047302246	0	0	\N	603	2026-02-01 01:49:40.601
604	1	1	55.106882	82.9526494	2026-01-31 23:05:03.013	MOVE	82.5	1.149999976158142	279	\N	604	2026-02-01 01:49:40.601
605	1	1	55.1067638	82.9522267	2026-01-31 23:05:21.152	MOVE	35.70299911499023	0	0	\N	605	2026-02-01 01:49:40.601
606	1	1	55.106773	82.952099	2026-01-31 23:05:36.078	MOVE	91	1.431730628013611	346.8740539550781	\N	606	2026-02-01 01:49:40.601
607	1	1	55.1067627	82.9522158	2026-01-31 23:06:01.852	MOVE	35.99300003051758	0	0	\N	607	2026-02-01 01:49:40.601
608	1	1	55.1067572	82.9523385	2026-01-31 23:08:02.975	MOVE	34.89500045776367	1.731196522712708	105.4973297119141	\N	608	2026-02-01 01:49:40.601
609	1	1	55.1067776	82.9522108	2026-01-31 23:08:20.288	MOVE	27.50900077819824	0	0	\N	609	2026-02-01 01:49:40.601
610	1	1	55.1068646	82.9523093	2026-01-31 23:09:04.007	MOVE	86.5	3.609999895095825	293	\N	610	2026-02-01 01:49:40.601
611	1	1	55.1067818	82.9522124	2026-01-31 23:09:27.854	MOVE	27.93499946594238	0	0	\N	611	2026-02-01 01:49:40.601
612	1	1	55.1069317	82.9526969	2026-01-31 23:10:06.164	MOVE	83.5	3.629999876022339	282	\N	612	2026-02-01 01:49:40.601
613	1	1	55.1067612	82.9522206	2026-01-31 23:10:37.196	MOVE	35.71099853515625	0	0	\N	613	2026-02-01 01:49:40.601
614	1	1	55.1073214	82.9540062	2026-01-31 23:11:19.011	MOVE	120	0	0	\N	614	2026-02-01 01:49:40.601
615	1	1	55.106783	82.9522207	2026-01-31 23:11:42.207	MOVE	27.42099952697754	0	0	\N	615	2026-02-01 01:49:40.601
616	1	1	55.1068796	82.952555	2026-01-31 23:15:32.993	MOVE	53.5	1.350000023841858	274	\N	616	2026-02-01 01:49:40.601
617	1	1	55.1067777	82.9521991	2026-01-31 23:15:56.992	MOVE	37.91699981689453	0	0	\N	617	2026-02-01 01:49:40.601
618	1	1	55.1067683	82.9523129	2026-01-31 23:16:46.122	MOVE	35.24100112915039	1.793839931488037	104.1991577148438	\N	618	2026-02-01 01:49:40.601
619	1	1	55.1067837	82.9522215	2026-01-31 23:17:15.326	MOVE	27.35099983215332	0	0	\N	619	2026-02-01 01:49:40.601
620	1	1	55.1068131	82.9526928	2026-01-31 23:17:32.989	MOVE	45	0.8299999833106995	122	\N	620	2026-02-01 01:49:40.601
621	1	1	55.1067842	82.9522142	2026-01-31 23:17:57.872	MOVE	27.43899917602539	0	0	\N	621	2026-02-01 01:49:40.601
622	1	1	55.1069764	82.952438	2026-01-31 23:18:33.145	MOVE	74.5	1.179999947547913	49	\N	622	2026-02-01 01:49:40.601
623	1	1	55.1067948	82.952881	2026-01-31 23:18:50.948	MOVE	46	1.939999938011169	294	\N	623	2026-02-01 01:49:40.601
624	1	1	55.1067733	82.9522056	2026-01-31 23:19:21.794	MOVE	35.79199981689453	0	0	\N	624	2026-02-01 01:49:40.601
625	1	1	55.1068121	82.9522957	2026-01-31 23:19:43.955	MOVE	27.66300010681152	0.2020091116428375	303.5692138671875	\N	625	2026-02-01 01:49:40.601
626	1	1	55.1067765	82.9522173	2026-01-31 23:20:01.07	MOVE	27.28400039672852	0	0	\N	626	2026-02-01 01:49:40.601
627	1	1	55.1068242	82.9523092	2026-01-31 23:20:01.981	MOVE	37.89199829101562	0.3217670917510986	305.8741760253906	\N	627	2026-02-01 01:49:40.601
628	1	1	55.1067745	82.9522619	2026-01-31 23:20:18.188	MOVE	26.38899993896484	0	0	\N	628	2026-02-01 01:49:40.601
629	1	1	55.1068258	82.9523431	2026-01-31 23:20:35.248	MOVE	129.0970001220703	0.8677324056625366	244.9707336425781	\N	629	2026-02-01 01:49:40.601
630	1	1	55.1067822	82.9522536	2026-01-31 23:20:52.382	MOVE	18.39200019836426	0	0	\N	630	2026-02-01 01:49:40.601
631	1	1	55.1067962	82.9523961	2026-01-31 23:21:09.486	MOVE	27.74799919128418	1.112078309059143	106.5891647338867	\N	631	2026-02-01 01:49:40.601
632	1	1	55.1067891	82.9522541	2026-01-31 23:21:26.616	MOVE	20.5580005645752	0	0	\N	632	2026-02-01 01:49:40.601
633	1	1	55.1069846	82.9522788	2026-01-31 23:22:03.147	MOVE	52	2.409659624099731	276.0321044921875	\N	633	2026-02-01 01:49:40.601
634	1	1	55.1068058	82.9522202	2026-01-31 23:22:14.171	MOVE	18.98100090026855	1.988999485969543	276.2940979003906	\N	634	2026-02-01 01:49:40.601
635	1	1	55.1068026	82.9528113	2026-01-31 23:23:03.113	MOVE	58.5	1.333806872367859	304.1435241699219	\N	635	2026-02-01 01:49:40.601
636	1	1	55.1067924	82.9522766	2026-01-31 23:23:14.169	MOVE	18.98100090026855	1.490692853927612	297.994873046875	\N	636	2026-02-01 01:49:40.601
637	1	1	55.1068527	82.9521592	2026-01-31 23:24:15.355	MOVE	19.1200008392334	3.300785541534424	318.7575988769531	\N	637	2026-02-01 01:49:40.601
638	1	1	55.1067792	82.9522612	2026-01-31 23:24:32.39	MOVE	17.75799942016602	0	0	\N	638	2026-02-01 01:49:40.601
639	1	1	55.1068361	82.9524665	2026-01-31 23:25:06.422	MOVE	32.32500076293945	1.149096131324768	76.40375518798828	\N	639	2026-02-01 01:49:40.601
640	1	1	55.106796	82.9522509	2026-01-31 23:25:23.479	MOVE	18.37299919128418	0	0	\N	640	2026-02-01 01:49:40.601
641	1	1	55.1067818	82.9523324	2026-01-31 23:25:40.534	MOVE	25.87700080871582	1.263415694236755	94.44315338134766	\N	641	2026-02-01 01:49:40.601
642	1	1	55.1069151	82.9520288	2026-01-31 23:25:55.973	MOVE	46.5	1.289999961853027	284	\N	642	2026-02-01 01:49:40.601
643	1	1	55.106943	82.9519564	2026-01-31 23:25:57.966	MOVE	55.11899948120117	0.7283503413200378	289.7877197265625	\N	643	2026-02-01 01:49:40.601
644	1	1	55.1067593	82.9522159	2026-01-31 23:26:14.691	MOVE	43.99200057983398	0	0	\N	644	2026-02-01 01:49:40.601
645	1	1	55.1067963	82.9528423	2026-01-31 23:26:27.969	MOVE	34.5	6.120361804962158	85.97173309326172	\N	645	2026-02-01 01:49:40.601
646	1	1	55.106764	82.9522338	2026-01-31 23:26:46.397	MOVE	34.43899917602539	0	0	\N	646	2026-02-01 01:49:40.601
647	1	1	55.1067872	82.9523909	2026-01-31 23:27:03.337	MOVE	26.32600021362305	1.538858413696289	82.2936782836914	\N	647	2026-02-01 01:49:40.601
648	1	1	55.1069954	82.9518352	2026-01-31 23:27:20.397	MOVE	186.7180023193359	1.058228731155396	300.0371398925781	\N	648	2026-02-01 01:49:40.601
649	1	1	55.1068572	82.9526003	2026-01-31 23:27:36.96	MOVE	43	6.869999885559082	87	\N	649	2026-02-01 01:49:40.601
650	1	1	55.1067847	82.953102	2026-01-31 23:27:42.971	MOVE	23	6.346889972686768	99.0004653930664	\N	650	2026-02-01 01:49:40.601
651	1	1	55.1067943	82.9522816	2026-01-31 23:28:01.932	MOVE	37.38999938964844	0	0	\N	651	2026-02-01 01:49:40.601
652	1	1	55.1069151	82.9520567	2026-01-31 23:28:17.977	MOVE	98.5	1.139999985694885	124	\N	652	2026-02-01 01:49:40.601
653	1	1	55.1067801	82.9522643	2026-01-31 23:28:42.384	MOVE	26.08600044250488	0	0	\N	653	2026-02-01 01:49:40.601
654	1	1	55.1068521	82.9526541	2026-01-31 23:29:47.954	MOVE	49	2.429999828338623	298	\N	654	2026-02-01 01:49:40.601
655	1	1	55.1067683	82.9522157	2026-01-31 23:30:12.848	MOVE	33.69100189208984	0	0	\N	655	2026-02-01 01:49:40.601
656	1	1	55.1066888	82.9527167	2026-01-31 23:30:48.159	MOVE	74	4.151959419250488	113.0603408813477	\N	656	2026-02-01 01:49:40.601
657	1	1	55.1067828	82.9522958	2026-01-31 23:31:01.17	MOVE	18.41200065612793	2.411213397979736	122.8355331420898	\N	657	2026-02-01 01:49:40.601
658	1	1	55.1068348	82.9522531	2026-01-31 23:31:19.103	MOVE	65.64900207519531	4.070013999938965	285.0315551757812	\N	658	2026-02-01 01:49:40.601
659	1	1	55.1067886	82.952273	2026-01-31 23:31:42.826	MOVE	31.83200073242188	0	0	\N	659	2026-02-01 01:49:40.601
660	1	1	55.1067624	82.9523665	2026-01-31 23:32:31.025	MOVE	32.20999908447266	1.669947624206543	144.1474914550781	\N	660	2026-02-01 01:49:40.601
661	1	1	55.106857	82.9526479	2026-01-31 23:32:47.114	MOVE	64.5	1.309999942779541	98	\N	661	2026-02-01 01:49:40.601
662	1	1	55.1067451	82.9528665	2026-01-31 23:33:05.121	MOVE	48.5	0.1499999910593033	354	\N	662	2026-02-01 01:49:40.601
663	1	1	55.1067796	82.9522767	2026-01-31 23:33:19.453	MOVE	27.47699928283691	0.17768295109272	340.7130432128906	\N	663	2026-02-01 01:49:40.601
664	1	1	55.1067662	82.9529769	2026-01-31 23:34:02.963	MOVE	59	2.399999856948853	313	\N	664	2026-02-01 01:49:40.601
665	1	1	55.1067712	82.9522416	2026-01-31 23:34:27.778	MOVE	40.27399826049805	0	0	\N	665	2026-02-01 01:49:40.601
666	1	1	55.1068019	82.9525736	2026-01-31 23:35:31.121	MOVE	49	0.2917810380458832	124.6343460083008	\N	666	2026-02-01 01:49:40.601
667	1	1	55.1067665	82.9523542	2026-01-31 23:35:43.998	MOVE	44.35900115966797	0.1826155781745911	186.1449584960938	\N	667	2026-02-01 01:49:40.601
668	1	1	55.10678	82.9522306	2026-01-31 23:36:01.252	MOVE	27.08399963378906	0	0	\N	668	2026-02-01 01:49:40.601
669	1	1	55.1071441	82.9516013	2026-01-31 23:37:03.049	MOVE	51.5	23.08576965332031	300.2998657226562	\N	669	2026-02-01 01:49:40.601
670	1	1	55.1069343	82.9519397	2026-01-31 23:37:15.885	MOVE	27.44499969482422	6.816134929656982	310.1463317871094	\N	670	2026-02-01 01:49:40.601
671	1	1	55.1068079	82.952684	2026-01-31 23:37:32.947	MOVE	72.5	0.1099999994039536	286	\N	671	2026-02-01 01:49:40.601
672	1	1	55.1069548	82.9520607	2026-01-31 23:37:56.921	MOVE	49.5	1.519999980926514	295	\N	672	2026-02-01 01:49:40.601
673	1	1	55.1067845	82.9522307	2026-01-31 23:38:25.006	MOVE	27.3390007019043	0	0	\N	673	2026-02-01 01:49:40.601
674	1	1	55.1067609	82.9523628	2026-01-31 23:39:44.876	MOVE	34.74599838256836	1.977093815803528	297.3692321777344	\N	674	2026-02-01 01:49:40.601
675	1	1	55.1069318	82.9528136	2026-01-31 23:40:00.969	MOVE	47.5	0.7400000095367432	100	\N	675	2026-02-01 01:49:40.601
676	1	1	55.1067695	82.9522329	2026-01-31 23:40:27.838	MOVE	34.64799880981445	0	0	\N	676	2026-02-01 01:49:40.601
677	1	1	55.1068175	82.9521654	2026-01-31 23:40:46.013	MOVE	27.44499969482422	3.559279441833496	303.5946655273438	\N	677	2026-02-01 01:49:40.601
678	1	1	55.1069565	82.9520797	2026-01-31 23:41:02.96	MOVE	62.5	1.370000004768372	293	\N	678	2026-02-01 01:49:40.601
679	1	1	55.1067661	82.9522316	2026-01-31 23:41:27.823	MOVE	35.36399841308594	0	0	\N	679	2026-02-01 01:49:40.601
680	1	1	55.1068195	82.9521507	2026-01-31 23:42:15.2	MOVE	34.30199813842773	2.149673700332642	298.9169921875	\N	680	2026-02-01 01:49:40.601
681	1	1	55.1067651	82.952235	2026-01-31 23:42:32.356	MOVE	34.76499938964844	0	0	\N	681	2026-02-01 01:49:40.601
682	1	1	55.1068182	82.9525301	2026-01-31 23:42:55.133	MOVE	49	1.079999923706055	307	\N	682	2026-02-01 01:49:40.601
683	1	1	55.1067706	82.9522221	2026-01-31 23:43:24.89	MOVE	33.79299926757812	0	0	\N	683	2026-02-01 01:49:40.601
684	1	1	55.1068804	82.9520737	2026-01-31 23:44:14.992	MOVE	34.85200119018555	2.785438537597656	310.8588256835938	\N	684	2026-02-01 01:49:40.601
685	1	1	55.1068162	82.9525179	2026-01-31 23:44:30.952	MOVE	49	0.8100000023841858	97	\N	685	2026-02-01 01:49:40.601
686	1	1	55.106785	82.9522335	2026-01-31 23:44:56.984	MOVE	27.24900054931641	0	0	\N	686	2026-02-01 01:49:40.601
687	1	1	55.1067738	82.9523185	2026-01-31 23:45:44.907	MOVE	27.3390007019043	0.755246102809906	175.6710968017578	\N	687	2026-02-01 01:49:40.601
688	1	1	55.1067293	82.9527396	2026-01-31 23:46:00.956	MOVE	49	0.6299999952316284	247	\N	688	2026-02-01 01:49:40.601
689	1	1	55.106854	82.9527629	2026-01-31 23:46:22.092	MOVE	48	4.779999732971191	102	\N	689	2026-02-01 01:49:40.601
690	1	1	55.1067844	82.952686	2026-01-31 23:46:51.087	MOVE	46	3.279999971389771	303	\N	690	2026-02-01 01:49:40.601
691	1	1	55.1068214	82.9527373	2026-01-31 23:46:58.888	MOVE	39.83700180053711	1.06151294708252	334.9065551757812	\N	691	2026-02-01 01:49:40.601
692	1	1	55.1067674	82.9522261	2026-01-31 23:47:26.133	MOVE	35.74200057983398	0	0	\N	692	2026-02-01 01:49:40.601
693	1	1	55.1068119	82.9522466	2026-01-31 23:48:15.266	MOVE	42.82099914550781	0.1890550851821899	66.69981384277344	\N	693	2026-02-01 01:49:40.601
694	1	1	55.1069548	82.9522436	2026-01-31 23:48:32.939	MOVE	58.5	0.1299999952316284	101	\N	694	2026-02-01 01:49:40.601
695	1	1	55.1067703	82.9522587	2026-01-31 23:48:57.817	MOVE	32.76399993896484	0	0	\N	695	2026-02-01 01:49:40.601
696	1	1	55.1067727	82.9521741	2026-01-31 23:49:50.803	MOVE	47.71500015258789	0	0	\N	696	2026-02-01 01:49:40.601
697	1	1	55.1068188	82.9526603	2026-01-31 23:50:32.074	MOVE	68	1.134727239608765	300.1377563476562	\N	697	2026-02-01 01:49:40.601
698	1	1	55.1068517	82.9525304	2026-01-31 23:50:52.944	MOVE	46.5	1.296514749526978	245.8257293701172	\N	698	2026-02-01 01:49:40.601
699	1	1	55.1068846	82.9524234	2026-01-31 23:51:16.875	MOVE	45.5	1.538069725036621	106.8686599731445	\N	699	2026-02-01 01:49:40.601
700	1	1	55.1067595	82.9522087	2026-01-31 23:51:38.367	MOVE	43.90399932861328	0	0	\N	700	2026-02-01 01:49:40.601
701	1	1	55.1068369	82.9524477	2026-01-31 23:52:03.911	MOVE	48.5	0.449999988079071	291	\N	701	2026-02-01 01:49:40.601
702	1	1	55.10677	82.9522271	2026-01-31 23:52:25.78	MOVE	35.98899841308594	0	0	\N	702	2026-02-01 01:49:40.601
703	1	1	55.1068706	82.9525897	2026-01-31 23:54:15.901	MOVE	48	1.16991126537323	112.9901351928711	\N	703	2026-02-01 01:49:40.601
704	1	1	55.1067664	82.9522188	2026-01-31 23:54:34.927	MOVE	35.88600158691406	0	0	\N	704	2026-02-01 01:49:40.601
705	1	1	55.1067124	82.9527842	2026-01-31 23:55:17.897	MOVE	47.5	0.009999999776482582	0	\N	705	2026-02-01 01:49:40.601
706	1	1	55.1067731	82.9522261	2026-01-31 23:55:36.813	MOVE	34.78499984741211	0	0	\N	706	2026-02-01 01:49:40.601
707	1	1	55.1069723	82.9520709	2026-01-31 23:57:14.072	MOVE	48	8.458407402038574	295.1420288085938	\N	707	2026-02-01 01:49:40.601
708	1	1	55.1067793	82.9522589	2026-01-31 23:57:29.502	MOVE	18.13100051879883	0	0	\N	708	2026-02-01 01:49:40.601
709	1	1	55.1069203	82.9525017	2026-01-31 23:58:34.481	MOVE	171.4839935302734	1.646741390228271	308.0155944824219	\N	709	2026-02-01 01:49:40.601
710	1	1	55.1068348	82.9527544	2026-01-31 23:58:54.055	MOVE	47.5	1.549999952316284	287	\N	710	2026-02-01 01:49:40.601
711	1	1	55.1068021	82.9523008	2026-01-31 23:59:20.896	MOVE	42.5	0.25	306	\N	711	2026-02-01 01:49:40.601
712	1	1	55.1069376	82.9523936	2026-01-31 23:59:47.091	MOVE	48.5	1.049999952316284	285	\N	712	2026-02-01 01:49:40.601
713	1	1	55.1067784	82.9522371	2026-02-01 00:00:03.787	MOVE	20.54700088500977	0	0	\N	713	2026-02-01 01:49:40.601
714	1	1	55.106835	82.9524603	2026-02-01 00:00:50.084	MOVE	47	1.889999985694885	283	\N	714	2026-02-01 01:49:40.601
715	1	1	55.1068698	82.9529495	2026-02-01 00:01:22.039	MOVE	49.5	0.8999999761581421	295	\N	715	2026-02-01 01:49:40.601
716	1	1	55.1069189	82.9527353	2026-02-01 00:01:53.046	MOVE	49	0.2899999916553497	55	\N	716	2026-02-01 01:49:40.601
717	1	1	55.1067745	82.9522266	2026-02-01 00:02:23.765	MOVE	34.54999923706055	0	0	\N	717	2026-02-01 01:49:40.601
718	1	1	55.1069356	82.9518082	2026-02-01 00:04:04.8	MOVE	168.9290008544922	2.141098737716675	284.9947509765625	\N	718	2026-02-01 01:49:40.601
719	1	1	55.1069031	82.9529241	2026-02-01 00:04:22.046	MOVE	44	8.010000228881836	279	\N	719	2026-02-01 01:49:40.601
720	1	1	55.1067471	82.9522142	2026-02-01 00:04:45.487	MOVE	43.39099884033203	0	0	\N	720	2026-02-01 01:49:40.601
721	1	1	55.1069623	82.9518744	2026-02-01 00:05:02.895	MOVE	49	2.589999914169312	278	\N	721	2026-02-01 01:49:40.601
722	1	1	55.106775	82.952218	2026-02-01 00:05:27.747	MOVE	31.59600067138672	0	0	\N	722	2026-02-01 01:49:40.601
723	1	1	55.1069771	82.951778	2026-02-01 00:14:57.296	MOVE	283.3720092773438	0.1803386062383652	359.9964294433594	\N	723	2026-02-01 01:49:40.601
724	1	1	55.1069314	82.9520218	2026-02-01 00:14:57.854	MOVE	87	1.426911592483521	292.425048828125	\N	724	2026-02-01 01:49:40.601
725	1	1	55.1067832	82.9522586	2026-02-01 00:15:22.681	MOVE	18.19000053405762	0	0	\N	725	2026-02-01 01:49:40.601
726	1	1	55.106754	82.9524441	2026-02-01 00:16:02.838	MOVE	44.47299957275391	0.8677345514297485	79.66011810302734	\N	726	2026-02-01 01:49:40.601
727	1	1	55.1067822	82.9522535	2026-02-01 00:16:19.965	MOVE	18.58099937438965	0	0	\N	727	2026-02-01 01:49:40.601
728	1	1	55.1068188	82.9525022	2026-02-01 00:18:33.034	MOVE	62	3.73445987701416	272.0138854980469	\N	728	2026-02-01 01:49:40.601
729	1	1	55.1069641	82.9516732	2026-02-01 00:18:58.032	MOVE	48.5	4.003937721252441	275.0137634277344	\N	729	2026-02-01 01:49:40.601
730	1	1	55.1068133	82.9521435	2026-02-01 00:19:13.87	MOVE	19.0939998626709	1.590407490730286	276.8725891113281	\N	730	2026-02-01 01:49:40.601
731	1	1	55.106785	82.9522551	2026-02-01 00:19:31.98	MOVE	19.32699966430664	0	0	\N	731	2026-02-01 01:49:40.601
732	1	1	55.1062068	82.9558479	2026-02-01 00:20:12.015	MOVE	193.5	12.89999961853027	100	\N	732	2026-02-01 01:49:40.601
733	1	1	55.1067758	82.9522187	2026-02-01 00:20:34.55	MOVE	27.41500091552734	0	0	\N	733	2026-02-01 01:49:40.601
734	1	1	55.106791	82.9529953	2026-02-01 00:23:47.852	MOVE	50.5	0.449999988079071	246	\N	734	2026-02-01 01:49:40.601
735	1	1	55.1067808	82.9522597	2026-02-01 00:24:07.154	MOVE	18.05900001525879	0	0	\N	735	2026-02-01 01:49:40.601
736	1	1	55.1068204	82.9525429	2026-02-01 00:25:13.032	MOVE	41.75	1.334276556968689	102.8704681396484	\N	736	2026-02-01 01:49:40.601
737	1	1	55.106804	82.9526611	2026-02-01 00:25:19.486	MOVE	163.0619964599609	1.323389291763306	102.958740234375	\N	737	2026-02-01 01:49:40.601
738	1	1	55.1067888	82.9522627	2026-02-01 00:25:42.683	MOVE	17.40299987792969	0	0	\N	738	2026-02-01 01:49:40.601
739	1	1	55.1068304	82.9526261	2026-02-01 00:26:48.033	MOVE	47.5	1.919131994247437	112.9942245483398	\N	739	2026-02-01 01:49:40.601
740	1	1	55.1067828	82.9523169	2026-02-01 00:26:58.845	MOVE	18.66300010681152	1.594955086708069	117.6957168579102	\N	740	2026-02-01 01:49:40.601
741	1	1	55.10678	82.9522078	2026-02-01 00:27:16.057	MOVE	28.07999992370605	0	0	\N	741	2026-02-01 01:49:40.601
742	1	1	55.1068781	82.952344	2026-02-01 00:27:48.843	MOVE	53	10.25	311	\N	742	2026-02-01 01:49:40.601
743	1	1	55.1067689	82.9522701	2026-02-01 00:28:07.225	MOVE	42.10400009155273	0	0	\N	743	2026-02-01 01:49:40.601
744	1	1	55.106787	82.9521908	2026-02-01 00:28:32.704	MOVE	36.98199844360352	0.5150070786476135	226.2036895751953	\N	744	2026-02-01 01:49:40.601
745	1	1	55.106977	82.9521004	2026-02-01 00:28:48.02	MOVE	116.5	2.740000009536743	110	\N	745	2026-02-01 01:49:40.601
746	1	1	55.1067819	82.9522068	2026-02-01 00:29:07.07	MOVE	27.68199920654297	0	0	\N	746	2026-02-01 01:49:40.601
747	1	1	55.1069508	82.9524713	2026-02-01 00:29:47.851	MOVE	46.5	7.299999713897705	296	\N	747	2026-02-01 01:49:40.601
748	1	1	55.1067765	82.9522588	2026-02-01 00:30:11.697	MOVE	17.04999923706055	0	0	\N	748	2026-02-01 01:49:40.601
749	1	1	55.1067709	82.9527149	2026-02-01 00:31:15.994	MOVE	48.5	8.050000190734863	270	\N	749	2026-02-01 01:49:40.601
750	1	1	55.1067765	82.9522072	2026-02-01 00:31:35.015	MOVE	28.13500022888184	0	0	\N	750	2026-02-01 01:49:40.601
751	1	1	55.1067613	82.9523211	2026-02-01 00:32:00.975	MOVE	33.36600112915039	1.179359912872314	150.3610687255859	\N	751	2026-02-01 01:49:40.601
752	1	1	55.1067786	82.952213	2026-02-01 00:32:18.347	MOVE	28.00799942016602	0	0	\N	752	2026-02-01 01:49:40.601
753	1	1	55.1068931	82.952132	2026-02-01 00:33:17.851	MOVE	50.5	8.5	278	\N	753	2026-02-01 01:49:40.601
754	1	1	55.1067853	82.9522525	2026-02-01 00:33:36.001	MOVE	17.80100059509277	0	0	\N	754	2026-02-01 01:49:40.601
755	1	1	55.1069167	82.952132	2026-02-01 00:33:50.003	MOVE	102.5	29.51407623291016	282.3288269042969	\N	755	2026-02-01 01:49:40.601
756	1	1	55.1068314	82.9520473	2026-02-01 00:34:02.422	MOVE	43.14400100708008	5.176898956298828	289.5165100097656	\N	756	2026-02-01 01:49:40.601
757	1	1	55.1068821	82.9519999	2026-02-01 00:34:17.984	MOVE	73.5	12.77999973297119	279	\N	757	2026-02-01 01:49:40.601
758	1	1	55.1067736	82.9522151	2026-02-01 00:34:37.179	MOVE	28.00399971008301	0	0	\N	758	2026-02-01 01:49:40.601
759	1	1	55.1068203	82.9529398	2026-02-01 00:35:18.024	MOVE	89.5	26.57999992370605	96	\N	759	2026-02-01 01:49:40.601
760	1	1	55.1067718	82.95225	2026-02-01 00:35:37.972	MOVE	31.86800003051758	0	0	\N	760	2026-02-01 01:49:40.601
761	1	1	55.1067612	82.9528633	2026-02-01 00:36:14.009	MOVE	48.5	2.186917304992676	283.0722351074219	\N	761	2026-02-01 01:49:40.601
762	1	1	55.10678	82.9522768	2026-02-01 00:36:28.86	MOVE	16.82999992370605	2.262423753738403	282.2655639648438	\N	762	2026-02-01 01:49:40.601
763	1	1	55.1068102	82.952882	2026-02-01 00:36:43.003	MOVE	43	0.218647688627243	278.0461730957031	\N	763	2026-02-01 01:49:40.601
764	1	1	55.10677	82.9522144	2026-02-01 00:37:12.682	MOVE	27.80400085449219	0	0	\N	764	2026-02-01 01:49:40.601
765	1	1	55.1067424	82.9525948	2026-02-01 00:38:17.811	MOVE	50	5.849999904632568	229	\N	765	2026-02-01 01:49:40.601
766	1	1	55.1067846	82.9522376	2026-02-01 00:38:36.235	MOVE	21.49699974060059	0	0	\N	766	2026-02-01 01:49:40.601
767	1	1	55.106798	82.9530209	2026-02-01 00:39:17.833	MOVE	58.5	0.6399999856948853	58	\N	767	2026-02-01 01:49:40.601
768	1	1	55.1067691	82.9522721	2026-02-01 00:39:40.706	MOVE	17.02400016784668	0	0	\N	768	2026-02-01 01:49:40.601
769	1	1	55.1068077	82.9521774	2026-02-01 00:40:47.812	MOVE	51.99900054931641	0.2815822660923004	135.9170379638672	\N	769	2026-02-01 01:49:40.601
770	1	1	55.1067824	82.9522683	2026-02-01 00:41:11.641	MOVE	18.04199981689453	0	0	\N	770	2026-02-01 01:49:40.601
771	1	1	55.106697	82.9524941	2026-02-01 00:42:48.84	MOVE	49	2.423479795455933	273.0064086914062	\N	771	2026-02-01 01:49:40.601
772	1	1	55.1068658	82.9522176	2026-02-01 00:43:10.827	MOVE	46	4.687813282012939	117.0954895019531	\N	772	2026-02-01 01:49:40.601
773	1	1	55.1067898	82.9522356	2026-02-01 00:43:30.65	MOVE	21.23100090026855	0	0	\N	773	2026-02-01 01:49:40.601
774	1	1	55.1069354	82.9519386	2026-02-01 00:43:47.642	MOVE	131.2940063476562	4.563990592956543	290.1539611816406	\N	774	2026-02-01 01:49:40.601
775	1	1	55.1067775	82.9522746	2026-02-01 00:44:04.813	MOVE	25.75600051879883	0	0	\N	775	2026-02-01 01:49:40.601
776	1	1	55.1069179	82.9520956	2026-02-01 00:44:21.973	MOVE	188.0650024414062	1.126740097999573	292.0593872070312	\N	776	2026-02-01 01:49:40.601
777	1	1	55.1067714	82.9522147	2026-02-01 00:44:41.695	MOVE	27.51300048828125	0	0	\N	777	2026-02-01 01:49:40.601
778	1	1	55.1068222	82.9519348	2026-02-01 00:47:01.806	MOVE	84.5	4.61536979675293	283.0617980957031	\N	778	2026-02-01 01:49:40.601
779	1	1	55.1067837	82.9522347	2026-02-01 00:47:21.36	MOVE	21.72299957275391	0	0	\N	779	2026-02-01 01:49:40.601
780	1	1	55.1067886	82.9527294	2026-02-01 00:48:47.967	MOVE	95.5	0.8450780510902405	210.8954467773438	\N	780	2026-02-01 01:49:40.601
781	1	1	55.1067643	82.9522637	2026-02-01 00:49:01.711	MOVE	27.52400016784668	0.8550340533256531	222.3741302490234	\N	781	2026-02-01 01:49:40.601
782	1	1	55.1068438	82.952561	2026-02-01 00:49:17.962	MOVE	106.5	0.85999995470047	302	\N	782	2026-02-01 01:49:40.601
783	1	1	55.106765	82.9522137	2026-02-01 00:49:41.721	MOVE	34.29399871826172	0	0	\N	783	2026-02-01 01:49:40.601
784	1	1	55.1068496	82.9520532	2026-02-01 00:51:38.564	MOVE	186.4040069580078	1.0135498046875	289.1535339355469	\N	784	2026-02-01 01:49:40.601
785	1	1	55.106775	82.9522603	2026-02-01 00:51:58.697	MOVE	17.65999984741211	0	0	\N	785	2026-02-01 01:49:40.601
786	1	1	55.1069525	82.9522828	2026-02-01 00:52:38.798	MOVE	220	0.6200000047683716	260	\N	786	2026-02-01 01:49:40.601
787	1	1	55.1067768	82.9522581	2026-02-01 00:53:00.45	MOVE	17.37299919128418	0	0	\N	787	2026-02-01 01:49:40.601
788	1	1	55.1068882	82.9518951	2026-02-01 00:53:17.811	MOVE	94	2.379999876022339	125	\N	788	2026-02-01 01:49:40.601
789	1	1	55.1067737	82.9522143	2026-02-01 00:53:34.938	MOVE	27.84700012207031	0	0	\N	789	2026-02-01 01:49:40.601
790	1	1	55.1068374	82.9521376	2026-02-01 00:54:18.79	MOVE	88.5	3.240000009536743	49	\N	790	2026-02-01 01:49:40.601
791	1	1	55.1067763	82.9522002	2026-02-01 00:54:36.769	MOVE	36.18999862670898	0	0	\N	791	2026-02-01 01:49:40.601
792	1	1	55.1067876	82.9520859	2026-02-01 00:55:01.726	MOVE	48.37799835205078	2.411390781402588	273.3827209472656	\N	792	2026-02-01 01:49:40.601
793	1	1	55.1069338	82.9525303	2026-02-01 00:55:18.809	MOVE	77.5	1.96999990940094	305	\N	793	2026-02-01 01:49:40.601
794	1	1	55.1067692	82.9522223	2026-02-01 00:55:35.759	MOVE	27.66399955749512	0	0	\N	794	2026-02-01 01:49:40.601
795	1	1	55.1069065	82.9521214	2026-02-01 00:56:47.792	MOVE	55	0.85999995470047	21	\N	795	2026-02-01 01:49:40.601
796	1	1	55.1067852	82.9522547	2026-02-01 00:57:05.804	MOVE	18.00600051879883	0	0	\N	796	2026-02-01 01:49:40.601
797	1	1	55.1067785	82.9524908	2026-02-01 00:57:41.802	MOVE	48.5	2.369999885559082	76	\N	797	2026-02-01 01:49:40.601
798	1	1	55.1067754	82.952209	2026-02-01 00:58:01.965	MOVE	27.51399993896484	0	0	\N	798	2026-02-01 01:49:40.601
799	1	1	55.1069102	82.9529723	2026-02-01 00:59:42.784	MOVE	48	2.821261644363403	101.9846572875977	\N	799	2026-02-01 01:49:40.601
800	1	1	55.1068752	82.9520656	2026-02-01 01:00:09.952	MOVE	46.5	5.549999713897705	288	\N	800	2026-02-01 01:49:40.601
801	1	1	55.1067796	82.9522609	2026-02-01 01:00:29.536	MOVE	18.32200050354004	0	0	\N	801	2026-02-01 01:49:40.601
802	1	1	55.1068613	82.9532137	2026-02-01 01:00:46.791	MOVE	89.5	0.75	288	\N	802	2026-02-01 01:49:40.601
803	1	1	55.1067798	82.9522047	2026-02-01 01:01:11.688	MOVE	27.95400047302246	0	0	\N	803	2026-02-01 01:49:40.601
804	1	1	55.1068263	82.9530791	2026-02-01 01:03:01.773	MOVE	78	2.549999952316284	83	\N	804	2026-02-01 01:49:40.601
805	1	1	55.1067837	82.9522377	2026-02-01 01:03:19.092	MOVE	20.98100090026855	0	0	\N	805	2026-02-01 01:49:40.601
806	1	1	55.1068317	82.952239	2026-02-01 01:03:32.941	MOVE	110.5	1.915803551673889	267.9966735839844	\N	806	2026-02-01 01:49:40.601
807	1	1	55.1067833	82.9522214	2026-02-01 01:03:44.038	MOVE	20.97100067138672	1.805936574935913	267.8387451171875	\N	807	2026-02-01 01:49:40.601
808	1	1	55.1068301	82.9525448	2026-02-01 01:04:33.781	MOVE	144	0.9249236583709717	287.4857177734375	\N	808	2026-02-01 01:49:40.601
809	1	1	55.1067748	82.9522258	2026-02-01 01:04:46.222	MOVE	27.66500091552734	1.115255832672119	281.7978820800781	\N	809	2026-02-01 01:49:40.601
810	1	1	55.1067824	82.9528733	2026-02-01 01:05:02.771	MOVE	107	1.049999952316284	279	\N	810	2026-02-01 01:49:40.601
811	1	1	55.1067838	82.9522684	2026-02-01 01:05:21.009	MOVE	17.66500091552734	0	0	\N	811	2026-02-01 01:49:40.601
812	1	1	55.1067762	82.9523847	2026-02-01 01:05:44.789	MOVE	28.13500022888184	0.6384217143058777	173.1896362304688	\N	812	2026-02-01 01:49:40.601
813	1	1	55.1067842	82.9522691	2026-02-01 01:06:01.959	MOVE	18.32200050354004	0	0	\N	813	2026-02-01 01:49:40.601
814	1	1	55.1067027	82.9526601	2026-02-01 01:06:32.944	MOVE	93	0.09228125214576721	0	\N	814	2026-02-01 01:49:40.601
815	1	1	55.106766	82.9522486	2026-02-01 01:06:43.988	MOVE	27.67099952697754	0.2780590653419495	271.8944091796875	\N	815	2026-02-01 01:49:40.601
816	1	1	55.1069104	82.9522552	2026-02-01 01:07:34.932	MOVE	91	3.470776319503784	96.04090881347656	\N	816	2026-02-01 01:49:40.601
817	1	1	55.1067947	82.9522659	2026-02-01 01:07:46.652	MOVE	36.22800064086914	1.677300095558167	108.2701721191406	\N	817	2026-02-01 01:49:40.601
818	1	1	55.1067153	82.9531012	2026-02-01 01:08:02.779	MOVE	70	16.36999893188477	113	\N	818	2026-02-01 01:49:40.601
819	1	1	55.1067709	82.9522223	2026-02-01 01:08:20.952	MOVE	35.84400177001953	0	0	\N	819	2026-02-01 01:49:40.601
820	1	1	55.1068052	82.9529824	2026-02-01 01:10:02.946	MOVE	62.5	5.789999961853027	86	\N	820	2026-02-01 01:49:40.601
821	1	1	55.1067759	82.952244	2026-02-01 01:10:22.857	MOVE	35.44800186157227	0	0	\N	821	2026-02-01 01:49:40.601
822	1	1	55.1069951	82.9522901	2026-02-01 01:13:17.769	MOVE	53.5	0.2966581583023071	274.0592346191406	\N	822	2026-02-01 01:49:40.601
823	1	1	55.1067955	82.9522581	2026-02-01 01:13:30.121	MOVE	17.90800094604492	0.2553476095199585	273.0559997558594	\N	823	2026-02-01 01:49:40.601
824	1	1	55.1068191	82.9524869	2026-02-01 01:13:47.765	MOVE	49.44400024414062	0.4806428849697113	102.1871643066406	\N	824	2026-02-01 01:49:40.601
825	1	1	55.1067735	82.9522116	2026-02-01 01:14:06.652	MOVE	36.85200119018555	0	0	\N	825	2026-02-01 01:49:40.601
826	1	1	55.1067515	82.9519412	2026-02-01 01:14:47.772	MOVE	95.5	0.3999999761581421	26	\N	826	2026-02-01 01:49:40.601
827	1	1	55.1067729	82.9522775	2026-02-01 01:15:04.98	MOVE	16.80999946594238	0	0	\N	827	2026-02-01 01:49:40.601
828	1	1	55.1067499	82.9521474	2026-02-01 01:16:17.759	MOVE	75.5	1.057162761688232	100.027587890625	\N	828	2026-02-01 01:49:40.601
829	1	1	55.1067691	82.9522307	2026-02-01 01:16:29.393	MOVE	36.96599960327148	1.005401253700256	100.3049774169922	\N	829	2026-02-01 01:49:40.601
830	1	1	55.1068364	82.9519833	2026-02-01 01:16:46.739	MOVE	82	1.639999985694885	85	\N	830	2026-02-01 01:49:40.601
831	1	1	55.1067827	82.9522583	2026-02-01 01:17:12.574	MOVE	18.20499992370605	0	0	\N	831	2026-02-01 01:49:40.601
832	1	1	55.1068743	82.9532597	2026-02-01 01:17:47.772	MOVE	99.5	1.259999990463257	192	\N	832	2026-02-01 01:49:40.601
833	1	1	55.1067733	82.9522133	2026-02-01 01:18:06.879	MOVE	27.7189998626709	0	0	\N	833	2026-02-01 01:49:40.601
834	1	1	55.1068013	82.952956	2026-02-01 01:18:47.936	MOVE	100	1.139999985694885	273	\N	834	2026-02-01 01:49:40.601
835	1	1	55.1067755	82.9522628	2026-02-01 01:19:12.634	MOVE	17.57299995422363	0	0	\N	835	2026-02-01 01:49:40.601
836	1	1	55.1067624	82.952414	2026-02-01 01:20:48.841	MOVE	241.5	1.01999831199646	315.1366577148438	\N	836	2026-02-01 01:49:40.601
837	1	1	55.1067762	82.9522731	2026-02-01 01:20:59.444	MOVE	17.26700019836426	0.9908591508865356	312.431640625	\N	837	2026-02-01 01:49:40.601
838	1	1	55.1069166	82.9527001	2026-02-01 01:21:47.766	MOVE	119	1.620710492134094	293.1560668945312	\N	838	2026-02-01 01:49:40.601
839	1	1	55.1068022	82.9530082	2026-02-01 01:22:09.913	MOVE	45	2.701874732971191	116.6170425415039	\N	839	2026-02-01 01:49:40.601
840	1	1	55.1068339	82.9526379	2026-02-01 01:22:36.935	MOVE	42	5.509999752044678	116	\N	840	2026-02-01 01:49:40.601
841	1	1	55.1067778	82.9528683	2026-02-01 01:22:43.73	MOVE	41.13700103759766	3.332925081253052	108.9988708496094	\N	841	2026-02-01 01:49:40.601
842	1	1	55.1068023	82.9522476	2026-02-01 01:23:10.644	MOVE	18.0620002746582	0	0	\N	842	2026-02-01 01:49:40.601
843	1	1	55.106723	82.9523786	2026-02-01 01:23:31.78	MOVE	35.07600021362305	3.10891056060791	129.9333190917969	\N	843	2026-02-01 01:49:40.601
844	1	1	55.1069616	82.9521932	2026-02-01 01:23:47.749	MOVE	94.5	0.9099999666213989	52	\N	844	2026-02-01 01:49:40.601
845	1	1	55.1067809	82.9522433	2026-02-01 01:24:05.986	MOVE	18.45299911499023	0	0	\N	845	2026-02-01 01:49:40.601
846	1	1	55.1068434	82.9523246	2026-02-01 01:24:23.112	MOVE	159.0950012207031	1.3339684009552	124.0045318603516	\N	846	2026-02-01 01:49:40.601
847	1	1	55.1067814	82.95224	2026-02-01 01:24:40.229	MOVE	18.15399932861328	0	0	\N	847	2026-02-01 01:49:40.601
848	1	1	55.1069025	82.9520782	2026-02-01 01:25:48.743	MOVE	85.5	4.539999961853027	281	\N	848	2026-02-01 01:49:40.601
849	1	1	55.106765	82.9522739	2026-02-01 01:26:05.745	MOVE	23.25799942016602	0	0	\N	849	2026-02-01 01:49:40.601
850	1	1	55.1069806	82.9526276	2026-02-01 01:26:22.744	MOVE	208.5	4.339999675750732	277	\N	850	2026-02-01 01:49:40.601
851	1	1	55.1067663	82.9522649	2026-02-01 01:26:45.65	MOVE	23.42300033569336	0	0	\N	851	2026-02-01 01:49:40.601
852	1	1	55.1066217	82.9530218	2026-02-01 01:27:02.748	MOVE	170.5	17.68000030517578	278	\N	852	2026-02-01 01:49:40.601
853	1	1	55.1067863	82.9522864	2026-02-01 01:27:20.866	MOVE	31.8430004119873	0	0	\N	853	2026-02-01 01:49:40.601
854	1	1	55.1067796	82.9523782	2026-02-01 01:27:46.63	MOVE	35.38199996948242	1.557397603988647	111.6133346557617	\N	854	2026-02-01 01:49:40.601
855	1	1	55.106832	82.9525267	2026-02-01 01:28:02.73	MOVE	76.5	8.389999389648438	92	\N	855	2026-02-01 01:49:40.601
856	1	1	55.1067834	82.9522336	2026-02-01 01:28:20.887	MOVE	21.12299919128418	0	0	\N	856	2026-02-01 01:49:40.601
857	1	1	55.1068818	82.9520999	2026-02-01 01:29:02.731	MOVE	85	1.079999923706055	115	\N	857	2026-02-01 01:49:40.601
858	1	1	55.1067736	82.9522191	2026-02-01 01:29:20.937	MOVE	33.60400009155273	0	0	\N	858	2026-02-01 01:49:40.601
859	1	1	55.1068423	82.9523266	2026-02-01 01:29:45.636	MOVE	21.12199974060059	2.478958129882812	10.10782718658447	\N	859	2026-02-01 01:49:40.601
860	1	1	55.1067875	82.9530757	2026-02-01 01:30:01.742	MOVE	49	13.34999942779541	118	\N	860	2026-02-01 01:49:40.601
861	1	1	55.1067628	82.9522482	2026-02-01 01:30:20.136	MOVE	23.41200065612793	0	0	\N	861	2026-02-01 01:49:40.601
862	1	1	55.1068734	82.9527094	2026-02-01 01:31:01.744	MOVE	97	1.539999961853027	123	\N	862	2026-02-01 01:49:40.601
863	1	1	55.1067734	82.9522204	2026-02-01 01:31:19.121	MOVE	25.54700088500977	0	0	\N	863	2026-02-01 01:49:40.601
864	1	1	55.1067866	82.9525587	2026-02-01 01:31:45.066	MOVE	36.97299957275391	2.331443071365356	98.20460510253906	\N	864	2026-02-01 01:49:40.601
865	1	1	55.1067968	82.9532028	2026-02-01 01:32:02.723	MOVE	94.5	1.149999976158142	72	\N	865	2026-02-01 01:49:40.601
866	1	1	55.1067833	82.9523266	2026-02-01 01:32:19.874	MOVE	29.63999938964844	0	0	\N	866	2026-02-01 01:49:40.601
867	1	1	55.1068817	82.9529582	2026-02-01 01:33:02.706	MOVE	84	0.8199999928474426	9	\N	867	2026-02-01 01:49:40.601
868	1	1	55.106786	82.9523388	2026-02-01 01:33:20.124	MOVE	35.65399932861328	0	0	\N	868	2026-02-01 01:49:40.601
869	1	1	55.1068335	82.9525561	2026-02-01 01:34:02.743	MOVE	97	0.5999999642372131	305	\N	869	2026-02-01 01:49:40.601
870	1	1	55.1067615	82.9523156	2026-02-01 01:34:19.885	MOVE	24.8799991607666	0	0	\N	870	2026-02-01 01:49:40.601
871	1	1	55.1066891	82.9527019	2026-02-01 01:35:33.897	MOVE	138.5	1.652559876441956	232.9284973144531	\N	871	2026-02-01 01:49:40.601
872	1	1	55.1067411	82.9523197	2026-02-01 01:35:45.629	MOVE	48.56900024414062	1.695241332054138	252.0266876220703	\N	872	2026-02-01 01:49:40.601
873	1	1	55.1067774	82.952273	2026-02-01 01:36:45.78	MOVE	25.12800025939941	0.662146270275116	334.9086608886719	\N	873	2026-02-01 01:49:40.601
874	1	1	55.106962	82.9528438	2026-02-01 01:37:02.735	MOVE	93	0.8399999737739563	119	\N	874	2026-02-01 01:49:40.601
875	1	1	55.1067736	82.9522519	2026-02-01 01:37:20.955	MOVE	23.28499984741211	0	0	\N	875	2026-02-01 01:49:40.601
876	1	1	55.1068383	82.953329	2026-02-01 01:38:02.742	MOVE	108.5	1.039999961853027	350	\N	876	2026-02-01 01:49:40.601
877	1	1	55.1067879	82.9523199	2026-02-01 01:38:20.177	MOVE	38.20299911499023	0	0	\N	877	2026-02-01 01:49:40.601
878	1	1	55.106805	82.9530854	2026-02-01 01:39:02.742	MOVE	97	3.009999990463257	86	\N	878	2026-02-01 01:49:40.601
879	1	1	55.1067761	82.9522663	2026-02-01 01:39:21.842	MOVE	34.68399810791016	0	0	\N	879	2026-02-01 01:49:40.601
880	1	1	55.1067126	82.9532265	2026-02-01 01:40:02.732	MOVE	79.5	4.019999980926514	111	\N	880	2026-02-01 01:49:40.601
881	1	1	55.106782	82.9522024	2026-02-01 01:40:20.851	MOVE	24.05900001525879	0	0	\N	881	2026-02-01 01:49:40.601
882	1	1	55.1068609	82.9522764	2026-02-01 01:40:45.662	MOVE	36.06000137329102	2.203984022140503	20.58171844482422	\N	882	2026-02-01 01:49:40.601
883	1	1	55.1067256	82.9531551	2026-02-01 01:41:02.722	MOVE	164	2.909999847412109	113	\N	883	2026-02-01 01:49:40.601
884	1	1	55.1067845	82.9522882	2026-02-01 01:41:20.211	MOVE	31.59199905395508	0	0	\N	884	2026-02-01 01:49:40.601
885	1	1	55.1068442	82.9522811	2026-02-01 01:43:22.893	MOVE	47.5	1.370000004768372	285	\N	885	2026-02-01 01:49:40.601
886	1	1	55.1069514	82.9520196	2026-02-01 01:43:53.871	MOVE	46	7.659999847412109	300	\N	886	2026-02-01 01:49:40.601
887	1	1	55.1070584	82.9519377	2026-02-01 01:44:21.844	MOVE	44	7.269999980926514	293	\N	887	2026-02-01 01:49:40.601
888	1	1	55.1067834	82.9523373	2026-02-01 01:44:44.862	MOVE	31.94700050354004	0	0	\N	888	2026-02-01 01:49:40.601
889	1	1	55.1069359	82.952307	2026-02-01 01:45:00.72	MOVE	48	0.09999999403953552	0	\N	889	2026-02-01 01:49:40.601
890	1	1	55.1067848	82.9523246	2026-02-01 01:45:25.871	MOVE	37.33499908447266	0	0	\N	890	2026-02-01 01:49:40.601
891	1	1	55.106926	82.9524847	2026-02-01 01:46:32.875	MOVE	65.5	0.4599999785423279	193	\N	891	2026-02-01 01:49:40.601
892	1	1	55.1067681	82.9522564	2026-02-01 01:46:56.586	MOVE	25.23100090026855	0	0	\N	892	2026-02-01 01:49:40.601
893	1	1	55.1068299	82.9522078	2026-02-01 01:47:46.632	MOVE	24.86700057983398	0.347937136888504	318.3739624023438	\N	893	2026-02-01 01:49:40.601
894	1	1	55.1069272	82.9521752	2026-02-01 01:48:02.708	MOVE	79	1.379999995231628	300	\N	894	2026-02-01 01:49:40.601
895	1	1	55.1067693	82.9522625	2026-02-01 01:48:27.593	MOVE	30.55599975585938	0	0	\N	895	2026-02-01 01:49:40.601
896	1	1	55.1068363	82.9521876	2026-02-01 01:49:13.926	MOVE	24.14599990844727	1.044457674026489	125.3577499389648	\N	896	2026-02-01 01:49:40.601
897	1	1	55.106772	82.952284	2026-02-01 01:49:31.839	MOVE	37.81100082397461	0	0	\N	897	2026-02-01 01:49:40.601
898	1	1	55.1068379	82.9522991	2026-02-01 01:50:03.661	MOVE	71	1.612731099128723	122.4590225219727	\N	898	2026-02-01 01:50:03.807
899	1	1	55.106957	82.9520933	2026-02-01 01:50:19.705	MOVE	45.5	4.364062309265137	114.6723556518555	\N	899	2026-02-01 01:50:19.646
900	1	1	55.1067812	82.952339	2026-02-01 01:50:29.804	MOVE	42.25500106811523	3.13473105430603	126.3166046142578	\N	900	2026-02-01 01:50:44.677
901	1	1	55.1067895	82.9522355	2026-02-01 01:51:20.99	MOVE	24.67399978637695	0	0	\N	901	2026-02-01 01:57:08.978
902	1	1	55.1067626	82.9523249	2026-02-01 01:51:44.716	MOVE	29.36000061035156	2.027880907058716	112.3966293334961	\N	902	2026-02-01 01:57:08.978
903	1	1	55.106943	82.9519382	2026-02-01 01:52:35.825	MOVE	203.1479949951172	3.602063179016113	282.0611572265625	\N	903	2026-02-01 01:57:08.978
904	1	1	55.1067897	82.9523553	2026-02-01 01:52:52.824	MOVE	36.29499816894531	0	0	\N	904	2026-02-01 01:57:08.978
905	1	1	55.1068163	82.9521513	2026-02-01 01:53:15.153	MOVE	37.57300186157227	4.180073261260986	295.9645080566406	\N	905	2026-02-01 01:57:08.978
906	1	1	55.1067731	82.9523106	2026-02-01 01:53:32.19	MOVE	25.79400062561035	0	0	\N	906	2026-02-01 01:57:08.978
907	1	1	55.1068528	82.9520343	2026-02-01 01:53:49.23	MOVE	53.65499877929688	0	0	\N	907	2026-02-01 01:57:08.978
908	1	1	55.1067686	82.952352	2026-02-01 01:54:15.114	MOVE	30.21699905395508	4.91205883026123	121.6933517456055	\N	908	2026-02-01 01:57:08.978
909	1	1	55.1068909	82.9523434	2026-02-01 01:54:29.704	MOVE	49.5	2.633495569229126	297.0645751953125	\N	909	2026-02-01 01:57:08.978
910	1	1	55.1069121	82.9522725	2026-02-01 01:54:32.142	MOVE	73.87200164794922	2.627321243286133	297.1079406738281	\N	910	2026-02-01 01:57:08.978
911	1	1	55.1067771	82.9522114	2026-02-01 01:54:49.17	MOVE	25.63699913024902	0	0	\N	911	2026-02-01 01:57:08.978
912	1	1	55.1072899	82.951352	2026-02-01 01:55:06.205	MOVE	196.7570037841797	4.025949001312256	311.92138671875	\N	912	2026-02-01 01:57:08.978
913	1	1	55.1067962	82.9521862	2026-02-01 01:55:23.234	MOVE	44.90399932861328	0	0	\N	913	2026-02-01 01:57:08.978
914	1	1	55.1069286	82.9522838	2026-02-01 01:55:40.2	MOVE	229.4029998779297	0.5972759127616882	105.9748077392578	\N	914	2026-02-01 01:57:08.978
915	1	1	55.1067631	82.9522311	2026-02-01 01:55:57.267	MOVE	26.04000091552734	0	0	\N	915	2026-02-01 01:57:08.978
916	1	1	55.1067855	82.9523046	2026-02-01 01:56:31.996	MOVE	24.13999938964844	0	0	\N	916	2026-02-01 01:57:08.978
917	1	1	55.1067656	82.9524194	2026-02-01 01:56:49.075	MOVE	35.89899826049805	0	0	\N	917	2026-02-01 01:57:08.978
918	1	1	55.1068072	82.952173	2026-02-01 01:57:02.672	MOVE	72	0.894005298614502	92.01010131835938	\N	918	2026-02-01 01:57:08.978
919	1	1	55.1068192	82.9523706	2026-02-01 01:57:23.142	MOVE	49.86600112915039	0	0	\N	919	2026-02-01 02:09:14.187
920	1	1	55.1068429	82.9521274	2026-02-01 01:57:57.854	MOVE	24.05400085449219	0	0	\N	920	2026-02-01 02:09:14.187
921	1	1	55.1067985	82.9523126	2026-02-01 01:58:14.886	MOVE	36.27099990844727	0.4344198405742645	155.6275482177734	\N	921	2026-02-01 02:09:14.187
922	1	1	55.1068237	82.9521893	2026-02-01 01:58:32.697	MOVE	45.4900016784668	0.652987003326416	266.9710693359375	\N	922	2026-02-01 02:09:14.187
923	1	1	55.106782	82.9523118	2026-02-01 01:58:48.945	MOVE	37.50099945068359	0	0	\N	923	2026-02-01 02:09:14.187
924	1	1	55.1068141	82.95223	2026-02-01 01:59:06.026	MOVE	24.13999938964844	0.2350872308015823	191.3511199951172	\N	924	2026-02-01 02:09:14.187
925	1	1	55.1068613	82.9521828	2026-02-01 01:59:40.055	MOVE	237.0850067138672	0.4219894707202911	109.153450012207	\N	925	2026-02-01 02:09:14.187
926	1	1	55.1067975	82.9521978	2026-02-01 01:59:57.084	MOVE	25.75600051879883	0	0	\N	926	2026-02-01 02:09:14.187
927	1	1	55.1068102	82.9525131	2026-02-01 01:59:58.705	MOVE	37.62799835205078	0.4727778136730194	278.2943420410156	\N	927	2026-02-01 02:09:14.187
928	1	1	55.1068082	82.9521674	2026-02-01 02:00:14.122	MOVE	26.16300010681152	0	0	\N	928	2026-02-01 02:09:14.187
929	1	1	55.1067781	82.9523585	2026-02-01 02:00:31.136	MOVE	48.64099884033203	0	0	\N	929	2026-02-01 02:09:14.187
930	1	1	55.1068769	82.9521298	2026-02-01 02:00:32.67	MOVE	56.31999969482422	0.7318761944770813	271.015380859375	\N	930	2026-02-01 02:09:14.187
931	1	1	55.1067738	82.9522283	2026-02-01 02:00:48.095	MOVE	24.66900062561035	0	0	\N	931	2026-02-01 02:09:14.187
932	1	1	55.1069153	82.9520242	2026-02-01 02:01:05.112	MOVE	175.9049987792969	0.3736967742443085	83.88558959960938	\N	932	2026-02-01 02:09:14.187
933	1	1	55.1067713	82.952302	2026-02-01 02:01:22.135	MOVE	36.79899978637695	0	0	\N	933	2026-02-01 02:09:14.187
934	1	1	55.106806	82.9526191	2026-02-01 02:01:39.175	MOVE	193.1540069580078	0.1377485692501068	217.5133514404297	\N	934	2026-02-01 02:09:14.187
935	1	1	55.1068135	82.9521672	2026-02-01 02:01:56.239	MOVE	26.26300048828125	0	0	\N	935	2026-02-01 02:09:14.187
936	1	1	55.1067759	82.9523183	2026-02-01 02:02:30.312	MOVE	24.14299964904785	0	0	\N	936	2026-02-01 02:09:14.187
937	1	1	55.1068446	82.9521651	2026-02-01 02:02:47.337	MOVE	23.9069995880127	0.2534168660640717	139.5955657958984	\N	937	2026-02-01 02:09:14.187
938	1	1	55.1069366	82.9520722	2026-02-01 02:03:02.722	MOVE	61.5	0.1499999910593033	343	\N	938	2026-02-01 02:09:14.187
939	1	1	55.1067564	82.9524179	2026-02-01 02:03:21.381	MOVE	37.02199935913086	0	0	\N	939	2026-02-01 02:09:14.187
940	1	1	55.1068801	82.9519634	2026-02-01 02:03:38.397	MOVE	170.0010070800781	0.6544865965843201	89.99320220947266	\N	940	2026-02-01 02:09:14.187
941	1	1	55.1067802	82.9523079	2026-02-01 02:03:55.439	MOVE	37.50099945068359	0	0	\N	941	2026-02-01 02:09:14.187
942	1	1	55.1068153	82.9521683	2026-02-01 02:04:12.468	MOVE	25.5310001373291	0.3239455223083496	178.9491577148438	\N	942	2026-02-01 02:09:14.187
943	1	1	55.1067757	82.9523014	2026-02-01 02:04:29.47	MOVE	23.74099922180176	0	0	\N	943	2026-02-01 02:09:14.187
944	1	1	55.1068378	82.9521584	2026-02-01 02:04:46.506	MOVE	24.18400001525879	0.2151927649974823	108.8739624023438	\N	944	2026-02-01 02:09:14.187
945	1	1	55.1068996	82.9518894	2026-02-01 02:05:02.705	MOVE	62.5	1.069999933242798	287	\N	945	2026-02-01 02:09:14.187
946	1	1	55.1067889	82.9523215	2026-02-01 02:05:20.575	MOVE	24.23900032043457	0	0	\N	946	2026-02-01 02:09:14.187
947	1	1	55.1068892	82.9522965	2026-02-01 02:05:37.607	MOVE	148.4490051269531	0.2891287803649902	280.065673828125	\N	947	2026-02-01 02:09:14.187
948	1	1	55.1067798	82.9523383	2026-02-01 02:05:54.659	MOVE	31.55999946594238	0	0	\N	948	2026-02-01 02:09:14.187
949	1	1	55.1068537	82.9521716	2026-02-01 02:06:11.704	MOVE	24.23200035095215	0.7113287448883057	72.10772705078125	\N	949	2026-02-01 02:09:14.187
950	1	1	55.1067939	82.9522283	2026-02-01 02:06:28.663	MOVE	24.62100028991699	0	0	\N	950	2026-02-01 02:09:14.187
951	1	1	55.1069615	82.9521963	2026-02-01 02:07:02.702	MOVE	119	2.869999885559082	88	\N	951	2026-02-01 02:09:14.187
952	1	1	55.1067966	82.9522803	2026-02-01 02:07:19.699	MOVE	40.84700012207031	0	0	\N	952	2026-02-01 02:09:14.187
953	1	1	55.106864	82.9520203	2026-02-01 02:07:36.687	MOVE	134.1470031738281	0.7774105668067932	216.1857757568359	\N	953	2026-02-01 02:09:14.187
954	1	1	55.1067885	82.9522112	2026-02-01 02:07:59.928	MOVE	24.26600074768066	4.430587768554688	267.2147216796875	\N	954	2026-02-01 02:09:14.187
955	1	1	55.1068677	82.9520718	2026-02-01 02:08:47.69	MOVE	59	0.8298116326332092	249.0075988769531	\N	955	2026-02-01 02:09:14.187
956	1	1	55.1067678	82.9522688	2026-02-01 02:09:07.805	MOVE	29.35600090026855	0	0	\N	956	2026-02-01 02:09:14.187
957	1	1	55.1069386	82.9523412	2026-02-01 02:09:24.863	MOVE	206.0260009765625	0.1800777316093445	91.90302276611328	\N	957	2026-02-01 02:09:24.874
958	1	1	55.1067747	82.9522646	2026-02-01 02:09:41.811	MOVE	40.95700073242188	0	0	\N	958	2026-02-01 02:09:41.764
959	1	1	55.1068259	82.9522301	2026-02-01 02:10:16.705	MOVE	37.41899871826172	0.3526109457015991	91.78765869140625	\N	959	2026-02-01 02:10:31.539
960	1	1	55.1067969	82.9521599	2026-02-01 02:10:32.625	MOVE	47.96200180053711	0	0	\N	960	2026-02-01 02:10:32.545
961	1	1	55.1074062	82.9482101	2026-02-01 02:10:46.703	MOVE	139	0.5799999833106995	277	\N	961	2026-02-01 02:10:46.608
962	1	1	55.1068083	82.9521965	2026-02-01 02:11:06.508	MOVE	45.00199890136719	0	0	\N	962	2026-02-01 02:11:06.484
963	1	1	55.1069761	82.9522477	2026-02-01 02:11:23.447	MOVE	168.3320007324219	0.4290774464607239	77.95429229736328	\N	963	2026-02-01 02:11:23.381
964	1	1	55.1067758	82.9522479	2026-02-01 02:11:40.408	MOVE	26.5049991607666	0	0	\N	964	2026-02-01 02:11:40.299
965	1	1	55.1068128	82.952077	2026-02-01 02:12:31.397	MOVE	25.75	0.1592311561107635	136.5181427001953	\N	965	2026-02-01 02:31:00.466
966	1	1	55.1069412	82.9518789	2026-02-01 02:12:47.711	MOVE	63.5	0.25	121	\N	966	2026-02-01 02:31:00.466
967	1	1	55.1069568	82.9520245	2026-02-01 02:13:04.709	MOVE	47	3.349999904632568	286	\N	967	2026-02-01 02:31:00.466
968	1	1	55.1067841	82.952293	2026-02-01 02:13:22.515	MOVE	31.9689998626709	0	0	\N	968	2026-02-01 02:31:00.466
969	1	1	55.1069457	82.9528086	2026-02-01 02:14:01.638	MOVE	106.8000030517578	1.395891427993774	289.1754150390625	\N	969	2026-02-01 02:31:00.466
970	1	1	55.1067736	82.9522519	2026-02-01 02:14:18.683	MOVE	25.08300018310547	0	0	\N	970	2026-02-01 02:31:00.466
971	1	1	55.1069554	82.952191	2026-02-01 02:14:35.716	MOVE	199.3509979248047	0.2116401493549347	246.3651123046875	\N	971	2026-02-01 02:31:00.466
972	1	1	55.1068566	82.9519913	2026-02-01 02:14:52.729	MOVE	53.58700180053711	0	0	\N	972	2026-02-01 02:31:00.466
973	1	1	55.1068127	82.9522737	2026-02-01 02:15:09.786	MOVE	24.7450008392334	0.2175625115633011	303.2632446289062	\N	973	2026-02-01 02:31:00.466
974	1	1	55.1070205	82.9526542	2026-02-01 02:15:26.794	MOVE	171.3049926757812	1.413135886192322	89.98583984375	\N	974	2026-02-01 02:31:00.466
975	1	1	55.1068744	82.952014	2026-02-01 02:15:44.016	MOVE	23.47699928283691	0	0	\N	975	2026-02-01 02:31:00.466
976	1	1	55.1068061	82.9521551	2026-02-01 02:16:00.992	MOVE	26.65800094604492	0.3922569751739502	148.3194427490234	\N	976	2026-02-01 02:31:00.466
977	1	1	55.1069718	82.9515294	2026-02-01 02:16:18.032	MOVE	149.0019989013672	0.6409875154495239	275.9903564453125	\N	977	2026-02-01 02:31:00.466
978	1	1	55.1067627	82.9522676	2026-02-01 02:16:34.996	MOVE	37.03200149536133	0	0	\N	978	2026-02-01 02:31:00.466
979	1	1	55.106842	82.9521271	2026-02-01 02:16:52.025	MOVE	40.58000183105469	0.6873499155044556	265.7998657226562	\N	979	2026-02-01 02:31:00.466
980	1	1	55.1069776	82.9520739	2026-02-01 02:17:08.691	MOVE	48.5	1.299999952316284	280	\N	980	2026-02-01 02:31:00.466
981	1	1	55.1068965	82.9521889	2026-02-01 02:17:26.029	MOVE	47.00099945068359	0.8128533959388733	284.6758117675781	\N	981	2026-02-01 02:31:00.466
982	1	1	55.1067771	82.9522217	2026-02-01 02:17:59.989	MOVE	24.14800071716309	0	0	\N	982	2026-02-01 02:31:00.466
983	1	1	55.1069204	82.952438	2026-02-01 02:18:16.978	MOVE	133.6510009765625	0.3792209625244141	136.7307281494141	\N	983	2026-02-01 02:31:00.466
984	1	1	55.106766	82.9522615	2026-02-01 02:18:34.001	MOVE	26.13800048828125	0	0	\N	984	2026-02-01 02:31:00.466
985	1	1	55.1068412	82.9521604	2026-02-01 02:18:34.685	MOVE	35.56900024414062	0.5311300754547119	253.8505554199219	\N	985	2026-02-01 02:31:00.466
986	1	1	55.1069346	82.952106	2026-02-01 02:18:50.696	MOVE	46.5	0.2999999821186066	101	\N	986	2026-02-01 02:31:00.466
987	1	1	55.1068239	82.9522535	2026-02-01 02:19:08.062	MOVE	36.72100067138672	0.2112189531326294	114.3103790283203	\N	987	2026-02-01 02:31:00.466
988	1	1	55.106945	82.9523403	2026-02-01 02:19:22.705	MOVE	46.5	0.7677032351493835	259.979736328125	\N	988	2026-02-01 02:31:00.466
989	1	1	55.106813	82.9522152	2026-02-01 02:19:42.095	MOVE	24.98299980163574	0.40792515873909	261.537353515625	\N	989	2026-02-01 02:31:00.466
990	1	1	55.1068623	82.9523782	2026-02-01 02:19:59.037	MOVE	44.10900115966797	0.5764944553375244	76.33865356445312	\N	990	2026-02-01 02:31:00.466
991	1	1	55.1068992	82.9525831	2026-02-01 02:20:12.69	MOVE	44	0.7300525903701782	271.0004577636719	\N	991	2026-02-01 02:31:00.466
992	1	1	55.106773	82.9522726	2026-02-01 02:20:33.008	MOVE	26.13800048828125	0	0	\N	992	2026-02-01 02:31:00.466
993	1	1	55.1069416	82.952424	2026-02-01 02:20:49.981	MOVE	178.9839935302734	0.4004156887531281	322.9305419921875	\N	993	2026-02-01 02:31:00.466
994	1	1	55.1067956	82.9522539	2026-02-01 02:21:06.996	MOVE	23.89399909973145	0	0	\N	994	2026-02-01 02:31:00.466
995	1	1	55.1068834	82.9523331	2026-02-01 02:21:24.016	MOVE	47.89199829101562	0.3216619193553925	9.20409870147705	\N	995	2026-02-01 02:31:00.466
996	1	1	55.1068595	82.9526164	2026-02-01 02:21:37.701	MOVE	49.5	0.4319991171360016	111.8949127197266	\N	996	2026-02-01 02:31:00.466
997	1	1	55.1067873	82.9522342	2026-02-01 02:21:58.036	MOVE	23.73299980163574	0	0	\N	997	2026-02-01 02:31:00.466
998	1	1	55.1069227	82.952719	2026-02-01 02:22:14.689	MOVE	47.5	0.25	66	\N	998	2026-02-01 02:31:00.466
999	1	1	55.1067873	82.9522413	2026-02-01 02:22:32.097	MOVE	23.65200042724609	0	0	\N	999	2026-02-01 02:31:00.466
1000	1	1	55.1068843	82.9525801	2026-02-01 02:22:49.031	MOVE	153.3630065917969	0.3131074607372284	92.95014953613281	\N	1000	2026-02-01 02:31:00.466
1001	1	1	55.1067903	82.9522451	2026-02-01 02:23:06.009	MOVE	23.63599967956543	0	0	\N	1001	2026-02-01 02:31:00.466
1002	1	1	55.1068775	82.952399	2026-02-01 02:23:23.02	MOVE	155.8760070800781	0.1910548955202103	107.793830871582	\N	1002	2026-02-01 02:31:00.466
1003	1	1	55.1067777	82.9522448	2026-02-01 02:23:40.047	MOVE	22.91399955749512	0	0	\N	1003	2026-02-01 02:31:00.466
1004	1	1	55.1068286	82.9523479	2026-02-01 02:23:57.07	MOVE	38.7599983215332	0.2166194021701813	331.5667724609375	\N	1004	2026-02-01 02:31:00.466
1005	1	1	55.1068092	82.9521932	2026-02-01 02:24:14.077	MOVE	24.40099906921387	0	0	\N	1005	2026-02-01 02:31:00.466
1006	1	1	55.1068817	82.9526987	2026-02-01 02:24:47.674	MOVE	61	0.5299999713897705	281	\N	1006	2026-02-01 02:31:00.466
1007	1	1	55.1067794	82.9522699	2026-02-01 02:25:05.42	MOVE	32.35699844360352	0	0	\N	1007	2026-02-01 02:31:00.466
1008	1	1	55.1068209	82.9528206	2026-02-01 02:25:22.445	MOVE	200.9239959716797	0.9725626707077026	114.8081207275391	\N	1008	2026-02-01 02:31:00.466
1009	1	1	55.106802	82.9522078	2026-02-01 02:25:39.491	MOVE	46.01399993896484	0	0	\N	1009	2026-02-01 02:31:00.466
1010	1	1	55.1068417	82.9520459	2026-02-01 02:26:30.575	MOVE	27.68099975585938	0.9471923112869263	268.8416442871094	\N	1010	2026-02-01 02:31:00.466
1011	1	1	55.1069575	82.9519222	2026-02-01 02:26:47.672	MOVE	55	0.4199999868869781	124	\N	1011	2026-02-01 02:31:00.466
1012	1	1	55.1069157	82.9522469	2026-02-01 02:26:51.656	MOVE	49.70000076293945	2.264423131942749	290.6152648925781	\N	1012	2026-02-01 02:31:00.466
1013	1	1	55.1068486	82.9520525	2026-02-01 02:27:17.69	MOVE	47	1.759999990463257	270	\N	1013	2026-02-01 02:31:00.466
1014	1	1	55.1067881	82.9522324	2026-02-01 02:27:52.928	MOVE	24.86700057983398	0	0	\N	1014	2026-02-01 02:31:00.466
1015	1	1	55.1069617	82.9526326	2026-02-01 02:28:23.689	MOVE	47.5	0.9170048832893372	272.0115966796875	\N	1015	2026-02-01 02:31:00.466
1016	1	1	55.1067801	82.9522479	2026-02-01 02:28:44.037	MOVE	24.04199981689453	0	0	\N	1016	2026-02-01 02:31:00.466
1017	1	1	55.1068442	82.9518602	2026-02-01 02:29:01.112	MOVE	152.1990051269531	1.079627633094788	279.0047302246094	\N	1017	2026-02-01 02:31:00.466
1018	1	1	55.1067646	82.9523322	2026-02-01 02:29:18.103	MOVE	39.2239990234375	0	0	\N	1018	2026-02-01 02:31:00.466
1019	1	1	55.1067932	82.9522255	2026-02-01 02:29:35.143	MOVE	31.74799919128418	3.151939153671265	263.6793823242188	\N	1019	2026-02-01 02:31:00.466
1020	1	1	55.1068551	82.9519828	2026-02-01 02:29:52.184	MOVE	54.92599868774414	0	0	\N	1020	2026-02-01 02:31:00.466
1021	1	1	55.1067869	82.9522169	2026-02-01 02:30:09.136	MOVE	23.86800003051758	0.875740110874176	284.0694274902344	\N	1021	2026-02-01 02:31:00.466
1022	1	1	55.1068977	82.9520253	2026-02-01 02:30:25.7	MOVE	64.5	0.25	163	\N	1022	2026-02-01 02:31:00.466
1023	1	1	55.1068213	82.952148	2026-02-01 02:30:43.198	MOVE	26.03899955749512	0	0	\N	1023	2026-02-01 02:31:00.466
1024	1	1	55.1067682	82.9522595	2026-02-01 02:12:14.364	MOVE	32.53499984741211	0	0	\N	1024	2026-02-01 02:32:56.699
1025	1	1	55.1068128	82.952077	2026-02-01 02:12:31.397	MOVE	25.75	0.1592311561107635	136.5181427001953	\N	1025	2026-02-01 02:32:56.699
1026	1	1	55.1069412	82.9518789	2026-02-01 02:12:47.711	MOVE	63.5	0.25	121	\N	1026	2026-02-01 02:32:56.699
1027	1	1	55.1069568	82.9520245	2026-02-01 02:13:04.709	MOVE	47	3.349999904632568	286	\N	1027	2026-02-01 02:32:56.699
1028	1	1	55.1067841	82.952293	2026-02-01 02:13:22.515	MOVE	31.9689998626709	0	0	\N	1028	2026-02-01 02:32:56.699
1029	1	1	55.1069457	82.9528086	2026-02-01 02:14:01.638	MOVE	106.8000030517578	1.395891427993774	289.1754150390625	\N	1029	2026-02-01 02:32:56.699
1030	1	1	55.1067736	82.9522519	2026-02-01 02:14:18.683	MOVE	25.08300018310547	0	0	\N	1030	2026-02-01 02:32:56.699
1031	1	1	55.1069554	82.952191	2026-02-01 02:14:35.716	MOVE	199.3509979248047	0.2116401493549347	246.3651123046875	\N	1031	2026-02-01 02:32:56.699
1032	1	1	55.1068566	82.9519913	2026-02-01 02:14:52.729	MOVE	53.58700180053711	0	0	\N	1032	2026-02-01 02:32:56.699
1033	1	1	55.1068127	82.9522737	2026-02-01 02:15:09.786	MOVE	24.7450008392334	0.2175625115633011	303.2632446289062	\N	1033	2026-02-01 02:32:56.699
1034	1	1	55.1070205	82.9526542	2026-02-01 02:15:26.794	MOVE	171.3049926757812	1.413135886192322	89.98583984375	\N	1034	2026-02-01 02:32:56.699
1035	1	1	55.1068744	82.952014	2026-02-01 02:15:44.016	MOVE	23.47699928283691	0	0	\N	1035	2026-02-01 02:32:56.699
1036	1	1	55.1068061	82.9521551	2026-02-01 02:16:00.992	MOVE	26.65800094604492	0.3922569751739502	148.3194427490234	\N	1036	2026-02-01 02:32:56.699
1037	1	1	55.1069718	82.9515294	2026-02-01 02:16:18.032	MOVE	149.0019989013672	0.6409875154495239	275.9903564453125	\N	1037	2026-02-01 02:32:56.699
1038	1	1	55.1067627	82.9522676	2026-02-01 02:16:34.996	MOVE	37.03200149536133	0	0	\N	1038	2026-02-01 02:32:56.699
1039	1	1	55.106842	82.9521271	2026-02-01 02:16:52.025	MOVE	40.58000183105469	0.6873499155044556	265.7998657226562	\N	1039	2026-02-01 02:32:56.699
1040	1	1	55.1069776	82.9520739	2026-02-01 02:17:08.691	MOVE	48.5	1.299999952316284	280	\N	1040	2026-02-01 02:32:56.699
1041	1	1	55.1068965	82.9521889	2026-02-01 02:17:26.029	MOVE	47.00099945068359	0.8128533959388733	284.6758117675781	\N	1041	2026-02-01 02:32:56.699
1042	1	1	55.1067771	82.9522217	2026-02-01 02:17:59.989	MOVE	24.14800071716309	0	0	\N	1042	2026-02-01 02:32:56.699
1043	1	1	55.1069204	82.952438	2026-02-01 02:18:16.978	MOVE	133.6510009765625	0.3792209625244141	136.7307281494141	\N	1043	2026-02-01 02:32:56.699
1044	1	1	55.106766	82.9522615	2026-02-01 02:18:34.001	MOVE	26.13800048828125	0	0	\N	1044	2026-02-01 02:32:56.699
1045	1	1	55.1068412	82.9521604	2026-02-01 02:18:34.685	MOVE	35.56900024414062	0.5311300754547119	253.8505554199219	\N	1045	2026-02-01 02:32:56.699
1046	1	1	55.1069346	82.952106	2026-02-01 02:18:50.696	MOVE	46.5	0.2999999821186066	101	\N	1046	2026-02-01 02:32:56.699
1047	1	1	55.1068239	82.9522535	2026-02-01 02:19:08.062	MOVE	36.72100067138672	0.2112189531326294	114.3103790283203	\N	1047	2026-02-01 02:32:56.699
1048	1	1	55.106945	82.9523403	2026-02-01 02:19:22.705	MOVE	46.5	0.7677032351493835	259.979736328125	\N	1048	2026-02-01 02:32:56.699
1049	1	1	55.106813	82.9522152	2026-02-01 02:19:42.095	MOVE	24.98299980163574	0.40792515873909	261.537353515625	\N	1049	2026-02-01 02:32:56.699
1050	1	1	55.1068623	82.9523782	2026-02-01 02:19:59.037	MOVE	44.10900115966797	0.5764944553375244	76.33865356445312	\N	1050	2026-02-01 02:32:56.699
1051	1	1	55.1068992	82.9525831	2026-02-01 02:20:12.69	MOVE	44	0.7300525903701782	271.0004577636719	\N	1051	2026-02-01 02:32:56.699
1052	1	1	55.106773	82.9522726	2026-02-01 02:20:33.008	MOVE	26.13800048828125	0	0	\N	1052	2026-02-01 02:32:56.699
1053	1	1	55.1069416	82.952424	2026-02-01 02:20:49.981	MOVE	178.9839935302734	0.4004156887531281	322.9305419921875	\N	1053	2026-02-01 02:32:56.699
1054	1	1	55.1067956	82.9522539	2026-02-01 02:21:06.996	MOVE	23.89399909973145	0	0	\N	1054	2026-02-01 02:32:56.699
1055	1	1	55.1068834	82.9523331	2026-02-01 02:21:24.016	MOVE	47.89199829101562	0.3216619193553925	9.20409870147705	\N	1055	2026-02-01 02:32:56.699
1056	1	1	55.1068595	82.9526164	2026-02-01 02:21:37.701	MOVE	49.5	0.4319991171360016	111.8949127197266	\N	1056	2026-02-01 02:32:56.699
1057	1	1	55.1067873	82.9522342	2026-02-01 02:21:58.036	MOVE	23.73299980163574	0	0	\N	1057	2026-02-01 02:32:56.699
1058	1	1	55.1069227	82.952719	2026-02-01 02:22:14.689	MOVE	47.5	0.25	66	\N	1058	2026-02-01 02:32:56.699
1059	1	1	55.1067873	82.9522413	2026-02-01 02:22:32.097	MOVE	23.65200042724609	0	0	\N	1059	2026-02-01 02:32:56.699
1060	1	1	55.1068843	82.9525801	2026-02-01 02:22:49.031	MOVE	153.3630065917969	0.3131074607372284	92.95014953613281	\N	1060	2026-02-01 02:32:56.699
1061	1	1	55.1067903	82.9522451	2026-02-01 02:23:06.009	MOVE	23.63599967956543	0	0	\N	1061	2026-02-01 02:32:56.699
1062	1	1	55.1068775	82.952399	2026-02-01 02:23:23.02	MOVE	155.8760070800781	0.1910548955202103	107.793830871582	\N	1062	2026-02-01 02:32:56.699
1063	1	1	55.1067777	82.9522448	2026-02-01 02:23:40.047	MOVE	22.91399955749512	0	0	\N	1063	2026-02-01 02:32:56.699
1064	1	1	55.1068286	82.9523479	2026-02-01 02:23:57.07	MOVE	38.7599983215332	0.2166194021701813	331.5667724609375	\N	1064	2026-02-01 02:32:56.699
1065	1	1	55.1068092	82.9521932	2026-02-01 02:24:14.077	MOVE	24.40099906921387	0	0	\N	1065	2026-02-01 02:32:56.699
1066	1	1	55.1068817	82.9526987	2026-02-01 02:24:47.674	MOVE	61	0.5299999713897705	281	\N	1066	2026-02-01 02:32:56.699
1067	1	1	55.1067794	82.9522699	2026-02-01 02:25:05.42	MOVE	32.35699844360352	0	0	\N	1067	2026-02-01 02:32:56.699
1068	1	1	55.1068209	82.9528206	2026-02-01 02:25:22.445	MOVE	200.9239959716797	0.9725626707077026	114.8081207275391	\N	1068	2026-02-01 02:32:56.699
1069	1	1	55.106802	82.9522078	2026-02-01 02:25:39.491	MOVE	46.01399993896484	0	0	\N	1069	2026-02-01 02:32:56.699
1070	1	1	55.1068417	82.9520459	2026-02-01 02:26:30.575	MOVE	27.68099975585938	0.9471923112869263	268.8416442871094	\N	1070	2026-02-01 02:32:56.699
1071	1	1	55.1069575	82.9519222	2026-02-01 02:26:47.672	MOVE	55	0.4199999868869781	124	\N	1071	2026-02-01 02:32:56.699
1072	1	1	55.1069157	82.9522469	2026-02-01 02:26:51.656	MOVE	49.70000076293945	2.264423131942749	290.6152648925781	\N	1072	2026-02-01 02:32:56.699
1073	1	1	55.1068486	82.9520525	2026-02-01 02:27:17.69	MOVE	47	1.759999990463257	270	\N	1073	2026-02-01 02:32:56.699
1074	1	1	55.1067881	82.9522324	2026-02-01 02:27:52.928	MOVE	24.86700057983398	0	0	\N	1074	2026-02-01 02:32:56.699
1075	1	1	55.1069617	82.9526326	2026-02-01 02:28:23.689	MOVE	47.5	0.9170048832893372	272.0115966796875	\N	1075	2026-02-01 02:32:56.699
1076	1	1	55.1067801	82.9522479	2026-02-01 02:28:44.037	MOVE	24.04199981689453	0	0	\N	1076	2026-02-01 02:32:56.699
1077	1	1	55.1068442	82.9518602	2026-02-01 02:29:01.112	MOVE	152.1990051269531	1.079627633094788	279.0047302246094	\N	1077	2026-02-01 02:32:56.699
1078	1	1	55.1067646	82.9523322	2026-02-01 02:29:18.103	MOVE	39.2239990234375	0	0	\N	1078	2026-02-01 02:32:56.699
1079	1	1	55.1067932	82.9522255	2026-02-01 02:29:35.143	MOVE	31.74799919128418	3.151939153671265	263.6793823242188	\N	1079	2026-02-01 02:32:56.699
1080	1	1	55.1068551	82.9519828	2026-02-01 02:29:52.184	MOVE	54.92599868774414	0	0	\N	1080	2026-02-01 02:32:56.699
1081	1	1	55.1067869	82.9522169	2026-02-01 02:30:09.136	MOVE	23.86800003051758	0.875740110874176	284.0694274902344	\N	1081	2026-02-01 02:32:56.699
1082	1	1	55.1068977	82.9520253	2026-02-01 02:30:25.7	MOVE	64.5	0.25	163	\N	1082	2026-02-01 02:32:56.699
1083	1	1	55.1068213	82.952148	2026-02-01 02:30:43.198	MOVE	26.03899955749512	0	0	\N	1083	2026-02-01 02:32:56.699
1084	1	1	55.1069005	82.9519532	2026-02-01 02:31:00.236	MOVE	150.7050018310547	1.978839516639709	256.9515380859375	\N	1084	2026-02-01 02:32:56.699
1085	1	1	55.1067843	82.9525058	2026-02-01 02:31:23.439	MOVE	45.32600021362305	0.9938201904296875	130.7661285400391	\N	1085	2026-02-01 02:32:56.699
1086	1	1	55.1069586	82.9525199	2026-02-01 02:31:37.697	MOVE	48.5	0.8089115619659424	275.0128173828125	\N	1086	2026-02-01 02:32:56.699
1087	1	1	55.1068144	82.9521393	2026-02-01 02:31:57.524	MOVE	56.27700042724609	0	0	\N	1087	2026-02-01 02:32:56.699
1088	1	1	55.1067983	82.9527151	2026-02-01 02:32:15.124	MOVE	155.5390014648438	0.949867308139801	128.8985900878906	\N	1088	2026-02-01 02:32:56.699
1089	1	1	55.1067642	82.9522767	2026-02-01 02:32:32.101	MOVE	30.98299980163574	0	0	\N	1089	2026-02-01 02:32:56.699
1090	1	1	55.106732	82.9527153	2026-02-01 02:32:47.158	MOVE	177.1369934082031	0.7331728935241699	106.9160461425781	\N	1090	2026-02-01 02:32:56.699
1091	1	1	55.1067872	82.9522765	2026-02-01 02:33:04.813	MOVE	40.34000015258789	0	0	\N	1091	2026-02-01 02:33:04.606
1092	1	1	55.1068945	82.9518414	2026-02-01 02:33:40.684	MOVE	73.5	3.699999809265137	283	\N	1092	2026-02-01 02:33:40.533
1093	1	1	55.1067778	82.9522207	2026-02-01 02:33:58.792	MOVE	23.76700019836426	0	0	\N	1093	2026-02-01 02:33:59.005
1094	1	1	55.1066896	82.9529599	2026-02-01 02:34:15.717	MOVE	204.3419952392578	4.979618072509766	112.1562042236328	\N	1094	2026-02-01 02:34:15.605
1095	1	1	55.1067885	82.952287	2026-02-01 02:34:32.678	MOVE	40.10900115966797	0	0	\N	1095	2026-02-01 02:34:32.615
1096	1	1	55.1068511	82.9528354	2026-02-01 02:35:10.656	MOVE	150	0.5299999713897705	101	\N	1096	2026-02-01 02:35:10.492
1097	1	1	55.1067689	82.9522435	2026-02-01 02:35:29.636	MOVE	22.5310001373291	0	0	\N	1097	2026-02-01 02:41:29.754
1098	1	1	55.106895	82.952838	2026-02-01 02:36:10.677	MOVE	102	0.5	104	\N	1098	2026-02-01 02:41:29.754
1099	1	1	55.1067738	82.9522718	2026-02-01 02:36:27.801	MOVE	30.40500068664551	0	0	\N	1099	2026-02-01 02:41:29.754
1100	1	1	55.1067486	82.9527314	2026-02-01 02:37:10.659	MOVE	61.5	0.6399999856948853	85	\N	1100	2026-02-01 02:41:29.754
1101	1	1	55.1067731	82.9522487	2026-02-01 02:37:28.809	MOVE	22.61300086975098	0	0	\N	1101	2026-02-01 02:41:29.754
1102	1	1	55.1067637	82.9527925	2026-02-01 02:37:46.159	MOVE	158.5449981689453	3.189836502075195	117.0491790771484	\N	1102	2026-02-01 02:41:29.754
1103	1	1	55.1067705	82.9522445	2026-02-01 02:38:03.225	MOVE	23.04299926757812	0	0	\N	1103	2026-02-01 02:41:29.754
1104	1	1	55.1069556	82.9522311	2026-02-01 02:39:10.675	MOVE	83	0.5799999833106995	301	\N	1104	2026-02-01 02:41:29.754
1105	1	1	55.1067904	82.9523056	2026-02-01 02:39:29.106	MOVE	38.4109992980957	0	0	\N	1105	2026-02-01 02:41:29.754
1106	1	1	55.1069462	82.9522965	2026-02-01 02:39:46.129	MOVE	162.1360015869141	0.5285926461219788	292.1304016113281	\N	1106	2026-02-01 02:41:29.754
1107	1	1	55.1067646	82.9522442	2026-02-01 02:40:03.357	MOVE	22.9069995880127	0	0	\N	1107	2026-02-01 02:41:29.754
1108	1	1	55.1069846	82.9519616	2026-02-01 02:40:36.679	MOVE	44.75	2.309784650802612	291.844970703125	\N	1108	2026-02-01 02:41:29.754
1109	1	1	55.1067646	82.9522539	2026-02-01 02:40:55.812	MOVE	22.39299964904785	0	0	\N	1109	2026-02-01 02:41:29.754
1110	1	1	55.1068967	82.9521124	2026-02-01 02:41:10.679	MOVE	73	12.513596534729	274.1478576660156	\N	1110	2026-02-01 02:41:29.754
1111	1	1	55.1068966	82.9523016	2026-02-01 02:41:36.664	MOVE	49.5	0.2382580190896988	237.8623657226562	\N	1111	2026-02-01 02:53:43.507
1112	1	1	55.1067818	82.9522602	2026-02-01 02:41:57.559	MOVE	30.45999908447266	0	0	\N	1112	2026-02-01 02:53:43.507
1113	1	1	55.1070045	82.9517632	2026-02-01 02:42:14.562	MOVE	183.6150054931641	1.092315793037415	299.95947265625	\N	1113	2026-02-01 02:53:43.507
1114	1	1	55.106771	82.9522461	2026-02-01 02:42:31.618	MOVE	23.35000038146973	0	0	\N	1114	2026-02-01 02:53:43.507
1115	1	1	55.1068201	82.9521377	2026-02-01 02:42:48.607	MOVE	47.37400054931641	0.3489662706851959	99.28237915039062	\N	1115	2026-02-01 02:53:43.507
1116	1	1	55.1067695	82.9522508	2026-02-01 02:43:05.714	MOVE	22.49099922180176	0	0	\N	1116	2026-02-01 02:53:43.507
1117	1	1	55.106962	82.9515248	2026-02-01 02:43:36.671	MOVE	47.25	6.882212162017822	277.0069885253906	\N	1117	2026-02-01 02:53:43.507
1118	1	1	55.1069837	82.9512011	2026-02-01 02:43:39.791	MOVE	108.8759994506836	6.8715500831604	277.0155334472656	\N	1118	2026-02-01 02:53:43.507
1119	1	1	55.1067857	82.9522741	2026-02-01 02:43:56.809	MOVE	41.03799819946289	0	0	\N	1119	2026-02-01 02:53:43.507
1120	1	1	55.1068909	82.9525494	2026-02-01 02:44:10.672	MOVE	64	0.1714274138212204	55.14304351806641	\N	1120	2026-02-01 02:53:43.507
1121	1	1	55.1067739	82.9522451	2026-02-01 02:44:30.822	MOVE	22.4379997253418	0	0	\N	1121	2026-02-01 02:53:43.507
1122	1	1	55.1068319	82.9517779	2026-02-01 02:44:47.862	MOVE	209.1009979248047	2.746922969818115	261.9735412597656	\N	1122	2026-02-01 02:53:43.507
1123	1	1	55.1068356	82.9521155	2026-02-01 02:45:04.896	MOVE	56.71200180053711	0	0	\N	1123	2026-02-01 02:53:43.507
1124	1	1	55.1067893	82.9522549	2026-02-01 02:45:21.942	MOVE	22.11700057983398	0.709982693195343	61.18963241577148	\N	1124	2026-02-01 02:53:43.507
1125	1	1	55.1068313	82.9523799	2026-02-01 02:45:56.278	MOVE	34.07799911499023	2.666208744049072	47.61399841308594	\N	1125	2026-02-01 02:53:43.507
1126	1	1	55.1067882	82.9522702	2026-02-01 02:46:13.286	MOVE	40.32799911499023	0	0	\N	1126	2026-02-01 02:53:43.507
1127	1	1	55.1077918	82.9363506	2026-02-01 02:46:33.568	MOVE	641.447998046875	46.64718627929688	277.1021728515625	\N	1127	2026-02-01 02:53:43.507
1128	1	1	55.1067845	82.952281	2026-02-01 02:46:50.629	MOVE	32.22800064086914	0	0	\N	1128	2026-02-01 02:53:43.507
1129	1	1	55.1073909	82.9481179	2026-02-01 02:47:08.228	MOVE	419.4200134277344	0	0	\N	1129	2026-02-01 02:53:43.507
1130	1	1	55.1067764	82.9522239	2026-02-01 02:47:25.273	MOVE	43.68999862670898	0	0	\N	1130	2026-02-01 02:53:43.507
1131	1	1	55.1070014	82.9527737	2026-02-01 02:47:59.62	MOVE	124.5	14.55999946594238	280	\N	1131	2026-02-01 02:53:43.507
1132	1	1	55.1067926	82.9523027	2026-02-01 02:48:17.822	MOVE	48.28200149536133	0	0	\N	1132	2026-02-01 02:53:43.507
1133	1	1	55.1068201	82.9521548	2026-02-01 02:49:28.556	MOVE	54.54299926757812	0	0	\N	1133	2026-02-01 02:53:43.507
1134	1	1	55.106933	82.9521327	2026-02-01 02:49:44.659	MOVE	84	1.419999957084656	288	\N	1134	2026-02-01 02:53:43.507
1135	1	1	55.1067908	82.9522563	2026-02-01 02:50:02.789	MOVE	40.72299957275391	0	0	\N	1135	2026-02-01 02:53:43.507
1136	1	1	55.1067627	82.952383	2026-02-01 02:50:27.795	MOVE	29.43899917602539	2.427393436431885	114.4422378540039	\N	1136	2026-02-01 02:53:43.507
1137	1	1	55.1070056	82.9519521	2026-02-01 02:50:43.66	MOVE	121.5	1.659999966621399	298	\N	1137	2026-02-01 02:53:43.507
1138	1	1	55.1067806	82.9522814	2026-02-01 02:51:01.787	MOVE	32.08300018310547	0	0	\N	1138	2026-02-01 02:53:43.507
1139	1	1	55.10683	82.9520875	2026-02-01 02:52:14.661	MOVE	110	15.9022216796875	237.4435882568359	\N	1139	2026-02-01 02:53:43.507
1140	1	1	55.1067657	82.9522416	2026-02-01 02:52:28.622	MOVE	29.47299957275391	1.836108803749084	206.2707977294922	\N	1140	2026-02-01 02:53:43.507
1141	1	1	55.106833	82.952743	2026-02-01 02:52:43.619	MOVE	104.5	2.471259832382202	271.0144653320312	\N	1141	2026-02-01 02:53:43.507
1142	1	1	55.1067764	82.9522241	2026-02-01 02:53:02.694	MOVE	24.03700065612793	0	0	\N	1142	2026-02-01 02:53:43.507
1143	1	1	55.1069863	82.9528277	2026-02-01 02:53:44.623	MOVE	169	3.639999866485596	302	\N	1143	2026-02-01 02:53:44.533
1144	1	1	55.1067865	82.9522865	2026-02-01 02:54:02.277	MOVE	38.52999877929688	0	0	\N	1144	2026-02-01 02:54:02.219
1145	1	1	55.1069717	82.9529113	2026-02-01 02:54:43.624	MOVE	108	1	94	\N	1145	2026-02-01 03:10:53.922
1146	1	1	55.1067908	82.9522563	2026-02-01 02:55:02.813	MOVE	40.72299957275391	0	0	\N	1146	2026-02-01 03:10:53.922
1147	1	1	55.1070466	82.9526343	2026-02-01 02:55:43.633	MOVE	76.5	0.9799999594688416	299	\N	1147	2026-02-01 03:10:53.922
1148	1	1	55.1067659	82.9522535	2026-02-01 02:56:01.924	MOVE	22.49399948120117	0	0	\N	1148	2026-02-01 03:10:53.922
1149	1	1	55.1068678	82.9522023	2026-02-01 02:56:28.579	MOVE	40.48699951171875	2.152033805847168	295.4690856933594	\N	1149	2026-02-01 03:10:53.922
1150	1	1	55.1069204	82.9528128	2026-02-01 02:56:43.616	MOVE	67.5	3.039999961853027	85	\N	1150	2026-02-01 03:10:53.922
1151	1	1	55.1067771	82.9522272	2026-02-01 02:57:02.638	MOVE	24.18099975585938	0	0	\N	1151	2026-02-01 03:10:53.922
1152	1	1	55.1069317	82.951799	2026-02-01 02:57:43.636	MOVE	62	0.8499999642372131	250	\N	1152	2026-02-01 03:10:53.922
1153	1	1	55.1068906	82.9521502	2026-02-01 02:58:01.639	MOVE	42	1.279999971389771	338	\N	1153	2026-02-01 03:10:53.922
1154	1	1	55.1067769	82.9522289	2026-02-01 02:58:19.832	MOVE	24.00900077819824	0	0	\N	1154	2026-02-01 03:10:53.922
1155	1	1	55.1068061	82.9523486	2026-02-01 02:58:36.852	MOVE	43.09199905395508	1.306329488754272	74.34139251708984	\N	1155	2026-02-01 03:10:53.922
1156	1	1	55.1069258	82.952097	2026-02-01 02:58:50.658	MOVE	46	1.082331299781799	89.98998260498047	\N	1156	2026-02-01 03:10:53.922
1157	1	1	55.1067656	82.9522518	2026-02-01 02:59:11.366	MOVE	21.88400077819824	0	0	\N	1157	2026-02-01 03:10:53.922
1158	1	1	55.1069385	82.9524724	2026-02-01 03:00:01.628	MOVE	40.5	3.435315132141113	102.0983581542969	\N	1158	2026-02-01 03:10:53.922
1159	1	1	55.1068284	82.9521275	2026-02-01 03:00:19.804	MOVE	46.02199935913086	0	0	\N	1159	2026-02-01 03:10:53.922
1160	1	1	55.106776	82.9522275	2026-02-01 03:00:44.175	MOVE	23.85799980163574	0	0	\N	1160	2026-02-01 03:10:53.922
1161	1	1	55.106873	82.9526321	2026-02-01 03:00:58.609	MOVE	62	0.9778783321380615	312.1072387695312	\N	1161	2026-02-01 03:10:53.922
1162	1	1	55.1067685	82.9522543	2026-02-01 03:01:18.222	MOVE	22.72599983215332	0	0	\N	1162	2026-02-01 03:10:53.922
1163	1	1	55.1067624	82.9520625	2026-02-01 03:02:33.36	MOVE	154.2220001220703	1.525986790657043	119.2021789550781	\N	1163	2026-02-01 03:10:53.922
1164	1	1	55.1067747	82.9522279	2026-02-01 03:02:50.373	MOVE	24.03700065612793	0	0	\N	1164	2026-02-01 03:10:53.922
1165	1	1	55.1069098	82.9523608	2026-02-01 03:03:28.622	MOVE	72.5	1.34648585319519	36.98418807983398	\N	1165	2026-02-01 03:10:53.922
1166	1	1	55.1067769	82.952226	2026-02-01 03:03:44.516	MOVE	24.25399971008301	0	0	\N	1166	2026-02-01 03:10:53.922
1167	1	1	55.1069169	82.9522286	2026-02-01 03:03:59.605	MOVE	89.5	0.7799999713897705	257	\N	1167	2026-02-01 03:10:53.922
1168	1	1	55.1067734	82.9522349	2026-02-01 03:04:18.458	MOVE	23.74900054931641	0	0	\N	1168	2026-02-01 03:10:53.922
1169	1	1	55.1068514	82.9520552	2026-02-01 03:04:43.551	MOVE	45.88299942016602	1.26678740978241	265.3104553222656	\N	1169	2026-02-01 03:10:53.922
1170	1	1	55.1067654	82.9522501	2026-02-01 03:05:15.58	MOVE	22.19700050354004	0	0	\N	1170	2026-02-01 03:10:53.922
1171	1	1	55.1068524	82.9524421	2026-02-01 03:05:32.602	MOVE	147.0789947509766	0.8369001746177673	197.1369323730469	\N	1171	2026-02-01 03:10:53.922
1172	1	1	55.1067697	82.9522486	2026-02-01 03:05:49.652	MOVE	22.49600028991699	0	0	\N	1172	2026-02-01 03:10:53.922
1173	1	1	55.106794	82.9525452	2026-02-01 03:06:06.634	MOVE	213.8789978027344	0.7442201972007751	208.9894104003906	\N	1173	2026-02-01 03:10:53.922
1174	1	1	55.1069645	82.9527215	2026-02-01 03:06:23.648	MOVE	44	1.769999980926514	133	\N	1174	2026-02-01 03:10:53.922
1175	1	1	55.106765	82.9523077	2026-02-01 03:06:41.294	MOVE	27.47800064086914	0	0	\N	1175	2026-02-01 03:10:53.922
1176	1	1	55.1067756	82.9522265	2026-02-01 03:07:44.518	MOVE	24.03700065612793	0	0	\N	1176	2026-02-01 03:10:53.922
1177	1	1	55.1068414	82.9521375	2026-02-01 03:07:58.598	MOVE	56	2.246005773544312	261.9601135253906	\N	1177	2026-02-01 03:10:53.922
1178	1	1	55.1067798	82.952181	2026-02-01 03:08:13.504	MOVE	24.18099975585938	1.27086341381073	255.3505249023438	\N	1178	2026-02-01 03:10:53.922
1179	1	1	55.1068782	82.9528403	2026-02-01 03:08:28.596	MOVE	55	0.4399999976158142	245	\N	1179	2026-02-01 03:10:53.922
1180	1	1	55.1067658	82.9522533	2026-02-01 03:08:47.434	MOVE	22.49600028991699	0	0	\N	1180	2026-02-01 03:10:53.922
1181	1	1	55.1068384	82.9523548	2026-02-01 03:10:13.296	MOVE	22.83699989318848	2.800018072128296	39.40108108520508	\N	1181	2026-02-01 03:10:53.922
1182	1	1	55.1068474	82.9528417	2026-02-01 03:10:28.617	MOVE	103	2.429999828338623	250	\N	1182	2026-02-01 03:10:53.922
1183	1	1	55.1067708	82.9522426	2026-02-01 03:10:47.35	MOVE	23.48999977111816	0	0	\N	1183	2026-02-01 03:10:53.922
1184	1	1	55.1068683	82.9521778	2026-02-01 03:11:04.444	MOVE	185.5859985351562	1.293913125991821	100.1476211547852	\N	1184	2026-02-01 03:34:01.832
1185	1	1	55.1067686	82.9522715	2026-02-01 03:11:21.463	MOVE	31.31599998474121	0	0	\N	1185	2026-02-01 03:34:01.832
1186	1	1	55.1067831	82.9524684	2026-02-01 03:11:58.64	MOVE	60	1.129999995231628	219	\N	1186	2026-02-01 03:34:01.832
1187	1	1	55.1067684	82.952267	2026-02-01 03:12:15.63	MOVE	31.40099906921387	0	0	\N	1187	2026-02-01 03:34:01.832
1188	1	1	55.1068076	82.9527705	2026-02-01 03:12:32.654	MOVE	134.1029968261719	0.7115350961685181	301.3823547363281	\N	1188	2026-02-01 03:34:01.832
1189	1	1	55.106768	82.9522497	2026-02-01 03:12:49.651	MOVE	21.88400077819824	0	0	\N	1189	2026-02-01 03:34:01.832
1190	1	1	55.106814	82.9525328	2026-02-01 03:13:58.633	MOVE	60.5	1.870000004768372	291	\N	1190	2026-02-01 03:34:01.832
1191	1	1	55.106768	82.9522518	2026-02-01 03:14:17.109	MOVE	23.17399978637695	0	0	\N	1191	2026-02-01 03:34:01.832
1192	1	1	55.1069195	82.9527204	2026-02-01 03:14:59.614	MOVE	68.5	1.459999918937683	95	\N	1192	2026-02-01 03:34:01.832
1193	1	1	55.1067656	82.9522706	2026-02-01 03:15:16.576	MOVE	21.87199974060059	0	0	\N	1193	2026-02-01 03:34:01.832
1194	1	1	55.1068084	82.9528252	2026-02-01 03:15:33.627	MOVE	157.2870025634766	2.558580160140991	98.02092742919922	\N	1194	2026-02-01 03:34:01.832
1195	1	1	55.1067711	82.9522514	2026-02-01 03:15:50.644	MOVE	22.66300010681152	0	0	\N	1195	2026-02-01 03:34:01.832
1196	1	1	55.1068031	82.9521766	2026-02-01 03:16:12.332	MOVE	23.6299991607666	4.010416984558105	297.8128662109375	\N	1196	2026-02-01 03:34:01.832
1197	1	1	55.1068253	82.9529883	2026-02-01 03:16:29.581	MOVE	111	0.4899999797344208	165	\N	1197	2026-02-01 03:34:01.832
1198	1	1	55.1067771	82.9522318	2026-02-01 03:16:46.435	MOVE	23.38599967956543	0	0	\N	1198	2026-02-01 03:34:01.832
1199	1	1	55.1069822	82.9522232	2026-02-01 03:17:03.433	MOVE	177.8430023193359	0.7930365800857544	39.51672744750977	\N	1199	2026-02-01 03:34:01.832
1200	1	1	55.1067704	82.9522538	2026-02-01 03:17:20.432	MOVE	22.72999954223633	0	0	\N	1200	2026-02-01 03:34:01.832
1201	1	1	55.1068303	82.952576	2026-02-01 03:18:28.587	MOVE	88	0.4581055045127869	304.1710815429688	\N	1201	2026-02-01 03:34:01.832
1202	1	1	55.1067733	82.952253	2026-02-01 03:18:47.757	MOVE	22.49200057983398	0	0	\N	1202	2026-02-01 03:34:01.832
1203	1	1	55.1067957	82.9521425	2026-02-01 03:19:12.353	MOVE	24.13199996948242	4.10909366607666	284.4352416992188	\N	1203	2026-02-01 03:34:01.832
1204	1	1	55.1067746	82.9522322	2026-02-01 03:19:29.352	MOVE	23.30200004577637	0	0	\N	1204	2026-02-01 03:34:01.832
1205	1	1	55.1067718	82.9523172	2026-02-01 03:19:29.602	MOVE	84.5	5.003518581390381	289.3782958984375	\N	1205	2026-02-01 03:34:01.832
1206	1	1	55.1067973	82.952122	2026-02-01 03:20:12.07	MOVE	23.38800048828125	1.706276893615723	280.5459594726562	\N	1206	2026-02-01 03:34:01.832
1207	1	1	55.1067747	82.9522667	2026-02-01 03:20:29.115	MOVE	30.11899948120117	0	0	\N	1207	2026-02-01 03:34:01.832
1208	1	1	55.106811	82.9521425	2026-02-01 03:21:12.659	MOVE	22.66300010681152	4.602704524993896	299.7029113769531	\N	1208	2026-02-01 03:34:01.832
1209	1	1	55.1068104	82.9518059	2026-02-01 03:21:28.605	MOVE	138	1	150	\N	1209	2026-02-01 03:34:01.832
1210	1	1	55.1067757	82.9522537	2026-02-01 03:21:46.743	MOVE	22.82600021362305	0	0	\N	1210	2026-02-01 03:34:01.832
1211	1	1	55.1068148	82.952131	2026-02-01 03:22:00.578	MOVE	149.5	6.005606651306152	287.4061584472656	\N	1211	2026-02-01 03:34:01.832
1212	1	1	55.1067802	82.952222	2026-02-01 03:22:12.506	MOVE	23.14299964904785	1.674576640129089	313.7801818847656	\N	1212	2026-02-01 03:34:01.832
1213	1	1	55.106903	82.9524684	2026-02-01 03:22:28.598	MOVE	115	3.069999933242798	94	\N	1213	2026-02-01 03:34:01.832
1214	1	1	55.106774	82.9522382	2026-02-01 03:22:46.735	MOVE	22.19400024414062	0	0	\N	1214	2026-02-01 03:34:01.832
1215	1	1	55.106826	82.9521511	2026-02-01 03:23:00.625	MOVE	240.5	3.842363119125366	286.1777038574219	\N	1215	2026-02-01 03:34:01.832
1216	1	1	55.1067778	82.9522269	2026-02-01 03:23:12.354	MOVE	22.66300010681152	2.926254749298096	290.0077819824219	\N	1216	2026-02-01 03:34:01.832
1217	1	1	55.1069058	82.9527171	2026-02-01 03:24:03.615	MOVE	179.8970031738281	0.5736857652664185	56.12984848022461	\N	1217	2026-02-01 03:34:01.832
1218	1	1	55.1067764	82.9522293	2026-02-01 03:24:20.558	MOVE	23.6299991607666	0	0	\N	1218	2026-02-01 03:34:01.832
1219	1	1	55.1067707	82.9523531	2026-02-01 03:24:37.555	MOVE	22.66399955749512	2.102812767028809	115.1003799438477	\N	1219	2026-02-01 03:34:01.832
1220	1	1	55.1067673	82.9522608	2026-02-01 03:24:54.595	MOVE	21.93899917602539	0	0	\N	1220	2026-02-01 03:34:01.832
1221	1	1	55.1069365	82.9528392	2026-02-01 03:25:28.611	MOVE	72.5	10.90999984741211	83	\N	1221	2026-02-01 03:34:01.832
1222	1	1	55.1067712	82.9522423	2026-02-01 03:25:45.696	MOVE	23.125	0	0	\N	1222	2026-02-01 03:34:01.832
1223	1	1	55.1068283	82.9523173	2026-02-01 03:25:59.587	MOVE	75.5	0.8869547843933105	252.9565277099609	\N	1223	2026-02-01 03:34:01.832
1224	1	1	55.1067757	82.9522385	2026-02-01 03:26:19.78	MOVE	23.42399978637695	0	0	\N	1224	2026-02-01 03:34:01.832
1225	1	1	55.1068776	82.9528561	2026-02-01 03:26:37.362	MOVE	287.3080139160156	3.808122634887695	72.66786193847656	\N	1225	2026-02-01 03:34:01.832
1226	1	1	55.106769	82.9522642	2026-02-01 03:26:54.407	MOVE	21.34600067138672	0	0	\N	1226	2026-02-01 03:34:01.832
1227	1	1	55.1069279	82.9526574	2026-02-01 03:29:48.395	MOVE	161.3390045166016	1.008583307266235	83.95525360107422	\N	1227	2026-02-01 03:34:01.832
1228	1	1	55.1067702	82.9522429	2026-02-01 03:30:05.454	MOVE	23.60700035095215	0	0	\N	1228	2026-02-01 03:34:01.832
1229	1	1	55.1068151	82.9522872	2026-02-01 03:30:22.487	MOVE	23.94799995422363	1.30986225605011	49.22992706298828	\N	1229	2026-02-01 03:34:01.832
1230	1	1	55.1067017	82.9518818	2026-02-01 03:30:38.619	MOVE	49.5	0.2299999892711639	260	\N	1230	2026-02-01 03:34:01.832
1231	1	1	55.1067699	82.9522431	2026-02-01 03:30:56.5	MOVE	23.60700035095215	0	0	\N	1231	2026-02-01 03:34:01.832
1232	1	1	55.1068948	82.9521777	2026-02-01 03:31:10.613	MOVE	47.5	0.19949671626091	83.89476776123047	\N	1232	2026-02-01 03:34:01.832
1233	1	1	55.106779	82.9522732	2026-02-01 03:31:30.481	MOVE	30.06800079345703	0	0	\N	1233	2026-02-01 03:34:01.832
1234	1	1	55.1068415	82.9522833	2026-02-01 03:31:47.528	MOVE	132.2220001220703	0.3086312413215637	209.1056976318359	\N	1234	2026-02-01 03:34:01.832
1235	1	1	55.1067733	82.9522749	2026-02-01 03:32:04.588	MOVE	29.30200004577637	0	0	\N	1235	2026-02-01 03:34:01.832
1236	1	1	55.106825	82.9521741	2026-02-01 03:32:21.634	MOVE	23.51600074768066	1.460603475570679	301.880615234375	\N	1236	2026-02-01 03:34:01.832
1237	1	1	55.1067674	82.9522444	2026-02-01 03:32:38.639	MOVE	23.22200012207031	0	0	\N	1237	2026-02-01 03:34:01.832
1238	1	1	55.1067765	82.95235	2026-02-01 03:32:55.616	MOVE	37.24300003051758	0.5822787284851074	101.8251953125	\N	1238	2026-02-01 03:34:01.832
1239	1	1	55.1067855	82.9521985	2026-02-01 03:33:12.556	MOVE	24.55200004577637	0	0	\N	1239	2026-02-01 03:34:01.832
1240	1	1	55.1068621	82.9520771	2026-02-01 03:33:29.577	MOVE	24.15200042724609	0	0	\N	1240	2026-02-01 03:34:01.832
1241	1	1	55.107035	82.9523225	2026-02-01 03:33:43.583	MOVE	52.5	0.948257327079773	293.0585327148438	\N	1241	2026-02-01 03:34:01.832
1242	1	1	55.1067689	82.9522724	2026-02-01 03:34:03.593	MOVE	31.82900047302246	0	0	\N	1242	2026-02-01 03:34:03.445
1243	1	1	55.106819	82.9528419	2026-02-01 03:34:44.607	MOVE	53	11.25	91	\N	1243	2026-02-01 03:49:51.916
1244	1	1	55.1067724	82.9523661	2026-02-01 03:34:57.851	MOVE	30.99200057983398	1.584773302078247	98.3034439086914	\N	1244	2026-02-01 03:49:51.916
1245	1	1	55.1067785	82.9522144	2026-02-01 03:35:14.816	MOVE	24.70599937438965	0	0	\N	1245	2026-02-01 03:49:51.916
1246	1	1	55.1064998	82.9533885	2026-02-01 03:45:31.636	MOVE	261.1310119628906	1.162014484405518	35.75797271728516	\N	1246	2026-02-01 03:49:51.916
1247	1	1	55.1067671	82.9522885	2026-02-01 03:45:48.643	MOVE	38.26800155639648	0	0	\N	1247	2026-02-01 03:49:51.916
1248	1	1	55.106862	82.9520056	2026-02-01 03:46:59.604	MOVE	107	0.7599999904632568	14	\N	1248	2026-02-01 03:49:51.916
1249	1	1	55.1067852	82.9522813	2026-02-01 03:47:17.379	MOVE	34.46099853515625	0	0	\N	1249	2026-02-01 03:49:51.916
1250	1	1	55.1067514	82.9526907	2026-02-01 03:47:34.41	MOVE	195.6739959716797	1.760380029678345	149.7269744873047	\N	1250	2026-02-01 03:49:51.916
1251	1	1	55.1067817	82.9522869	2026-02-01 03:47:51.452	MOVE	37.24399948120117	0	0	\N	1251	2026-02-01 03:49:51.916
1252	1	1	55.1071299	82.9521477	2026-02-01 03:48:56.594	MOVE	48.5	4.671724319458008	314.0762634277344	\N	1252	2026-02-01 03:49:51.916
1253	1	1	55.1068004	82.9522865	2026-02-01 03:49:11.729	MOVE	31.32900047302246	0	0	\N	1253	2026-02-01 03:49:51.916
1254	1	1	55.1066433	82.9526504	2026-02-01 03:49:28.592	MOVE	96	0.9699999690055847	315	\N	1254	2026-02-01 03:49:51.916
1255	1	1	55.1067772	82.9522793	2026-02-01 03:49:45.715	MOVE	30.41300010681152	0	0	\N	1255	2026-02-01 03:49:51.916
1256	1	1	55.1068767	82.9524402	2026-02-01 03:50:02.853	MOVE	141.3549957275391	0.6677281856536865	324.2383422851562	\N	1256	2026-02-01 04:05:57.865
1257	1	1	55.1067875	82.9523126	2026-02-01 03:50:19.873	MOVE	49.2400016784668	0	0	\N	1257	2026-02-01 04:05:57.865
1258	1	1	55.106749	82.9531411	2026-02-01 03:50:58.564	MOVE	108	0.5399999618530273	260	\N	1258	2026-02-01 04:05:57.865
1259	1	1	55.1067972	82.9522557	2026-02-01 03:51:16.515	MOVE	41.72700119018555	0	0	\N	1259	2026-02-01 04:05:57.865
1260	1	1	55.1070448	82.9522181	2026-02-01 03:51:33.523	MOVE	179.7310028076172	1.032708048820496	338.0879821777344	\N	1260	2026-02-01 04:05:57.865
1261	1	1	55.1067749	82.9522306	2026-02-01 03:51:50.565	MOVE	24.13500022888184	0	0	\N	1261	2026-02-01 04:05:57.865
1262	1	1	55.1068621	82.9526146	2026-02-01 03:52:28.587	MOVE	104.5	0.4199999868869781	276	\N	1262	2026-02-01 04:05:57.865
1263	1	1	55.1067703	82.9522757	2026-02-01 03:52:46.727	MOVE	31.33399963378906	0	0	\N	1263	2026-02-01 04:05:57.865
1264	1	1	55.1067817	82.9533163	2026-02-01 03:53:28.58	MOVE	84	0.9699999690055847	337	\N	1264	2026-02-01 04:05:57.865
1265	1	1	55.1067973	82.952257	2026-02-01 03:53:46.316	MOVE	42.48600006103516	0	0	\N	1265	2026-02-01 04:05:57.865
1266	1	1	55.1067905	82.952364	2026-02-01 03:54:12.71	MOVE	35.72200012207031	0.1158491745591164	37.62030792236328	\N	1266	2026-02-01 04:05:57.865
1267	1	1	55.1069617	82.9521401	2026-02-01 03:54:28.568	MOVE	52	0.5699999928474426	299	\N	1267	2026-02-01 04:05:57.865
1268	1	1	55.1067662	82.9522511	2026-02-01 03:54:53.606	MOVE	23.19300079345703	0	0	\N	1268	2026-02-01 04:05:57.865
1269	1	1	55.1070028	82.9520325	2026-02-01 03:55:28.733	MOVE	61	5.309999942779541	304	\N	1269	2026-02-01 04:05:57.865
1270	1	1	55.1067884	82.9522107	2026-02-01 03:55:42.254	MOVE	22.76300048828125	3.602073431015015	305.0508117675781	\N	1270	2026-02-01 04:05:57.865
1271	1	1	55.1067318	82.9524676	2026-02-01 03:55:58.575	MOVE	97	0.7599999904632568	282	\N	1271	2026-02-01 04:05:57.865
1272	1	1	55.1067781	82.9522271	2026-02-01 03:56:16.817	MOVE	24.27700042724609	0	0	\N	1272	2026-02-01 04:05:57.865
1273	1	1	55.1066048	82.9532425	2026-02-01 03:56:58.715	MOVE	90.5	1.57001531124115	121.7979125976562	\N	1273	2026-02-01 04:05:57.865
1274	1	1	55.106754	82.9523153	2026-02-01 03:57:13.214	MOVE	23.77499961853027	0.5681470036506653	172.4863128662109	\N	1274	2026-02-01 04:05:57.865
1275	1	1	55.1065686	82.9534627	2026-02-01 03:57:28.733	MOVE	99.5	1.009999990463257	131	\N	1275	2026-02-01 04:05:57.865
1276	1	1	55.1067796	82.9522844	2026-02-01 03:57:53.707	MOVE	39.50299835205078	0	0	\N	1276	2026-02-01 04:05:57.865
1277	1	1	55.1066402	82.9537367	2026-02-01 03:58:28.572	MOVE	188.5	1.049999952316284	123	\N	1277	2026-02-01 04:05:57.865
1278	1	1	55.1067657	82.9522593	2026-02-01 03:58:43.726	MOVE	22.79899978637695	0	0	\N	1278	2026-02-01 04:05:57.865
1279	1	1	55.106707	82.9535925	2026-02-01 03:58:58.737	MOVE	169	1.569999933242798	40	\N	1279	2026-02-01 04:05:57.865
1280	1	1	55.1067653	82.9522641	2026-02-01 03:59:13.512	MOVE	22.8390007019043	1.460655927658081	36.01217269897461	\N	1280	2026-02-01 04:05:57.865
1281	1	1	55.1068576	82.9526009	2026-02-01 03:59:29.543	MOVE	90	7.669999599456787	293	\N	1281	2026-02-01 04:05:57.865
1282	1	1	55.1067875	82.9522522	2026-02-01 03:59:47.717	MOVE	41.50099945068359	0	0	\N	1282	2026-02-01 04:05:57.865
1283	1	1	55.1071392	82.9526468	2026-02-01 04:00:28.724	MOVE	91	2.639999866485596	145	\N	1283	2026-02-01 04:05:57.865
1284	1	1	55.1067602	82.9522572	2026-02-01 04:00:47.935	MOVE	23.52599906921387	0	0	\N	1284	2026-02-01 04:05:57.865
1285	1	1	55.1070155	82.9520111	2026-02-01 04:01:01.725	MOVE	106	3.321724653244019	64.141845703125	\N	1285	2026-02-01 04:05:57.865
1286	1	1	55.1068234	82.952276	2026-02-01 04:01:11.408	MOVE	42.73199844360352	2.732476472854614	109.4468536376953	\N	1286	2026-02-01 04:05:57.865
1287	1	1	55.1072152	82.9517805	2026-02-01 04:01:28.549	MOVE	50.5	4.75	302	\N	1287	2026-02-01 04:05:57.865
1288	1	1	55.1067804	82.952204	2026-02-01 04:01:53.453	MOVE	25.02799987792969	0	0	\N	1288	2026-02-01 04:05:57.865
1289	1	1	55.1066234	82.9532519	2026-02-01 04:02:09.562	MOVE	66.5	4.979842185974121	114.9191741943359	\N	1289	2026-02-01 04:05:57.865
1290	1	1	55.1065999	82.9533468	2026-02-01 04:02:10.569	MOVE	76.56900024414062	4.987239837646484	114.8912200927734	\N	1290	2026-02-01 04:05:57.865
1291	1	1	55.1067766	82.9522799	2026-02-01 04:02:38.773	MOVE	39.21900177001953	0	0	\N	1291	2026-02-01 04:05:57.865
1292	1	1	55.1067702	82.952766	2026-02-01 04:03:14.73	MOVE	133	0.550000011920929	248	\N	1292	2026-02-01 04:05:57.865
1293	1	1	55.1067811	82.9522599	2026-02-01 04:03:33.976	MOVE	32.55500030517578	0	0	\N	1293	2026-02-01 04:05:57.865
1294	1	1	55.1067332	82.9524303	2026-02-01 04:03:58.167	MOVE	39.62699890136719	3.402713537216187	125.0699691772461	\N	1294	2026-02-01 04:05:57.865
1295	1	1	55.1065665	82.9532515	2026-02-01 04:04:13.659	MOVE	89.5	7.009999752044678	125	\N	1295	2026-02-01 04:05:57.865
1296	1	1	55.1067783	82.9522728	2026-02-01 04:04:32.743	MOVE	29.0049991607666	0	0	\N	1296	2026-02-01 04:05:57.865
1297	1	1	55.1064725	82.9533136	2026-02-01 04:05:15.547	MOVE	86.5	2.450000047683716	124	\N	1297	2026-02-01 04:05:57.865
1298	1	1	55.1067791	82.9522684	2026-02-01 04:05:33.996	MOVE	30.13400077819824	0	0	\N	1298	2026-02-01 04:05:57.865
1299	1	1	55.1067182	82.9525155	2026-02-01 04:06:03.517	MOVE	29.70000076293945	8.197328567504883	246.9510498046875	\N	1299	2026-02-01 04:06:18.237
1300	1	1	55.1067705	82.9522462	2026-02-01 04:06:20.249	MOVE	22.35000038146973	0	0	\N	1300	2026-02-01 04:06:19.945
1301	1	1	55.1068816	82.9522472	2026-02-01 04:06:33.533	MOVE	33.5	4.399794101715088	109.3160400390625	\N	1301	2026-02-01 04:06:48.319
1302	1	1	55.1067871	82.9522511	2026-02-01 04:06:50.748	MOVE	18.13899993896484	0	0	\N	1302	2026-02-01 04:06:50.451
1303	1	1	55.106946	82.9523303	2026-02-01 04:07:03.521	MOVE	38	4.427313804626465	102.5473327636719	\N	1303	2026-02-01 04:07:18.233
1304	1	1	55.1067873	82.9522506	2026-02-01 04:07:19.842	MOVE	18.23800086975098	0	0	\N	1304	2026-02-01 04:07:19.545
1305	1	1	55.1068441	82.9531334	2026-02-01 04:07:33.522	MOVE	42.5	0.5813910961151123	102.8532104492188	\N	1305	2026-02-01 04:07:33.238
1306	1	1	55.1067897	82.9521323	2026-02-01 04:07:47.326	MOVE	33.09500122070312	6.040041446685791	265.028564453125	\N	1306	2026-02-01 04:08:15.289
1307	1	1	55.1068118	82.9527004	2026-02-01 04:08:00.604	MOVE	326.8819885253906	0.1861308515071869	99.63925170898438	\N	1307	2026-02-01 04:08:15.289
1308	1	1	55.1069278	82.9522762	2026-02-01 04:08:18.537	MOVE	43.5	6.409999847412109	290	\N	1308	2026-02-01 04:08:18.263
1309	1	1	55.1069598	82.9521788	2026-02-01 04:08:19.522	MOVE	40.5	3.688250780105591	288.4202575683594	\N	1309	2026-02-01 04:08:34.228
1310	1	1	55.106781	82.9522613	2026-02-01 04:08:34.849	MOVE	17.9419994354248	0	0	\N	1310	2026-02-01 04:08:34.566
1311	1	1	55.106779	82.9525392	2026-02-01 04:08:35.539	MOVE	30.47100067138672	0.7974429130554199	304.270751953125	\N	1311	2026-02-01 04:08:50.302
1312	1	1	55.1068182	82.9529258	2026-02-01 04:08:51.531	MOVE	47.5	1.079999923706055	78	\N	1312	2026-02-01 04:08:51.24
1313	1	1	55.1068172	82.9527183	2026-02-01 04:09:07.528	MOVE	48	3.549999952316284	78	\N	1313	2026-02-01 04:09:07.387
1314	1	1	55.1067754	82.952261	2026-02-01 04:09:25.643	MOVE	17.34600067138672	0	0	\N	1314	2026-02-01 04:09:25.345
1315	1	1	55.1068899	82.9529696	2026-02-01 04:09:59.449	MOVE	322.8980102539062	1.023697137832642	85.77031707763672	\N	1315	2026-02-01 04:09:59.223
1316	1	1	55.1067849	82.9523809	2026-02-01 04:10:16.413	MOVE	17.80999946594238	1.605207443237305	108.1308059692383	\N	1316	2026-02-01 04:10:16.221
1317	1	1	55.1067756	82.9522167	2026-02-01 04:10:33.323	MOVE	26.48699951171875	0	0	\N	1317	2026-02-01 04:10:33.091
1318	1	1	55.1067879	82.9531053	2026-02-01 04:11:04.518	MOVE	44	6.33512020111084	120.9775924682617	\N	1318	2026-02-01 04:11:04.273
1319	1	1	55.1067739	82.9522647	2026-02-01 04:11:20.852	MOVE	17.22500038146973	0	0	\N	1319	2026-02-01 04:11:20.624
1320	1	1	55.1067653	82.9525085	2026-02-01 04:11:54.718	MOVE	163.6990051269531	1.143819212913513	120.1006088256836	\N	1320	2026-02-01 04:11:55.688
1321	1	1	55.1067591	82.9522586	2026-02-01 04:12:11.636	MOVE	22.11199951171875	0	0	\N	1321	2026-02-01 04:12:11.469
1322	1	1	55.1067984	82.9521477	2026-02-01 04:12:28.533	MOVE	30.38699913024902	0	0	\N	1322	2026-02-01 04:12:28.331
1323	1	1	55.106773	82.9522681	2026-02-01 04:12:45.441	MOVE	16.44599914550781	0	0	\N	1323	2026-02-01 04:12:45.197
1324	1	1	55.1068731	82.9519069	2026-02-01 04:18:19.518	MOVE	211	12.68274593353271	298.3241577148438	\N	1324	2026-02-01 04:18:34.214
1325	1	1	55.1067854	82.9522685	2026-02-01 04:18:36.079	MOVE	39.86199951171875	0	0	\N	1325	2026-02-01 04:18:35.796
1326	1	1	55.1058069	82.9455476	2026-02-01 04:19:43.786	MOVE	338.7969970703125	0	0	\N	1326	2026-02-01 04:19:43.576
1327	1	1	55.1064209	82.9565315	2026-02-01 04:20:00.522	MOVE	102.5	7.37999963760376	111	\N	1327	2026-02-01 04:20:00.899
1328	1	1	55.1063819	82.956708	2026-02-01 04:20:02.86	MOVE	119.1669998168945	7.308832168579102	111.0996932983398	\N	1328	2026-02-01 04:20:17.536
1329	1	1	55.1067827	82.9522736	2026-02-01 04:20:33.477	MOVE	21.99699974060059	0	0	\N	1329	2026-02-01 04:20:33.309
1330	1	1	55.1068137	82.9521948	2026-02-01 04:20:34.522	MOVE	101	0.7976183295249939	307.3390502929688	\N	1330	2026-02-01 04:20:49.211
1331	1	1	55.1067805	82.9522676	2026-02-01 04:20:50.39	MOVE	21.30599975585938	0	0	\N	1331	2026-02-01 04:20:50.135
1332	1	1	55.1068683	82.9517871	2026-02-01 04:21:15.515	MOVE	171.5	3.066169261932373	255.2671661376953	\N	1332	2026-02-01 04:21:30.205
1333	1	1	55.1067893	82.9522498	2026-02-01 04:21:33.577	MOVE	22.40299987792969	0	0	\N	1333	2026-02-01 04:21:33.335
1334	1	1	55.1071135	82.9509631	2026-02-01 04:22:30.508	MOVE	112.5	13.50050449371338	281.2546691894531	\N	1334	2026-02-01 04:22:45.215
1335	1	1	55.1067968	82.9522243	2026-02-01 04:22:49.039	MOVE	24.18199920654297	0	0	\N	1335	2026-02-01 04:22:48.785
1336	1	1	55.1069162	82.9516297	2026-02-01 04:25:15.508	MOVE	223.5	5.431537628173828	290.4716796875	\N	1336	2026-02-01 04:28:15.195
1337	1	1	55.1067728	82.9522422	2026-02-01 04:25:32.357	MOVE	23.64599990844727	0	0	\N	1337	2026-02-01 04:28:15.195
1338	1	1	55.1068773	82.9519081	2026-02-01 04:26:23.219	MOVE	181.2910003662109	0.4955228567123413	289.8466186523438	\N	1338	2026-02-01 04:28:15.195
1339	1	1	55.1068008	82.9522206	2026-02-01 04:26:40.135	MOVE	24.05400085449219	0	0	\N	1339	2026-02-01 04:28:15.195
1340	1	1	55.1067645	82.952267	2026-02-01 04:27:19.137	MOVE	22.5930004119873	0	0	\N	1340	2026-02-01 04:28:15.195
1341	1	1	55.1068032	82.9522128	2026-02-01 04:28:02.325	MOVE	22.40299987792969	2.064693450927734	88.42601013183594	\N	1341	2026-02-01 04:28:15.195
1342	1	1	55.1067645	82.9522991	2026-02-01 04:29:03.474	MOVE	22.45999908447266	0.3154976069927216	347.0412902832031	\N	1342	2026-02-01 04:29:03.251
1343	1	1	55.1068765	82.9510277	2026-02-01 04:29:30.516	MOVE	131	5.549776077270508	282.9745483398438	\N	1343	2026-02-01 04:29:45.197
1344	1	1	55.10677	82.9522425	2026-02-01 04:29:48.781	MOVE	22.33600044250488	0	0	\N	1344	2026-02-01 04:29:48.503
1345	1	1	55.1075888	82.9498545	2026-02-01 04:30:05.519	MOVE	224	1.429999947547913	279	\N	1345	2026-02-01 04:30:05.327
1346	1	1	55.1067669	82.9522599	2026-02-01 04:30:22.596	MOVE	21.15500068664551	0	0	\N	1346	2026-02-01 04:30:22.325
1347	1	1	55.1079608	82.9497949	2026-02-01 04:30:38.514	MOVE	105.5	9.029999732971191	99	\N	1347	2026-02-01 04:30:38.221
1348	1	1	55.107669	82.9505186	2026-02-01 04:30:46.515	MOVE	89	6.409494400024414	125.7916564941406	\N	1348	2026-02-01 04:31:01.228
1349	1	1	55.1067678	82.9522634	2026-02-01 04:31:03.87	MOVE	19.85400009155273	0	0	\N	1349	2026-02-01 04:31:03.585
1350	1	1	55.1067545	82.9523864	2026-02-01 04:31:22.511	MOVE	233	7.114197254180908	104.958381652832	\N	1350	2026-02-01 04:31:37.183
1351	1	1	55.1067669	82.9522599	2026-02-01 04:31:37.712	MOVE	21.15500068664551	0	0	\N	1351	2026-02-01 04:31:37.498
1352	1	1	55.1069061	82.9519688	2026-02-01 04:31:51.521	MOVE	127	5.159427642822266	277.1548767089844	\N	1352	2026-02-01 04:31:51.273
1353	1	1	55.1067901	82.9522352	2026-02-01 04:32:03.392	MOVE	20.76099967956543	2.29846715927124	284.4675903320312	\N	1353	2026-02-01 04:32:18.091
1354	1	1	55.1068271	82.9520245	2026-02-01 04:32:20.512	MOVE	44.20500183105469	3.154491901397705	282.1419372558594	\N	1354	2026-02-01 04:32:35.273
1355	1	1	55.1067676	82.9522601	2026-02-01 04:32:37.212	MOVE	21.67700004577637	0	0	\N	1355	2026-02-01 04:32:36.921
1356	1	1	55.1070134	82.9515213	2026-02-01 04:33:19.509	MOVE	186.5	0.699999988079071	134	\N	1356	2026-02-01 04:33:19.262
1357	1	1	55.1067833	82.9522231	2026-02-01 04:33:37.366	MOVE	24.09600067138672	0	0	\N	1357	2026-02-01 04:33:37.077
1358	1	1	55.1068926	82.9523077	2026-02-01 04:34:19.512	MOVE	80	2.819999933242798	272	\N	1358	2026-02-01 04:34:19.833
1359	1	1	55.1067817	82.9522774	2026-02-01 04:34:36.508	MOVE	20.86000061035156	0	0	\N	1359	2026-02-01 04:34:36.228
1360	1	1	55.1067856	82.9523992	2026-02-01 04:34:53.408	MOVE	194.3289947509766	0.4858821034431458	135.9709625244141	\N	1360	2026-02-01 04:34:53.189
1361	1	1	55.1067794	82.9522764	2026-02-01 04:35:10.326	MOVE	21.06100082397461	0	0	\N	1361	2026-02-01 04:35:10.11
1362	1	1	55.1067808	82.9523697	2026-02-01 04:35:45.52	MOVE	37.62300109863281	0.3691180944442749	59.96987152099609	\N	1362	2026-02-01 04:36:00.203
1363	1	1	55.1067796	82.9522718	2026-02-01 04:36:01.058	MOVE	20.6919994354248	0	0	\N	1363	2026-02-01 04:36:00.776
1364	1	1	55.1068195	82.9521958	2026-02-01 04:36:15.511	MOVE	44.25	0.1418564170598984	87.04666137695312	\N	1364	2026-02-01 04:36:15.224
1365	1	1	55.1067782	82.9522378	2026-02-01 04:36:34.891	MOVE	22.27499961853027	0	0	\N	1365	2026-02-01 04:36:34.609
1366	1	1	55.1067859	82.9518789	2026-02-01 04:36:49.513	MOVE	168	2.755908966064453	279.0702819824219	\N	1366	2026-02-01 04:36:49.241
1367	1	1	55.1067721	82.9522441	2026-02-01 04:37:06.404	MOVE	22.48600006103516	0	0	\N	1367	2026-02-01 04:37:06.111
1368	1	1	55.1066926	82.9529042	2026-02-01 04:37:20.511	MOVE	229.5	8.222488403320312	127.9810409545898	\N	1368	2026-02-01 04:37:20.212
1369	1	1	55.1067466	82.9523432	2026-02-01 04:37:34.374	MOVE	30.43400001525879	4.143014430999756	139.5446929931641	\N	1369	2026-02-01 04:37:34.119
1370	1	1	55.1068269	82.9526141	2026-02-01 04:37:50.517	MOVE	138	5.949999809265137	108	\N	1370	2026-02-01 04:37:50.287
1371	1	1	55.1068066	82.9521732	2026-02-01 04:38:08.32	MOVE	25.88599967956543	0	0	\N	1371	2026-02-01 04:38:08.033
1372	1	1	55.1067716	82.9522567	2026-02-01 04:38:32.494	MOVE	18.99799919128418	2.613190650939941	97.88729095458984	\N	1372	2026-02-01 04:38:32.275
1373	1	1	55.1068287	82.9522188	2026-02-01 04:39:23.247	MOVE	149.9680023193359	0.5167227387428284	120.0303039550781	\N	1373	2026-02-01 04:39:23.003
1374	1	1	55.1067687	82.9522674	2026-02-01 04:39:40.149	MOVE	19.60499954223633	0	0	\N	1374	2026-02-01 04:39:39.879
1375	1	1	55.106822	82.9520292	2026-02-01 04:40:19.519	MOVE	96.5	1.813488364219666	22.59387397766113	\N	1375	2026-02-01 04:40:34.178
1376	1	1	55.1067727	82.9522549	2026-02-01 04:40:35.699	MOVE	20.20999908447266	0	0	\N	1376	2026-02-01 04:40:35.39
1377	1	1	55.1068353	82.951858	2026-02-01 04:40:49.517	MOVE	169.5	1.542982220649719	285.4158630371094	\N	1377	2026-02-01 04:40:49.216
1378	1	1	55.1067693	82.9522667	2026-02-01 04:41:01.84	MOVE	19.60499954223633	1.976940155029297	105.7709503173828	\N	1378	2026-02-01 04:41:16.522
1379	1	1	55.1068395	82.952489	2026-02-01 04:41:49.516	MOVE	84	2.249696493148804	93.0090560913086	\N	1379	2026-02-01 04:41:49.21
1380	1	1	55.106786	82.9523276	2026-02-01 04:42:02.645	MOVE	29.19099998474121	1.407890558242798	95.03742218017578	\N	1380	2026-02-01 04:42:17.916
1381	1	1	55.1067736	82.952524	2026-02-01 04:42:19.51	MOVE	92	0.2099999934434891	116	\N	1381	2026-02-01 04:42:19.236
1382	1	1	55.1067685	82.9522668	2026-02-01 04:42:36.48	MOVE	19.62899971008301	0	0	\N	1382	2026-02-01 04:42:36.2
1383	1	1	55.106862	82.9520992	2026-02-01 04:43:01.893	MOVE	19.57099914550781	5.555221080780029	316.8134460449219	\N	1383	2026-02-01 04:43:01.653
1384	1	1	55.1067684	82.9522507	2026-02-01 04:43:18.806	MOVE	21.81599998474121	0	0	\N	1384	2026-02-01 04:43:18.56
1385	1	1	55.1069658	82.9515217	2026-02-01 04:43:49.527	MOVE	66.5	6.693826198577881	286.0798034667969	\N	1385	2026-02-01 04:43:49.255
1386	1	1	55.1067961	82.9521549	2026-02-01 04:44:02.477	MOVE	20.46599960327148	3.195643186569214	298.9209899902344	\N	1386	2026-02-01 04:44:17.161
1387	1	1	55.1067666	82.9522613	2026-02-01 04:44:19.401	MOVE	20.27599906921387	0	0	\N	1387	2026-02-01 04:44:19.137
1388	1	1	55.1067612	82.9523697	2026-02-01 04:44:19.51	MOVE	99.5	2.40792441368103	99.41459655761719	\N	1388	2026-02-01 04:44:34.222
1389	1	1	55.1067703	82.9522501	2026-02-01 04:44:36.326	MOVE	20.72999954223633	0	0	\N	1389	2026-02-01 04:44:36.052
1390	1	1	55.106904	82.9508522	2026-02-01 04:45:19.504	MOVE	159.5	1	329	\N	1390	2026-02-01 04:45:19.243
1391	1	1	55.1067797	82.9522577	2026-02-01 04:45:36.456	MOVE	16.73100090026855	0	0	\N	1391	2026-02-01 04:45:36.198
1392	1	1	55.1069174	82.9517777	2026-02-01 04:45:50.506	MOVE	105	13.83843898773193	278.2450866699219	\N	1392	2026-02-01 04:45:50.18
1393	1	1	55.1067886	82.9521718	2026-02-01 04:46:02.51	MOVE	20.73600006103516	5.125149726867676	289.4554138183594	\N	1393	2026-02-01 04:46:17.179
1394	1	1	55.1067667	82.9522563	2026-02-01 04:46:19.464	MOVE	20.06100082397461	0	0	\N	1394	2026-02-01 04:46:19.15
1395	1	1	55.1068374	82.9516954	2026-02-01 04:46:50.525	MOVE	194.5	3.713793516159058	101.7755661010742	\N	1395	2026-02-01 04:46:50.262
1396	1	1	55.1067702	82.9522486	2026-02-01 04:47:01.852	MOVE	21.20599937438965	3.586819410324097	101.2035446166992	\N	1396	2026-02-01 04:47:16.546
1397	1	1	55.1067656	82.9526986	2026-02-01 04:47:50.519	MOVE	172	1.195035576820374	296.7702941894531	\N	1397	2026-02-01 04:47:50.239
1398	1	1	55.1067693	82.9522606	2026-02-01 04:48:01.85	MOVE	20.17499923706055	1.885137677192688	283.1345520019531	\N	1398	2026-02-01 04:48:16.557
1399	1	1	55.1069942	82.9517955	2026-02-01 04:48:50.509	MOVE	148	0.9010635018348694	322.8863830566406	\N	1399	2026-02-01 04:48:50.329
1400	1	1	55.1067743	82.9522397	2026-02-01 04:49:01.856	MOVE	20.82500076293945	0.1078535914421082	323.3243713378906	\N	1400	2026-02-01 04:49:16.572
1401	1	1	55.1068544	82.9521402	2026-02-01 04:49:45.526	MOVE	225.75	1.585923075675964	281.3348083496094	\N	1401	2026-02-01 04:50:00.506
1402	1	1	55.1067687	82.9522593	2026-02-01 04:50:01.852	MOVE	20.27199935913086	0	0	\N	1402	2026-02-01 04:50:01.518
1403	1	1	55.1071234	82.9519087	2026-02-01 04:50:49.522	MOVE	59	2.416460514068604	249.0947723388672	\N	1403	2026-02-01 04:50:49.28
1404	1	1	55.106789	82.9522109	2026-02-01 04:51:01.89	MOVE	21.94099998474121	1.314694404602051	205.5425262451172	\N	1404	2026-02-01 04:51:16.557
1405	1	1	55.1067857	82.9525964	2026-02-01 04:51:19.522	MOVE	71	2.361267566680908	5.333327293395996	\N	1405	2026-02-01 04:51:34.262
1406	1	1	55.1067703	82.9522646	2026-02-01 04:51:35.829	MOVE	19.82099914550781	0	0	\N	1406	2026-02-01 04:51:35.472
1407	1	1	55.1068429	82.9522587	2026-02-01 04:51:49.516	MOVE	75	0.4809614717960358	357.3179931640625	\N	1407	2026-02-01 04:51:49.263
1408	1	1	55.1067692	82.9522666	2026-02-01 04:52:02.553	MOVE	19.91300010681152	0.5999624729156494	176.4619140625	\N	1408	2026-02-01 04:52:17.213
1409	1	1	55.1067695	82.9523953	2026-02-01 04:53:49.513	MOVE	120.5	0.3414177894592285	222.9408264160156	\N	1409	2026-02-01 04:54:04.244
1410	1	1	55.1067693	82.9522554	2026-02-01 04:54:04.825	MOVE	21.14100074768066	0	0	\N	1410	2026-02-01 04:54:04.562
1411	1	1	55.1067563	82.9532009	2026-02-01 04:54:19.508	MOVE	85.5	2.903931617736816	95.98978424072266	\N	1411	2026-02-01 04:54:19.158
1412	1	1	55.1068128	82.9525299	2026-02-01 04:54:38.509	MOVE	49	1.991740822792053	243.7521667480469	\N	1412	2026-02-01 04:54:38.18
1413	1	1	55.1068447	82.9524582	2026-02-01 04:54:49.384	MOVE	115.8560028076172	1.274260878562927	270.0330810546875	\N	1413	2026-02-01 04:55:04.034
1414	1	1	55.1067671	82.952265	2026-02-01 04:55:06.293	MOVE	20.86300086975098	0	0	\N	1414	2026-02-01 04:55:05.993
1415	1	1	55.1068698	82.9525184	2026-02-01 04:55:23.231	MOVE	160.4230041503906	0.7701498866081238	100.7840270996094	\N	1415	2026-02-01 04:55:22.932
1416	1	1	55.1067673	82.9522594	2026-02-01 04:55:40.148	MOVE	20.95199966430664	0	0	\N	1416	2026-02-01 04:55:39.881
1417	1	1	55.1068937	82.9523641	2026-02-01 04:56:11.516	MOVE	41.5	2.246821880340576	63.9672966003418	\N	1417	2026-02-01 04:56:11.192
1418	1	1	55.1067661	82.9522596	2026-02-01 04:56:30.928	MOVE	20.92300033569336	0	0	\N	1418	2026-02-01 04:56:30.65
1419	1	1	55.1068304	82.9525033	2026-02-01 04:56:45.521	MOVE	47.5	0.2809885144233704	74.9856948852539	\N	1419	2026-02-01 04:56:45.284
1420	1	1	55.1067949	82.9528584	2026-02-01 04:57:04.533	MOVE	42.5	0.8199999928474426	146	\N	1420	2026-02-01 04:57:04.137
1421	1	1	55.1067707	82.952255	2026-02-01 04:57:21.674	MOVE	21.38299942016602	0	0	\N	1421	2026-02-01 04:57:21.329
1422	1	1	55.1068312	82.9523257	2026-02-01 04:57:22.52	MOVE	35.44100189208984	0.3178873360157013	337.7371826171875	\N	1422	2026-02-01 04:57:38.428
1423	1	1	55.1067643	82.9522608	2026-02-01 04:57:38.598	MOVE	21.02499961853027	0	0	\N	1423	2026-02-01 04:57:55.245
1424	1	1	55.1069519	82.9523713	2026-02-01 04:58:47.503	MOVE	49	3.970000028610229	96	\N	1424	2026-02-01 04:58:47.231
1425	1	1	55.1067702	82.9522541	2026-02-01 04:59:06.261	MOVE	21.19099998474121	0	0	\N	1425	2026-02-01 04:59:05.934
1426	1	1	55.1067789	82.9523392	2026-02-01 04:59:32.879	MOVE	24.51700019836426	1.000489950180054	288.9091796875	\N	1426	2026-02-01 04:59:32.615
1427	1	1	55.1067407	82.953481	2026-02-01 04:59:49.804	MOVE	128.6699981689453	0.09279829263687134	0	\N	1427	2026-02-01 04:59:49.523
1428	1	1	55.106766	82.9522576	2026-02-01 05:00:06.724	MOVE	20.85400009155273	0	0	\N	1428	2026-02-01 05:00:06.443
1429	1	1	55.1069428	82.9522942	2026-02-01 05:00:20.506	MOVE	91.5	0.4165978133678436	171.7318115234375	\N	1429	2026-02-01 05:00:20.208
1430	1	1	55.1067941	82.9522739	2026-02-01 05:00:32.481	MOVE	30.73699951171875	0.6613094806671143	175.2816772460938	\N	1430	2026-02-01 05:00:47.305
1431	1	1	55.1067662	82.952405	2026-02-01 05:00:50.503	MOVE	40.34600067138672	0.1934992372989655	263.5416870117188	\N	1431	2026-02-01 05:01:05.149
1432	1	1	55.1067636	82.9522478	2026-02-01 05:01:06.387	MOVE	21.78400039672852	0	0	\N	1432	2026-02-01 05:01:06.059
1433	1	1	55.1067588	82.9524194	2026-02-01 05:01:31.968	MOVE	31.71500015258789	1.185091137886047	129.3528747558594	\N	1433	2026-02-01 05:01:31.691
1434	1	1	55.1067626	82.9522609	2026-02-01 05:01:48.907	MOVE	21.83499908447266	0	0	\N	1434	2026-02-01 05:01:48.645
1435	1	1	55.1067654	82.9523912	2026-02-01 05:01:50.515	MOVE	80	1.14860212802887	120.0385055541992	\N	1435	2026-02-01 05:02:05.235
1436	1	1	55.1067806	82.9522808	2026-02-01 05:02:05.83	MOVE	38.93899917602539	0	0	\N	1436	2026-02-01 05:02:05.508
1437	1	1	55.1068285	82.9531323	2026-02-01 05:02:22.798	MOVE	173.4700012207031	2.388014554977417	98.00513458251953	\N	1437	2026-02-01 05:02:22.528
1438	1	1	55.1067809	82.9522799	2026-02-01 05:02:39.721	MOVE	38.93899917602539	0	0	\N	1438	2026-02-01 05:02:39.458
1439	1	1	55.106745	82.9524857	2026-02-01 05:02:49.52	MOVE	104	1.54371166229248	248.6591949462891	\N	1439	2026-02-01 05:03:04.151
1440	1	1	55.1067657	82.9522599	2026-02-01 05:03:05.158	MOVE	20.16900062561035	0	0	\N	1440	2026-02-01 05:03:04.798
1441	1	1	55.1069817	82.9518858	2026-02-01 05:03:21.504	MOVE	107.5	11.39999961853027	281	\N	1441	2026-02-01 05:03:21.158
1442	1	1	55.106769	82.9522613	2026-02-01 05:03:39.021	MOVE	19.99900054931641	0	0	\N	1442	2026-02-01 05:03:38.668
1443	1	1	55.1067854	82.9523779	2026-02-01 05:04:50.52	MOVE	229	1.609102487564087	174.8845367431641	\N	1443	2026-02-01 05:04:50.193
1444	1	1	55.1067692	82.9522475	2026-02-01 05:05:03.678	MOVE	21.51600074768066	1.143118381500244	174.5793914794922	\N	1444	2026-02-01 05:05:18.336
1445	1	1	55.1068028	82.9518718	2026-02-01 05:05:30.502	MOVE	204.75	3.171200037002563	246.3500518798828	\N	1445	2026-02-01 05:05:45.143
1446	1	1	55.1067648	82.952259	2026-02-01 05:05:46.961	MOVE	21.04199981689453	0	0	\N	1446	2026-02-01 05:05:46.602
1447	1	1	55.1067925	82.9521266	2026-02-01 05:06:35.504	MOVE	172.5	3.944948196411133	74.59268188476562	\N	1447	2026-02-01 05:06:35.188
1448	1	1	55.1067916	82.9523147	2026-02-01 05:06:47.595	MOVE	37.51900100708008	2.83872389793396	69.95500946044922	\N	1448	2026-02-01 05:07:02.236
1449	1	1	55.1068362	82.9526514	2026-02-01 05:07:35.51	MOVE	78	3.544938802719116	258.8745727539062	\N	1449	2026-02-01 05:07:35.154
1450	1	1	55.1067683	82.9522374	2026-02-01 05:07:47.272	MOVE	21.02799987792969	3.18452000617981	257.6278686523438	\N	1450	2026-02-01 05:08:01.916
1451	1	1	55.1068328	82.9522536	2026-02-01 05:08:35.522	MOVE	56.5	3.65243673324585	275.0243835449219	\N	1451	2026-02-01 05:08:35.205
1452	1	1	55.1068414	82.9521401	2026-02-01 05:08:38.039	MOVE	106.8320007324219	3.63712477684021	275.0465087890625	\N	1452	2026-02-01 05:08:52.73
1453	1	1	55.1067699	82.9522492	2026-02-01 05:08:55.031	MOVE	20.28000068664551	0	0	\N	1453	2026-02-01 05:08:54.652
1454	1	1	55.1067773	82.9523309	2026-02-01 05:09:17.603	MOVE	17.00300025939941	6.057689666748047	94.24341583251953	\N	1454	2026-02-01 05:09:17.349
1455	1	1	55.1068211	82.9528211	2026-02-01 05:09:34.502	MOVE	115.5	1.899999976158142	287	\N	1455	2026-02-01 05:09:34.147
1456	1	1	55.1067707	82.9522568	2026-02-01 05:09:51.583	MOVE	20.67900085449219	0	0	\N	1456	2026-02-01 05:09:51.277
1457	1	1	55.1069416	82.9521814	2026-02-01 05:10:34.52	MOVE	72.5	2.710000038146973	281	\N	1457	2026-02-01 05:10:34.274
1458	1	1	55.10677	82.9522494	2026-02-01 05:10:51.654	MOVE	20.71199989318848	0	0	\N	1458	2026-02-01 05:10:51.434
1459	1	1	55.1068692	82.9521329	2026-02-01 05:11:05.504	MOVE	73	3.109758615493774	300.2088012695312	\N	1459	2026-02-01 05:11:05.146
1460	1	1	55.1067857	82.9522175	2026-02-01 05:11:17.609	MOVE	20.73100090026855	1.727823972702026	306.7400207519531	\N	1460	2026-02-01 05:11:32.255
1461	1	1	55.1068893	82.9525353	2026-02-01 05:12:05.502	MOVE	129.5	3.064491987228394	244.6828765869141	\N	1461	2026-02-01 05:12:05.191
1462	1	1	55.1067687	82.952239	2026-02-01 05:12:18.167	MOVE	20.89599990844727	2.682431936264038	241.4645538330078	\N	1462	2026-02-01 05:12:32.961
1463	1	1	55.1067629	82.952339	2026-02-01 05:13:17.603	MOVE	20.34700012207031	5.518069744110107	111.7063980102539	\N	1463	2026-02-01 05:13:17.532
1464	1	1	55.1069441	82.9525308	2026-02-01 05:13:34.51	MOVE	45	13.19999980926514	82	\N	1464	2026-02-01 05:13:34.254
1465	1	1	55.1067687	82.9522553	2026-02-01 05:13:51.497	MOVE	20.84499931335449	0	0	\N	1465	2026-02-01 05:13:51.182
1466	1	1	55.1068616	82.9527058	2026-02-01 05:14:05.512	MOVE	53.5	2.368695735931396	64.99329376220703	\N	1466	2026-02-01 05:14:05.2
1467	1	1	55.1068864	82.9528025	2026-02-01 05:14:08.399	MOVE	111.2379989624023	2.368368625640869	64.99510955810547	\N	1467	2026-02-01 05:14:23.049
1468	1	1	55.1067681	82.9522589	2026-02-01 05:14:25.305	MOVE	20.10600090026855	0	0	\N	1468	2026-02-01 05:14:25.096
1469	1	1	55.1068053	82.9521066	2026-02-01 05:14:42.215	MOVE	206.1239929199219	0.5419302582740784	214.8047485351562	\N	1469	2026-02-01 05:14:41.892
1470	1	1	55.1067669	82.952256	2026-02-01 05:14:59.133	MOVE	19.63400077819824	0	0	\N	1470	2026-02-01 05:19:59.708
1471	1	1	55.1068281	82.9523743	2026-02-01 05:16:05.506	MOVE	69	3.429999828338623	112	\N	1471	2026-02-01 05:19:59.708
1472	1	1	55.1067661	82.9522613	2026-02-01 05:16:23.856	MOVE	20.66600036621094	0	0	\N	1472	2026-02-01 05:19:59.708
1473	1	1	55.1070209	82.9518393	2026-02-01 05:17:38.301	MOVE	125.4680023193359	0.6191325187683105	326.0560607910156	\N	1473	2026-02-01 05:19:59.708
1474	1	1	55.1067701	82.9522562	2026-02-01 05:17:55.295	MOVE	20.59900093078613	0	0	\N	1474	2026-02-01 05:19:59.708
1475	1	1	55.1069065	82.9521255	2026-02-01 05:18:12.249	MOVE	204.4519958496094	1.136733055114746	129.9892883300781	\N	1475	2026-02-01 05:19:59.708
1476	1	1	55.1067666	82.9522583	2026-02-01 05:18:29.148	MOVE	20.1830005645752	0	0	\N	1476	2026-02-01 05:19:59.708
1477	1	1	55.1067926	82.9521617	2026-02-01 05:18:48.733	MOVE	20.51000022888184	3.420043468475342	287.3642883300781	\N	1477	2026-02-01 05:19:59.708
1478	1	1	55.1067694	82.9522574	2026-02-01 05:19:05.707	MOVE	21.89500045776367	0	0	\N	1478	2026-02-01 05:19:59.708
1479	1	1	55.1069337	82.9524378	2026-02-01 05:20:35.548	MOVE	97	1.5852210521698	86.95980072021484	\N	1479	2026-02-01 05:20:35.274
1480	1	1	55.1067915	82.9522555	2026-02-01 05:20:47.722	MOVE	21.69099998474121	0.6743371486663818	84.61141967773438	\N	1480	2026-02-01 05:21:02.409
1481	1	1	55.1069807	82.952202	2026-02-01 05:21:04.527	MOVE	96.5	3.639999866485596	291	\N	1481	2026-02-01 05:21:04.225
1482	1	1	55.1067764	82.952242	2026-02-01 05:21:21.81	MOVE	21.71199989318848	0	0	\N	1482	2026-02-01 05:21:21.655
1483	1	1	55.1068721	82.9528448	2026-02-01 05:22:12.859	MOVE	199.6510009765625	1.212256550788879	90.98774719238281	\N	1483	2026-02-01 05:22:12.713
1484	1	1	55.1067685	82.952252	2026-02-01 05:22:29.895	MOVE	21.96500015258789	0	0	\N	1484	2026-02-01 05:22:29.722
1485	1	1	55.1067665	82.952619	2026-02-01 05:23:34.531	MOVE	66.5	1.313517093658447	279.0429077148438	\N	1485	2026-02-01 05:23:34.315
1486	1	1	55.1067728	82.9522558	2026-02-01 05:23:54.953	MOVE	21.56100082397461	0	0	\N	1486	2026-02-01 05:23:54.684
1487	1	1	55.1068004	82.9527468	2026-02-01 05:24:12.08	MOVE	201.7969970703125	0.6073494553565979	86.04344940185547	\N	1487	2026-02-01 05:24:11.876
1488	1	1	55.1067723	82.9522591	2026-02-01 05:24:29.089	MOVE	21.76600074768066	0	0	\N	1488	2026-02-01 05:24:28.925
1489	1	1	55.1067974	82.9521454	2026-02-01 05:24:46.076	MOVE	37.91899871826172	2.593298196792603	276.3982543945312	\N	1489	2026-02-01 05:24:45.91
1490	1	1	55.1070225	82.9520428	2026-02-01 05:25:01.531	MOVE	47.25	0.3173357248306274	131.1097106933594	\N	1490	2026-02-01 05:25:01.241
1491	1	1	55.1067787	82.9522334	2026-02-01 05:25:20.112	MOVE	23.11800003051758	0	0	\N	1491	2026-02-01 05:25:19.92
1492	1	1	55.1068858	82.952934	2026-02-01 05:25:35.555	MOVE	50.5	0.199999988079071	269	\N	1492	2026-02-01 05:25:35.29
1493	1	1	55.1067719	82.9522635	2026-02-01 05:25:54.161	MOVE	31.77300071716309	0	0	\N	1493	2026-02-01 05:25:53.965
1494	1	1	55.1067687	82.9524424	2026-02-01 05:26:11.153	MOVE	31.72599983215332	0.703368604183197	267.8057861328125	\N	1494	2026-02-01 05:26:10.975
1495	1	1	55.1067739	82.9522497	2026-02-01 05:26:28.179	MOVE	22.47299957275391	0	0	\N	1495	2026-02-01 05:26:27.99
1496	1	1	55.1068523	82.952511	2026-02-01 05:27:04.531	MOVE	59.5	0.4699999988079071	300	\N	1496	2026-02-01 05:27:04.34
1497	1	1	55.1067855	82.9522797	2026-02-01 05:27:21.698	MOVE	30.82999992370605	0	0	\N	1497	2026-02-01 05:27:21.537
1498	1	1	55.1068285	82.9520499	2026-02-01 05:27:35.498	MOVE	54.5	4.771566390991211	177.9356842041016	\N	1498	2026-02-01 05:27:35.212
1499	1	1	55.106842	82.951764	2026-02-01 05:27:37.495	MOVE	54.57899856567383	3.941807746887207	140.2356719970703	\N	1499	2026-02-01 05:27:52.156
1500	1	1	55.1067739	82.9522756	2026-02-01 05:27:54.318	MOVE	17.18400001525879	0	0	\N	1500	2026-02-01 05:27:53.962
1501	1	1	55.1064099	82.9498628	2026-02-01 05:28:28.292	MOVE	224.3390045166016	0.5287973880767822	356.3848876953125	\N	1501	2026-02-01 05:28:28.546
1502	1	1	55.106603	82.9529187	2026-02-01 05:28:45.248	MOVE	33.06999969482422	0	0	\N	1502	2026-02-01 05:28:44.906
1503	1	1	55.1067494	82.9524498	2026-02-01 05:29:02.328	MOVE	22.72599983215332	1.959853172302246	132.8773651123047	\N	1503	2026-02-01 05:29:02.021
1504	1	1	55.1068372	82.9520352	2026-02-01 05:29:19.329	MOVE	35.09799957275391	0	0	\N	1504	2026-02-01 05:29:19.026
1505	1	1	55.1068065	82.9521132	2026-02-01 05:29:37.75	MOVE	35.9119987487793	0.8441554307937622	283.25	\N	1505	2026-02-01 05:29:37.454
1506	1	1	55.1070802	82.9523074	2026-02-01 05:29:49.538	MOVE	44.75	0.7904643416404724	244.2420501708984	\N	1506	2026-02-01 05:30:04.255
1507	1	1	55.1066079	82.9529107	2026-02-01 05:30:06.507	MOVE	35.27099990844727	0	0	\N	1507	2026-02-01 05:30:06.269
1508	1	1	55.1069042	82.952625	2026-02-01 05:30:19.533	MOVE	39.25	2.017731666564941	109.9819107055664	\N	1508	2026-02-01 05:30:34.275
1509	1	1	55.1068363	82.9520298	2026-02-01 05:30:36.391	MOVE	32.80099868774414	0	0	\N	1509	2026-02-01 05:30:36.166
1510	1	1	55.1067957	82.9522467	2026-02-01 05:30:53.51	MOVE	41.79399871826172	1.276357054710388	286.0366516113281	\N	1510	2026-02-01 05:30:53.243
1511	1	1	55.1066252	82.9528352	2026-02-01 05:31:10.356	MOVE	42.80300140380859	0	0	\N	1511	2026-02-01 05:31:10.229
1512	1	1	55.1067848	82.9524956	2026-02-01 05:31:27.333	MOVE	201.2480010986328	0.2458962351083755	270.9774169921875	\N	1512	2026-02-01 05:31:27.178
1513	1	1	55.1067625	82.9522604	2026-02-01 05:31:44.33	MOVE	31.78700065612793	0	0	\N	1513	2026-02-01 05:32:16.115
1514	1	1	55.1068565	82.9523935	2026-02-01 05:32:01.495	MOVE	211.1869964599609	0.1651743799448013	241.6744995117188	\N	1514	2026-02-01 05:32:16.115
1515	1	1	55.1067845	82.952268	2026-02-01 05:32:18.575	MOVE	20.94000053405762	0	0	\N	1515	2026-02-01 05:32:18.161
1516	1	1	55.1066279	82.9526682	2026-02-01 05:32:37.85	MOVE	30.20800018310547	2.636200904846191	265.177001953125	\N	1516	2026-02-01 05:32:37.724
1517	1	1	55.1069386	82.9522091	2026-02-01 05:32:54.845	MOVE	151.5429992675781	0.7035112380981445	3.108826637268066	\N	1517	2026-02-01 05:32:54.635
1518	1	1	55.1065944	82.9528239	2026-02-01 05:33:11.85	MOVE	45.34999847412109	0	0	\N	1518	2026-02-01 05:33:11.667
1519	1	1	55.1066401	82.9528605	2026-02-01 05:33:36.462	MOVE	46.0099983215332	0	0	\N	1519	2026-02-01 05:33:36.254
1520	1	1	55.1067698	82.9526068	2026-02-01 05:33:53.516	MOVE	82	0.8399999737739563	126	\N	1520	2026-02-01 05:33:53.265
1521	1	1	55.1067661	82.9521941	2026-02-01 05:34:10.597	MOVE	32.45299911499023	0	0	\N	1521	2026-02-01 05:34:10.384
1522	1	1	55.1068157	82.9525284	2026-02-01 05:34:36.17	MOVE	52.67100143432617	1.735979318618774	299.1916809082031	\N	1522	2026-02-01 05:40:24.559
1523	1	1	55.1066226	82.9529186	2026-02-01 05:34:53.18	MOVE	34.35699844360352	0	0	\N	1523	2026-02-01 05:40:24.559
1524	1	1	55.106657	82.9527459	2026-02-01 05:35:10.517	MOVE	51.58399963378906	0	0	\N	1524	2026-02-01 05:40:24.559
1525	1	1	55.1067583	82.952689	2026-02-01 05:36:20.495	MOVE	47	5.0061936378479	82.86729431152344	\N	1525	2026-02-01 05:40:24.559
1526	1	1	55.1066205	82.9527487	2026-02-01 05:36:36.635	MOVE	51.80799865722656	0	0	\N	1526	2026-02-01 05:40:24.559
1527	1	1	55.106755	82.9530602	2026-02-01 05:36:50.5	MOVE	47.5	0.5321633815765381	94.96050262451172	\N	1527	2026-02-01 05:40:24.559
1528	1	1	55.1067923	82.9522647	2026-02-01 05:37:06.695	MOVE	21.70199966430664	0	0	\N	1528	2026-02-01 05:40:24.559
1529	1	1	55.1066123	82.9528235	2026-02-01 05:37:23.722	MOVE	43.21099853515625	0	0	\N	1529	2026-02-01 05:40:24.559
1530	1	1	55.1066322	82.9527503	2026-02-01 05:37:40.77	MOVE	50.58300018310547	0	0	\N	1530	2026-02-01 05:40:24.559
1531	1	1	55.106808	82.9524235	2026-02-01 05:38:07.626	MOVE	47.01200103759766	1.584340572357178	303.6539611816406	\N	1531	2026-02-01 05:40:24.559
1532	1	1	55.1069031	82.9517181	2026-02-01 05:38:23.517	MOVE	51.5	2.519999980926514	338	\N	1532	2026-02-01 05:40:24.559
1533	1	1	55.1066158	82.9528985	2026-02-01 05:38:41.714	MOVE	43.51200103759766	0	0	\N	1533	2026-02-01 05:40:24.559
1534	1	1	55.1067478	82.9524217	2026-02-01 05:39:08.461	MOVE	43.99300003051758	1.852340340614319	297.9443054199219	\N	1534	2026-02-01 05:40:24.559
1535	1	1	55.1068552	82.9518684	2026-02-01 05:39:23.5	MOVE	62.5	4.799999713897705	272	\N	1535	2026-02-01 05:40:24.559
1536	1	1	55.1067565	82.9523153	2026-02-01 05:39:42.756	MOVE	19.125	0	0	\N	1536	2026-02-01 05:40:24.559
1537	1	1	55.1067775	82.952106	2026-02-01 05:40:06.76	MOVE	36.55300140380859	3.14545202255249	269.09765625	\N	1537	2026-02-01 05:40:24.559
1538	1	1	55.1066059	82.9569985	2026-02-01 05:40:23.519	MOVE	71	20.68999862670898	96	\N	1538	2026-02-01 05:40:24.559
1539	1	1	55.1067956	82.9524855	2026-02-01 05:40:40.736	MOVE	52	0	0	\N	1539	2026-02-01 05:51:04.032
1540	1	1	55.1067716	82.9521892	2026-02-01 05:41:03.443	MOVE	34.54600143432617	0	0	\N	1540	2026-02-01 05:51:04.032
1541	1	1	55.1068972	82.952289	2026-02-01 05:41:31.334	MOVE	48.67699813842773	1.918778538703918	314.2281188964844	\N	1541	2026-02-01 05:51:04.032
1542	1	1	55.106601	82.9526917	2026-02-01 05:41:48.362	MOVE	50.86700057983398	0	0	\N	1542	2026-02-01 05:51:04.032
1543	1	1	55.110074	82.9306806	2026-02-01 05:42:07.337	MOVE	460.7030029296875	42.67972564697266	276.5292053222656	\N	1543	2026-02-01 05:51:04.032
1544	1	1	55.1066678	82.9525304	2026-02-01 05:42:21.503	MOVE	47.83300018310547	0.3298952281475067	227.0014495849609	\N	1544	2026-02-01 05:51:04.032
1545	1	1	55.1065976	82.9528665	2026-02-01 05:42:41.353	MOVE	47.38199996948242	0	0	\N	1545	2026-02-01 05:51:04.032
1546	1	1	55.1067792	82.95241	2026-02-01 05:42:57.525	MOVE	49.5	4.130000114440918	231	\N	1546	2026-02-01 05:51:04.032
1547	1	1	55.106773	82.9522066	2026-02-01 05:43:15.634	MOVE	34.45600128173828	0	0	\N	1547	2026-02-01 05:51:04.032
1548	1	1	55.1066061	82.9528303	2026-02-01 05:43:41.409	MOVE	49.38399887084961	0	0	\N	1548	2026-02-01 05:51:04.032
1549	1	1	55.1069354	82.9529121	2026-02-01 05:43:57.511	MOVE	74	0.9099999666213989	323	\N	1549	2026-02-01 05:51:04.032
1550	1	1	55.1066344	82.9529096	2026-02-01 05:44:15.634	MOVE	46.20500183105469	0	0	\N	1550	2026-02-01 05:51:04.032
1551	1	1	55.1068251	82.9521794	2026-02-01 05:44:41.076	MOVE	24.44599914550781	2.226969480514526	327.6865539550781	\N	1551	2026-02-01 05:51:04.032
1552	1	1	55.1067092	82.952974	2026-02-01 05:44:57.496	MOVE	89	0.6899999976158142	324	\N	1552	2026-02-01 05:51:04.032
1553	1	1	55.1067869	82.952171	2026-02-01 05:45:15.248	MOVE	27.77499961853027	0	0	\N	1553	2026-02-01 05:51:04.032
1554	1	1	55.1066535	82.9527305	2026-02-01 05:45:44.541	MOVE	51.20600128173828	0	0	\N	1554	2026-02-01 05:51:04.032
1555	1	1	55.1067599	82.9525931	2026-02-01 05:46:10.528	MOVE	38.28200149536133	1.913848400115967	102.8629379272461	\N	1555	2026-02-01 05:51:04.032
1556	1	1	55.1069674	82.9517806	2026-02-01 05:46:27.506	MOVE	71	2.769999980926514	330	\N	1556	2026-02-01 05:51:04.032
1557	1	1	55.1067751	82.952186	2026-02-01 05:46:44.492	MOVE	36.84299850463867	0	0	\N	1557	2026-02-01 05:51:04.032
1558	1	1	55.1068623	82.951853	2026-02-01 05:47:01.519	MOVE	170.8379974365234	0.264754980802536	201.0753173828125	\N	1558	2026-02-01 05:51:04.032
1559	1	1	55.1065914	82.9527539	2026-02-01 05:47:18.535	MOVE	56.75600051879883	0	0	\N	1559	2026-02-01 05:51:04.032
1560	1	1	55.1067827	82.9522728	2026-02-01 05:47:41.279	MOVE	19.70599937438965	3.867476940155029	286.1187133789062	\N	1560	2026-02-01 05:51:04.032
1561	1	1	55.1067728	82.9515947	2026-02-01 05:47:57.519	MOVE	96	8.420000076293945	268	\N	1561	2026-02-01 05:51:04.032
1562	1	1	55.1066976	82.9527522	2026-02-01 05:48:15.276	MOVE	45.63000106811523	0	0	\N	1562	2026-02-01 05:51:04.032
1563	1	1	55.1067835	82.9519813	2026-02-01 05:48:41.876	MOVE	35.09000015258789	2.819174766540527	274.9997253417969	\N	1563	2026-02-01 05:51:04.032
1564	1	1	55.106643	82.952809	2026-02-01 05:48:58.903	MOVE	46.47299957275391	0	0	\N	1564	2026-02-01 05:51:04.032
1565	1	1	55.1066926	82.9523447	2026-02-01 05:49:00.505	MOVE	64.98600006103516	9.465648651123047	275.8289794921875	\N	1565	2026-02-01 05:51:04.032
1566	1	1	55.1065736	82.9529011	2026-02-01 05:49:15.932	MOVE	47.50699996948242	0	0	\N	1566	2026-02-01 05:51:04.032
1567	1	1	55.1066564	82.9525461	2026-02-01 05:49:41.205	MOVE	47.84199905395508	2.724317073822021	133.6390686035156	\N	1567	2026-02-01 05:51:04.032
1568	1	1	55.1067797	82.9522739	2026-02-01 05:49:58.231	MOVE	33.56100082397461	0	0	\N	1568	2026-02-01 05:51:04.032
1569	1	1	55.1068547	82.9520993	2026-02-01 05:49:58.461	MOVE	106.5	2.442164897918701	314.7988586425781	\N	1569	2026-02-01 05:51:04.032
1570	1	1	55.1067758	82.952205	2026-02-01 05:50:15.308	MOVE	33.75400161743164	0	0	\N	1570	2026-02-01 05:51:04.032
1571	1	1	55.1067532	82.9523171	2026-02-01 05:50:41.602	MOVE	46.1349983215332	0.5673954486846924	162.1876983642578	\N	1571	2026-02-01 05:51:04.032
1572	1	1	55.106835	82.9522147	2026-02-01 05:50:57.511	MOVE	118	0.9300000071525574	40	\N	1572	2026-02-01 05:51:04.032
1573	1	1	55.1066228	82.9528153	2026-02-01 05:51:15.626	MOVE	45.90299987792969	0	0	\N	1573	2026-02-01 06:01:52.762
1574	1	1	55.1067897	82.9529867	2026-02-01 05:51:33.243	MOVE	197.2859954833984	1.083376169204712	286.2998657226562	\N	1574	2026-02-01 06:01:52.762
1575	1	1	55.1066204	82.9527152	2026-02-01 05:51:50.301	MOVE	55.20500183105469	0	0	\N	1575	2026-02-01 06:01:52.762
1576	1	1	55.1067739	82.9524382	2026-02-01 05:52:07.27	MOVE	35.99499893188477	2.327411651611328	67.0561752319336	\N	1576	2026-02-01 06:01:52.762
1577	1	1	55.1066303	82.9528483	2026-02-01 05:52:24.312	MOVE	44.37799835205078	0	0	\N	1577	2026-02-01 06:01:52.762
1578	1	1	55.1067843	82.9527236	2026-02-01 05:52:41.348	MOVE	48.03799819946289	0.2733282744884491	57.47621154785156	\N	1578	2026-02-01 06:01:52.762
1579	1	1	55.107004	82.9523448	2026-02-01 05:52:57.503	MOVE	51	2.789999961853027	249	\N	1579	2026-02-01 06:01:52.762
1580	1	1	55.106756	82.9522054	2026-02-01 05:53:15.656	MOVE	32.19900131225586	0	0	\N	1580	2026-02-01 06:01:52.762
1581	1	1	55.1065857	82.9527595	2026-02-01 05:53:43.128	MOVE	54.49100112915039	0	0	\N	1581	2026-02-01 06:01:52.762
1582	1	1	55.1066054	82.9529049	2026-02-01 05:54:00.155	MOVE	44.17699813842773	0	0	\N	1582	2026-02-01 06:01:52.762
1583	1	1	55.1086283	82.9701842	2026-02-01 05:54:17.151	MOVE	321.1950073242188	0	0	\N	1583	2026-02-01 06:01:52.762
1584	1	1	55.1068082	82.9524885	2026-02-01 05:54:31.467	MOVE	86.5	2.279999971389771	266	\N	1584	2026-02-01 06:01:52.762
1585	1	1	55.1067635	82.952238	2026-02-01 05:55:01.673	MOVE	34.9900016784668	0	0	\N	1585	2026-02-01 06:01:52.762
1586	1	1	55.1068005	82.9523422	2026-02-01 05:55:48.477	MOVE	79	2.579999923706055	268	\N	1586	2026-02-01 06:01:52.762
1587	1	1	55.1066905	82.9525679	2026-02-01 05:56:07.653	MOVE	52.63399887084961	0	0	\N	1587	2026-02-01 06:01:52.762
1588	1	1	55.1067649	82.9521911	2026-02-01 05:56:33.1	MOVE	31.01499938964844	0	0	\N	1588	2026-02-01 06:01:52.762
1589	1	1	55.1068355	82.9528931	2026-02-01 05:56:47.486	MOVE	85	4.601388931274414	83.9758071899414	\N	1589	2026-02-01 06:01:52.762
1590	1	1	55.1067358	82.9524871	2026-02-01 05:57:04.389	MOVE	51.39799880981445	0	0	\N	1590	2026-02-01 06:01:52.762
1591	1	1	55.1068254	82.9522556	2026-02-01 05:57:18.463	MOVE	60.5	3.00011944770813	263.8802185058594	\N	1591	2026-02-01 06:01:52.762
1592	1	1	55.1067794	82.9521655	2026-02-01 05:57:32.437	MOVE	36.30699920654297	1.252101421356201	254.9826965332031	\N	1592	2026-02-01 06:01:52.762
1593	1	1	55.1067895	82.9527956	2026-02-01 05:57:47.473	MOVE	53.5	4.769999980926514	279	\N	1593	2026-02-01 06:01:52.762
1594	1	1	55.1067973	82.9527096	2026-02-01 05:57:49.523	MOVE	73.99400329589844	4.743165016174316	279.0433654785156	\N	1594	2026-02-01 06:01:52.762
1595	1	1	55.1067616	82.9521756	2026-02-01 05:58:08.439	MOVE	35.58499908447266	0	0	\N	1595	2026-02-01 06:01:52.762
1596	1	1	55.1067695	82.9522925	2026-02-01 05:58:50.094	MOVE	35.16400146484375	0	0	\N	1596	2026-02-01 06:01:52.762
1597	1	1	55.1067647	82.9521905	2026-02-01 05:59:48.078	MOVE	32.25	0	0	\N	1597	2026-02-01 06:01:52.762
1598	1	1	55.1068899	82.9527243	2026-02-01 06:00:02.503	MOVE	54	1.507347941398621	346.0315551757812	\N	1598	2026-02-01 06:01:52.762
1599	1	1	55.1066097	82.952831	2026-02-01 06:00:22.078	MOVE	48.02899932861328	0	0	\N	1599	2026-02-01 06:01:52.762
1600	1	1	55.1067722	82.9521926	2026-02-01 06:00:48.393	MOVE	31.85000038146973	0	0	\N	1600	2026-02-01 06:01:52.762
1601	1	1	55.1067608	82.9524798	2026-02-01 06:01:06.313	MOVE	165.6909942626953	0.2960070669651031	302.3345336914062	\N	1601	2026-02-01 06:01:52.762
1602	1	1	55.1067687	82.9522007	2026-02-01 06:01:23.3	MOVE	30.84000015258789	0	0	\N	1602	2026-02-01 06:01:52.762
1603	1	1	55.1068236	82.9478786	2026-02-01 06:02:07.378	MOVE	244.1710052490234	1.88582456111908	95.95927429199219	\N	1603	2026-02-01 06:02:07.198
1604	1	1	55.1067843	82.9522937	2026-02-01 06:02:24.45	MOVE	16.87400054931641	0	0	\N	1604	2026-02-01 06:02:24.195
1605	1	1	55.1067642	82.9522043	2026-02-01 06:02:41.413	MOVE	31.13299942016602	0	0	\N	1605	2026-02-01 06:02:41.254
1606	1	1	55.106604	82.9528741	2026-02-01 06:03:15.463	MOVE	45.89400100708008	0	0	\N	1606	2026-02-01 06:03:15.866
1607	1	1	55.1067707	82.9521851	2026-02-01 06:03:32.601	MOVE	31.76199913024902	0	0	\N	1607	2026-02-01 06:03:32.678
1608	1	1	55.1068711	82.9521063	2026-02-01 06:03:49.586	MOVE	206.9140014648438	0.467688649892807	242.0679321289062	\N	1608	2026-02-01 06:03:50.567
1609	1	1	55.1067286	82.9523899	2026-02-01 06:04:06.654	MOVE	39.53799819946289	0	0	\N	1609	2026-02-01 06:10:06.512
1610	1	1	55.106791	82.9522876	2026-02-01 06:04:24.32	MOVE	27.98900032043457	0.3100117146968842	357.4900207519531	\N	1610	2026-02-01 06:10:06.512
1611	1	1	55.1067339	82.9523658	2026-02-01 06:04:41.355	MOVE	37.6150016784668	0	0	\N	1611	2026-02-01 06:10:06.512
1612	1	1	55.106783	82.9521511	2026-02-01 06:04:58.304	MOVE	34.11100006103516	1.775419116020203	268.8394775390625	\N	1612	2026-02-01 06:10:06.512
1613	1	1	55.1069105	82.9524475	2026-02-01 06:05:15.346	MOVE	123.2460021972656	0.3909521400928497	249.8570709228516	\N	1613	2026-02-01 06:10:06.512
1614	1	1	55.1067634	82.9521756	2026-02-01 06:05:32.397	MOVE	27.49399948120117	0	0	\N	1614	2026-02-01 06:10:06.512
1615	1	1	55.10682	82.9525452	2026-02-01 06:05:49.449	MOVE	146.7949981689453	0.1575518995523453	174.547119140625	\N	1615	2026-02-01 06:10:06.512
1616	1	1	55.1067695	82.9522026	2026-02-01 06:06:06.509	MOVE	32.8380012512207	0	0	\N	1616	2026-02-01 06:10:06.512
1617	1	1	55.1069463	82.9528811	2026-02-01 06:06:38.473	MOVE	47	1.465424776077271	97.96087646484375	\N	1617	2026-02-01 06:10:06.512
1618	1	1	55.1067838	82.9522285	2026-02-01 06:06:58.417	MOVE	24.95800018310547	0	0	\N	1618	2026-02-01 06:10:06.512
1619	1	1	55.1072163	82.952105	2026-02-01 06:07:15.491	MOVE	49	1.789999961853027	71	\N	1619	2026-02-01 06:10:06.512
1620	1	1	55.1065952	82.9528887	2026-02-01 06:07:32.442	MOVE	49.63399887084961	0	0	\N	1620	2026-02-01 06:10:06.512
1621	1	1	55.1066551	82.9527792	2026-02-01 06:07:59.481	MOVE	47.71500015258789	0.2093193531036377	265.7068786621094	\N	1621	2026-02-01 06:10:06.512
1622	1	1	55.106852	82.9524305	2026-02-01 06:08:16.488	MOVE	70	2.549999952316284	314	\N	1622	2026-02-01 06:10:06.512
1623	1	1	55.1067756	82.9522204	2026-02-01 06:08:33.585	MOVE	35.5620002746582	0	0	\N	1623	2026-02-01 06:10:06.512
1624	1	1	55.1068411	82.9520517	2026-02-01 06:09:00.095	MOVE	32.31600189208984	4.4869065284729	291.9679870605469	\N	1624	2026-02-01 06:10:06.512
1625	1	1	55.1071295	82.9522641	2026-02-01 06:09:15.496	MOVE	64.5	3.109999895095825	298	\N	1625	2026-02-01 06:10:06.512
1626	1	1	55.1065849	82.9528575	2026-02-01 06:09:34.171	MOVE	45.96900177001953	0	0	\N	1626	2026-02-01 06:10:06.512
1627	1	1	55.1068395	82.9521898	2026-02-01 06:09:51.328	MOVE	24.39200019836426	0.1346172988414764	269.0038757324219	\N	1627	2026-02-01 06:10:06.512
1628	1	1	55.1065776	82.9528942	2026-02-01 06:10:08.391	MOVE	50.4900016784668	0	0	\N	1628	2026-02-01 06:10:08.314
1629	1	1	55.1068327	82.952244	2026-02-01 06:10:28.814	MOVE	37.52199935913086	2.068084478378296	313.2102355957031	\N	1629	2026-02-01 06:22:14.109
1630	1	1	55.1068728	82.95234	2026-02-01 06:10:45.497	MOVE	56	2.609999895095825	120	\N	1630	2026-02-01 06:22:14.109
1631	1	1	55.1065484	82.9529858	2026-02-01 06:11:02.885	MOVE	14.2790002822876	0	0	\N	1631	2026-02-01 06:22:14.109
1632	1	1	55.1070362	82.9517597	2026-02-01 06:11:19.925	MOVE	197.2409973144531	4.83662223815918	295.0828552246094	\N	1632	2026-02-01 06:22:14.109
1633	1	1	55.1067677	82.9521915	2026-02-01 06:11:36.969	MOVE	32.57400131225586	0	0	\N	1633	2026-02-01 06:22:14.109
1634	1	1	55.1068164	82.9521406	2026-02-01 06:11:42.485	MOVE	48	7.580825328826904	122.1692581176758	\N	1634	2026-02-01 06:22:14.109
1635	1	1	55.1067552	82.9522215	2026-02-01 06:11:58.884	MOVE	33.09799957275391	0	0	\N	1635	2026-02-01 06:22:14.109
1636	1	1	55.1067586	82.9528184	2026-02-01 06:12:15.481	MOVE	58	2.379999876022339	289	\N	1636	2026-02-01 06:22:14.109
1637	1	1	55.1067938	82.9522455	2026-02-01 06:12:32.903	MOVE	22.85400009155273	0	0	\N	1637	2026-02-01 06:22:14.109
1638	1	1	55.1067851	82.9528318	2026-02-01 06:13:15.454	MOVE	197.5	2.409999847412109	295	\N	1638	2026-02-01 06:22:14.109
1639	1	1	55.1065621	82.952924	2026-02-01 06:13:34.423	MOVE	48.10200119018555	0	0	\N	1639	2026-02-01 06:22:14.109
1640	1	1	55.1066528	82.9527675	2026-02-01 06:13:59.087	MOVE	46.40599822998047	2.12256383895874	306.6948547363281	\N	1640	2026-02-01 06:22:14.109
1641	1	1	55.106843	82.9523753	2026-02-01 06:14:12.44	MOVE	48	3.802478790283203	274.0297546386719	\N	1641	2026-02-01 06:22:14.109
1642	1	1	55.1067671	82.9522248	2026-02-01 06:14:28.487	MOVE	32.38899993896484	0	0	\N	1642	2026-02-01 06:22:14.109
1643	1	1	55.1068072	82.9528266	2026-02-01 06:14:44.45	MOVE	49.5	0.8799999952316284	88	\N	1643	2026-02-01 06:22:14.109
1644	1	1	55.1067705	82.9522075	2026-02-01 06:15:02.541	MOVE	31.50200080871582	0	0	\N	1644	2026-02-01 06:22:14.109
1645	1	1	55.1069473	82.9524975	2026-02-01 06:15:19.568	MOVE	147.5220031738281	3.040194511413574	116.0095901489258	\N	1645	2026-02-01 06:22:14.109
1646	1	1	55.1067697	82.952186	2026-02-01 06:15:36.6	MOVE	33.06999969482422	0	0	\N	1646	2026-02-01 06:22:14.109
1647	1	1	55.1067131	82.9523986	2026-02-01 06:15:54.375	MOVE	32.38700103759766	3.505832672119141	127.9565124511719	\N	1647	2026-02-01 06:22:14.109
1648	1	1	55.1067666	82.9522518	2026-02-01 06:16:11.397	MOVE	32.81700134277344	0	0	\N	1648	2026-02-01 06:22:14.109
1649	1	1	55.106775	82.9524351	2026-02-01 06:16:28.439	MOVE	33.78400039672852	1.658948421478271	103.6725769042969	\N	1649	2026-02-01 06:22:14.109
1650	1	1	55.1069228	82.9521967	2026-02-01 06:16:45.465	MOVE	69.5	0.5699999928474426	204	\N	1650	2026-02-01 06:22:14.109
1651	1	1	55.1067815	82.9522503	2026-02-01 06:17:02.411	MOVE	33.7599983215332	0	0	\N	1651	2026-02-01 06:22:14.109
1652	1	1	55.1068168	82.9520591	2026-02-01 06:17:19.436	MOVE	142.9869995117188	1.878718376159668	268.9977722167969	\N	1652	2026-02-01 06:22:14.109
1653	1	1	55.106547	82.9529237	2026-02-01 06:17:36.465	MOVE	49.13600158691406	0	0	\N	1653	2026-02-01 06:22:14.109
1654	1	1	55.1068096	82.9523937	2026-02-01 06:17:53.413	MOVE	216.8200073242188	0.05325754731893539	0	\N	1654	2026-02-01 06:22:14.109
1655	1	1	55.106771	82.952201	2026-02-01 06:18:10.456	MOVE	32.64400100708008	0	0	\N	1655	2026-02-01 06:22:14.109
1656	1	1	55.1068529	82.9525063	2026-02-01 06:18:45.461	MOVE	75.5	8.329999923706055	99	\N	1656	2026-02-01 06:22:14.109
1657	1	1	55.1067748	82.9522658	2026-02-01 06:19:02.737	MOVE	32.11899948120117	0	0	\N	1657	2026-02-01 06:22:14.109
1658	1	1	55.1066643	82.952601	2026-02-01 06:19:29.406	MOVE	47.92200088500977	4.500646114349365	124.9182052612305	\N	1658	2026-02-01 06:22:14.109
1659	1	1	55.1068565	82.9526707	2026-02-01 06:19:45.483	MOVE	60.5	1	61	\N	1659	2026-02-01 06:22:14.109
1660	1	1	55.1067731	82.9521911	2026-02-01 06:20:03.398	MOVE	31.80900001525879	0	0	\N	1660	2026-02-01 06:22:14.109
1661	1	1	55.1065506	82.9529252	2026-02-01 06:20:29.057	MOVE	20.91900062561035	0	0	\N	1661	2026-02-01 06:22:14.109
1662	1	1	55.1067269	82.9528309	2026-02-01 06:20:45.466	MOVE	84	5.519999980926514	144	\N	1662	2026-02-01 06:22:14.109
1663	1	1	55.1067418	82.9523442	2026-02-01 06:21:03.527	MOVE	36.28400039672852	0	0	\N	1663	2026-02-01 06:22:14.109
1664	1	1	55.1069964	82.9521014	2026-02-01 06:21:21.401	MOVE	174.9669952392578	0.7229170203208923	305.3099365234375	\N	1664	2026-02-01 06:22:14.109
1665	1	1	55.1065995	82.9528341	2026-02-01 06:21:38.437	MOVE	48.29299926757812	0	0	\N	1665	2026-02-01 06:22:14.109
1666	1	1	55.1067251	82.9525586	2026-02-01 06:21:55.491	MOVE	36.43899917602539	0.6505861878395081	263.2696533203125	\N	1666	2026-02-01 06:22:14.109
1667	1	1	55.106788	82.9531021	2026-02-01 06:22:11.654	MOVE	45.75	0.1810314804315567	228.3819427490234	\N	1667	2026-02-01 06:22:14.109
1668	1	1	55.1067684	82.9521955	2026-02-01 06:22:30.713	MOVE	30.89299964904785	0	0	\N	1668	2026-02-01 06:31:32.583
1669	1	1	55.1068527	82.9521294	2026-02-01 06:22:48.496	MOVE	187.6710052490234	1.028085708618164	131.5103912353516	\N	1669	2026-02-01 06:31:32.583
1670	1	1	55.1066041	82.9528512	2026-02-01 06:23:05.441	MOVE	46.50299835205078	0	0	\N	1670	2026-02-01 06:31:32.583
1671	1	1	55.1067069	82.9529987	2026-02-01 06:23:23.397	MOVE	214.5290069580078	1.260050296783447	117.0466613769531	\N	1671	2026-02-01 06:31:32.583
1672	1	1	55.1069474	82.9521797	2026-02-01 06:23:39.47	MOVE	47	0.5199999809265137	103	\N	1672	2026-02-01 06:31:32.583
1673	1	1	55.1067702	82.9522092	2026-02-01 06:23:57.523	MOVE	31.18199920654297	0	0	\N	1673	2026-02-01 06:31:32.583
1674	1	1	55.1068239	82.9525708	2026-02-01 06:24:12.475	MOVE	49	4.82547664642334	302.1422424316406	\N	1674	2026-02-01 06:31:32.583
1675	1	1	55.1068628	82.9524798	2026-02-01 06:24:14.559	MOVE	69.8479995727539	4.795046806335449	302.2792053222656	\N	1675	2026-02-01 06:31:32.583
1676	1	1	55.1067502	82.9523261	2026-02-01 06:24:31.549	MOVE	28.9330005645752	0	0	\N	1676	2026-02-01 06:31:32.583
1677	1	1	55.1068336	82.9518414	2026-02-01 06:24:49.431	MOVE	166.5619964599609	0.3146640658378601	290.7455749511719	\N	1677	2026-02-01 06:31:32.583
1678	1	1	55.1067488	82.9523708	2026-02-01 06:25:06.454	MOVE	41.25600051879883	0	0	\N	1678	2026-02-01 06:31:32.583
1679	1	1	55.1067592	82.9522084	2026-02-01 06:26:04.497	MOVE	31.7140007019043	0	0	\N	1679	2026-02-01 06:31:32.583
1680	1	1	55.106899	82.951938	2026-02-01 06:26:22.467	MOVE	196.4830017089844	1.609055638313293	278.0733642578125	\N	1680	2026-02-01 06:31:32.583
1681	1	1	55.1067172	82.9523982	2026-02-01 06:26:39.443	MOVE	37.86000061035156	0	0	\N	1681	2026-02-01 06:31:32.583
1682	1	1	55.106635	82.9528555	2026-02-01 06:26:56.423	MOVE	43.5620002746582	1.900359630584717	107.390022277832	\N	1682	2026-02-01 06:31:32.583
1683	1	1	55.107131	82.9512879	2026-02-01 06:27:11.649	MOVE	41.25	4.165997505187988	291.9401550292969	\N	1683	2026-02-01 06:31:32.583
1684	1	1	55.1065857	82.9528885	2026-02-01 06:27:30.757	MOVE	50.4379997253418	0	0	\N	1684	2026-02-01 06:31:32.583
1685	1	1	55.1067503	82.9527838	2026-02-01 06:27:45.443	MOVE	60.5	7.061469554901123	102.1059417724609	\N	1685	2026-02-01 06:31:32.583
1686	1	1	55.106696	82.9526827	2026-02-01 06:27:59.523	MOVE	39.11999893188477	3.943641901016235	111.2225646972656	\N	1686	2026-02-01 06:31:32.583
1687	1	1	55.1066325	82.9529203	2026-02-01 06:28:16.548	MOVE	128.2299957275391	0.886613667011261	113.0692596435547	\N	1687	2026-02-01 06:31:32.583
1688	1	1	55.106578	82.9528577	2026-02-01 06:28:33.562	MOVE	48.55599975585938	0	0	\N	1688	2026-02-01 06:31:32.583
1689	1	1	55.1067129	82.9529687	2026-02-01 06:28:51.439	MOVE	180.1779937744141	0.9517520070075989	277.0710144042969	\N	1689	2026-02-01 06:31:32.583
1690	1	1	55.1067676	82.9522138	2026-02-01 06:29:08.468	MOVE	30.39900016784668	0	0	\N	1690	2026-02-01 06:31:32.583
1691	1	1	55.1068919	82.9525901	2026-02-01 06:29:30.37	MOVE	52.27399826049805	4.255345344543457	353.5245971679688	\N	1691	2026-02-01 06:31:32.583
1692	1	1	55.1067519	82.9524507	2026-02-01 06:29:47.401	MOVE	145.3399963378906	2.916707754135132	126.1608123779297	\N	1692	2026-02-01 06:31:32.583
1693	1	1	55.106765	82.9522473	2026-02-01 06:30:04.461	MOVE	30.70899963378906	0	0	\N	1693	2026-02-01 06:31:32.583
1694	1	1	55.1068031	82.952394	2026-02-01 06:30:21.473	MOVE	54.74399948120117	0.2299310564994812	296.8446960449219	\N	1694	2026-02-01 06:31:32.583
1695	1	1	55.1067646	82.9521904	2026-02-01 06:30:38.477	MOVE	31.16799926757812	0	0	\N	1695	2026-02-01 06:31:32.583
1696	1	1	55.1068242	82.9521424	2026-02-01 06:30:56.507	MOVE	28.65999984741211	0.3088322281837463	287.2541809082031	\N	1696	2026-02-01 06:31:32.583
1697	1	1	55.1065741	82.9528849	2026-02-01 06:31:13.511	MOVE	50.90200042724609	0	0	\N	1697	2026-02-01 06:31:32.583
1698	1	1	55.1067714	82.9522048	2026-02-01 06:31:30.556	MOVE	31.0890007019043	0	0	\N	1698	2026-02-01 06:31:32.583
1699	1	1	55.1069527	82.9522255	2026-02-01 06:31:38.407	MOVE	47	5.664773941040039	313.4075622558594	\N	1699	2026-02-01 06:31:53.03
1700	1	1	55.106782	82.9521333	2026-02-01 06:31:55.629	MOVE	31.20499992370605	0	0	\N	1700	2026-02-01 06:31:55.279
1701	1	1	55.1068042	82.9526773	2026-02-01 06:32:08.411	MOVE	39.5	2.969568967819214	74.9717788696289	\N	1701	2026-02-01 06:32:22.974
1702	1	1	55.1068888	82.95193	2026-02-01 06:32:26.305	MOVE	21.80999946594238	0	0	\N	1702	2026-02-01 06:32:25.865
1703	1	1	55.1068322	82.9522505	2026-02-01 06:32:40.436	MOVE	49.5	2.78956127166748	131.8741912841797	\N	1703	2026-02-01 06:32:40.045
1704	1	1	55.1067729	82.952262	2026-02-01 06:32:55.163	MOVE	14.48499965667725	1.424200415611267	138.7213287353516	\N	1704	2026-02-01 06:32:54.757
1705	1	1	55.1067542	82.9521891	2026-02-01 06:33:12.076	MOVE	27.09099960327148	0	0	\N	1705	2026-02-01 06:33:11.72
1706	1	1	55.1083969	82.9492783	2026-02-01 06:33:12.399	MOVE	44.54499816894531	9.760000228881836	301	\N	1706	2026-02-01 06:33:27.02
1707	1	1	55.1067819	82.9521341	2026-02-01 06:33:29.04	MOVE	27.16600036621094	0	0	\N	1707	2026-02-01 06:33:28.622
1708	1	1	55.1066077	82.9526748	2026-02-01 06:33:33.42	MOVE	42.52700042724609	3.035171270370483	141.8003845214844	\N	1708	2026-02-01 06:33:48.019
1709	1	1	55.1066879	82.9527397	2026-02-01 06:33:51.093	MOVE	48.22800064086914	0	0	\N	1709	2026-02-01 06:33:50.674
1710	1	1	55.1065632	82.9541196	2026-02-01 06:34:07.395	MOVE	52	9.569999694824219	99	\N	1710	2026-02-01 06:34:07.051
1711	1	1	55.106623	82.9528951	2026-02-01 06:34:24.92	MOVE	39.18899917602539	0	0	\N	1711	2026-02-01 06:34:24.504
1712	1	1	55.1067566	82.9526278	2026-02-01 06:34:41.875	MOVE	196.8379974365234	0.6615515351295471	141.8092803955078	\N	1712	2026-02-01 06:34:41.525
1713	1	1	55.1067946	82.9521414	2026-02-01 06:34:58.822	MOVE	29.66600036621094	0	0	\N	1713	2026-02-01 06:34:58.441
1714	1	1	55.1067605	82.9523433	2026-02-01 06:35:04.413	MOVE	43.5	6.339051723480225	107.5055694580078	\N	1714	2026-02-01 06:35:19.007
1715	1	1	55.1066982	82.9527027	2026-02-01 06:35:20.156	MOVE	43.61600112915039	0	0	\N	1715	2026-02-01 06:35:19.756
1716	1	1	55.1068156	82.952082	2026-02-01 06:35:37.114	MOVE	31.87800025939941	0	0	\N	1716	2026-02-01 06:35:38.427
1717	1	1	55.1067325	82.952717	2026-02-01 06:35:37.405	MOVE	45.18899917602539	3.231829881668091	104.2393493652344	\N	1717	2026-02-01 06:35:53.218
1718	1	1	55.1068182	82.9520882	2026-02-01 06:35:54.03	MOVE	32.2859992980957	0	0	\N	1718	2026-02-01 06:35:53.655
1719	1	1	55.1067756	82.9522748	2026-02-01 06:36:19.828	MOVE	14.37100028991699	0.6290009021759033	130.6011199951172	\N	1719	2026-02-01 06:36:19.493
1720	1	1	55.1065548	82.9531481	2026-02-01 06:36:35.414	MOVE	48	3.210000038146973	189	\N	1720	2026-02-01 06:36:35.097
1721	1	1	55.1067678	82.9522564	2026-02-01 06:36:53.649	MOVE	19.72699928283691	0	0	\N	1721	2026-02-01 06:36:53.251
1722	1	1	55.1066863	82.9533312	2026-02-01 06:37:07.413	MOVE	100.5	18.81138229370117	80.89863586425781	\N	1722	2026-02-01 06:37:07.087
1723	1	1	55.1067727	82.9522954	2026-02-01 06:37:21.291	MOVE	21.64200019836426	1.436954617500305	313.2699584960938	\N	1723	2026-02-01 06:37:20.928
1724	1	1	55.1072495	82.950353	2026-02-01 06:37:36.411	MOVE	49.5	2.720000028610229	289	\N	1724	2026-02-01 06:37:36.055
1725	1	1	55.1067805	82.9522619	2026-02-01 06:37:55.159	MOVE	14.77799987792969	0	0	\N	1725	2026-02-01 06:37:54.726
1726	1	1	55.106337	82.9554145	2026-02-01 06:38:37.448	MOVE	121.5	13.71000003814697	113	\N	1726	2026-02-01 06:38:37.159
1727	1	1	55.1063053	82.9555447	2026-02-01 06:38:39.053	MOVE	137.531005859375	13.65502834320068	113.0600280761719	\N	1727	2026-02-01 06:38:53.704
1728	1	1	55.1067771	82.9522723	2026-02-01 06:38:56.03	MOVE	29.13100051879883	0	0	\N	1728	2026-02-01 06:38:55.763
1729	1	1	55.1067335	82.9522516	2026-02-01 06:39:22.376	MOVE	20.32399940490723	1.515966653823853	196.0033569335938	\N	1729	2026-02-01 06:39:22.18
1730	1	1	55.1069717	82.9513705	2026-02-01 06:39:37.444	MOVE	102	8.170000076293945	103	\N	1730	2026-02-01 06:39:37.119
1731	1	1	55.106807	82.9522805	2026-02-01 06:39:56.901	MOVE	42.50500106811523	0	0	\N	1731	2026-02-01 06:39:56.747
1732	1	1	55.1070115	82.951596	2026-02-01 06:40:13.949	MOVE	354.5379943847656	3.009268999099731	7.236270427703857	\N	1732	2026-02-01 06:40:13.762
1733	1	1	55.1065594	82.952907	2026-02-01 06:40:31.008	MOVE	29.91500091552734	0	0	\N	1733	2026-02-01 06:42:27.699
1734	1	1	55.1066078	82.9527593	2026-02-01 06:40:48.527	MOVE	37.66500091552734	1.459612607955933	269.6599426269531	\N	1734	2026-02-01 06:42:27.699
1735	1	1	55.1067596	82.9522868	2026-02-01 06:41:24.223	MOVE	16.98900032043457	0	0	\N	1735	2026-02-01 06:42:27.699
1736	1	1	55.1070177	82.9503755	2026-02-01 06:41:39.394	MOVE	242.5	3.079999923706055	108	\N	1736	2026-02-01 06:42:27.699
1737	1	1	55.1067744	82.9522243	2026-02-01 06:41:58.23	MOVE	22.16900062561035	0	0	\N	1737	2026-02-01 06:42:27.699
1738	1	1	55.1068431	82.9524783	2026-02-01 06:42:15.25	MOVE	201.4640045166016	1.80502188205719	103.1043395996094	\N	1738	2026-02-01 06:42:27.699
1739	1	1	55.1068749	82.9519159	2026-02-01 06:42:32.17	MOVE	51.83599853515625	0	0	\N	1739	2026-02-01 06:42:31.756
1740	1	1	55.1067903	82.952267	2026-02-01 06:42:49.063	MOVE	12.99100017547607	0	0	\N	1740	2026-02-01 06:42:48.704
1741	1	1	55.106883	82.9519523	2026-02-01 06:43:23.258	MOVE	23.03899955749512	0	0	\N	1741	2026-02-01 06:43:22.955
1742	1	1	55.1067701	82.9522473	2026-02-01 06:43:40.233	MOVE	19.58799934387207	0	0	\N	1742	2026-02-01 06:43:39.895
1743	1	1	55.106203	82.9541539	2026-02-01 06:43:56.432	MOVE	150.5	1.449999928474426	0	\N	1743	2026-02-01 06:43:56.086
1744	1	1	55.1065734	82.9529538	2026-02-01 06:44:14.107	MOVE	50.45399856567383	2.413114309310913	144.8346557617188	\N	1744	2026-02-01 06:44:13.818
1745	1	1	55.1067865	82.9522363	2026-02-01 06:44:31.077	MOVE	16.31900024414062	0	0	\N	1745	2026-02-01 06:44:30.729
1746	1	1	55.1067527	82.9523767	2026-02-01 06:44:51.663	MOVE	29.59000015258789	5.084035873413086	103.4078903198242	\N	1746	2026-02-01 06:44:51.408
1747	1	1	55.1066864	82.9525903	2026-02-01 06:45:04.405	MOVE	49.5	3.152904272079468	116.0971069335938	\N	1747	2026-02-01 06:45:19.089
1748	1	1	55.1066159	82.9528584	2026-02-01 06:45:21.299	MOVE	51.09600067138672	0	0	\N	1748	2026-02-01 06:45:20.987
1749	1	1	55.1068752	82.9520111	2026-02-01 06:45:37.413	MOVE	83	1.740000009536743	138	\N	1749	2026-02-01 06:45:37.184
1750	1	1	55.106716	82.9525036	2026-02-01 06:45:55.228	MOVE	43.00299835205078	0	0	\N	1750	2026-02-01 06:45:54.936
1751	1	1	55.1070091	82.9520929	2026-02-01 06:46:07.395	MOVE	72.5	1.056998014450073	138.9153747558594	\N	1751	2026-02-01 06:46:22.025
1752	1	1	55.1067798	82.9522783	2026-02-01 06:46:23.092	MOVE	30.96699905395508	0	0	\N	1752	2026-02-01 06:46:22.76
1753	1	1	55.1068216	82.9528821	2026-02-01 06:46:37.414	MOVE	79	1.910660743713379	118.8741302490234	\N	1753	2026-02-01 06:46:37.15
1754	1	1	55.1067837	82.9524094	2026-02-01 06:46:51.368	MOVE	41.57300186157227	0.9652413725852966	149.3874053955078	\N	1754	2026-02-01 06:46:51.092
1755	1	1	55.1063111	82.9513054	2026-02-01 06:47:07.413	MOVE	63	9.079999923706055	232	\N	1755	2026-02-01 06:47:07.196
1756	1	1	55.1067627	82.9521646	2026-02-01 06:47:25.29	MOVE	28.375	0	0	\N	1756	2026-02-01 06:47:24.954
1757	1	1	55.1067724	82.9522811	2026-02-01 06:47:51.653	MOVE	31.0319995880127	1.825741410255432	68.21094512939453	\N	1757	2026-02-01 06:47:51.31
1758	1	1	55.1068777	82.9524647	2026-02-01 06:48:08.416	MOVE	125	0.6499999761581421	49	\N	1758	2026-02-01 06:48:08.497
1759	1	1	55.1067813	82.9522411	2026-02-01 06:48:25.525	MOVE	19.9640007019043	0	0	\N	1759	2026-02-01 06:51:05.739
1760	1	1	55.1064809	82.954046	2026-02-01 06:49:03.411	MOVE	44.25	9.288763046264648	76.38311004638672	\N	1760	2026-02-01 06:51:05.739
1761	1	1	55.1067741	82.952235	2026-02-01 06:49:20.864	MOVE	19.6919994354248	0	0	\N	1761	2026-02-01 06:51:05.739
1762	1	1	55.1069108	82.9532514	2026-02-01 06:49:33.412	MOVE	42.25	7.924606323242188	101.9571762084961	\N	1762	2026-02-01 06:51:05.739
1763	1	1	55.1067806	82.9521334	2026-02-01 06:49:49.976	MOVE	29.36100006103516	0	0	\N	1763	2026-02-01 06:51:05.739
1764	1	1	55.1070084	82.9525211	2026-02-01 06:50:06.406	MOVE	46	4.210000038146973	109	\N	1764	2026-02-01 06:51:05.739
1765	1	1	55.1067947	82.9521603	2026-02-01 06:50:23.891	MOVE	29.53499984741211	0	0	\N	1765	2026-02-01 06:51:05.739
1766	1	1	55.1068913	82.9517937	2026-02-01 06:50:37.395	MOVE	68.5	5.757740497589111	281.0956115722656	\N	1766	2026-02-01 06:51:05.739
1767	1	1	55.1067846	82.9522249	2026-02-01 06:50:50.75	MOVE	13.67099952697754	2.535406112670898	292.8221435546875	\N	1767	2026-02-01 06:51:05.739
1768	1	1	55.106987	82.9519154	2026-02-01 06:51:07.402	MOVE	58	1.899999976158142	106	\N	1768	2026-02-01 07:02:03.541
1769	1	1	55.1067726	82.9522395	2026-02-01 06:51:24.556	MOVE	19.11800003051758	0	0	\N	1769	2026-02-01 07:02:03.541
1770	1	1	55.1069265	82.9521413	2026-02-01 06:51:35.391	MOVE	47.5	7.907394886016846	290.160400390625	\N	1770	2026-02-01 07:02:03.541
1771	1	1	55.1065682	82.952917	2026-02-01 06:51:50.823	MOVE	40.01200103759766	0	0	\N	1771	2026-02-01 07:02:03.541
1772	1	1	55.1068675	82.9521654	2026-02-01 06:52:05.397	MOVE	48.5	1.801066875457764	255.0372009277344	\N	1772	2026-02-01 07:02:03.541
1773	1	1	55.1067755	82.9522491	2026-02-01 06:52:24.698	MOVE	19.35400009155273	0	0	\N	1773	2026-02-01 07:02:03.541
1774	1	1	55.1068659	82.9520973	2026-02-01 06:52:38.411	MOVE	69	12.55603981018066	263.899169921875	\N	1774	2026-02-01 07:02:03.541
1775	1	1	55.106765	82.9520737	2026-02-01 06:52:51.067	MOVE	29.75699996948242	6.217796325683594	257.7828369140625	\N	1775	2026-02-01 07:02:03.541
1776	1	1	55.1068313	82.9524327	2026-02-01 06:53:07.413	MOVE	52.5	5.519999980926514	238	\N	1776	2026-02-01 07:02:03.541
1777	1	1	55.1067855	82.9522435	2026-02-01 06:53:25.008	MOVE	16.10700035095215	0	0	\N	1777	2026-02-01 07:02:03.541
1778	1	1	55.106847	82.9520774	2026-02-01 06:53:51.164	MOVE	24.71599960327148	0.3242882192134857	9.502813339233398	\N	1778	2026-02-01 07:02:03.541
1779	1	1	55.1068609	82.9527748	2026-02-01 06:54:07.414	MOVE	54.5	0.550000011920929	5	\N	1779	2026-02-01 07:02:03.541
1780	1	1	55.1067975	82.9522144	2026-02-01 06:54:25.159	MOVE	22.41200065612793	0	0	\N	1780	2026-02-01 07:02:03.541
1781	1	1	55.1068821	82.9519332	2026-02-01 06:54:51.637	MOVE	22.56800079345703	1.089451909065247	252.3679504394531	\N	1781	2026-02-01 07:02:03.541
1782	1	1	55.1069304	82.9521946	2026-02-01 06:55:07.404	MOVE	58.5	3.480000019073486	290	\N	1782	2026-02-01 07:02:03.541
1783	1	1	55.1067973	82.9521101	2026-02-01 06:55:23.327	MOVE	35.01399993896484	0.9771459102630615	220.1519012451172	\N	1783	2026-02-01 07:02:03.541
1784	1	1	55.1068045	82.953247	2026-02-01 06:55:34.397	MOVE	49.5	1.679372787475586	94.1854476928711	\N	1784	2026-02-01 07:02:03.541
1785	1	1	55.1067723	82.9522888	2026-02-01 06:55:42.726	MOVE	22.88999938964844	3.85442852973938	267.9473266601562	\N	1785	2026-02-01 07:02:03.541
1786	1	1	55.1067926	82.9522088	2026-02-01 06:56:07.711	MOVE	23.0890007019043	0	0	\N	1786	2026-02-01 07:02:03.541
1787	1	1	55.1068481	82.9522174	2026-02-01 06:56:58.522	MOVE	21.80500030517578	0	0	\N	1787	2026-02-01 07:02:03.541
1788	1	1	55.1067906	82.9522577	2026-02-01 06:57:15.467	MOVE	18.09799957275391	0	0	\N	1788	2026-02-01 07:02:03.541
1789	1	1	55.1068221	82.9521541	2026-02-01 06:57:32.427	MOVE	23.86599922180176	0	0	\N	1789	2026-02-01 07:02:03.541
1790	1	1	55.1067621	82.9522534	2026-02-01 06:58:06.316	MOVE	19.15900039672852	0	0	\N	1790	2026-02-01 07:02:03.541
1791	1	1	55.1068226	82.9521866	2026-02-01 06:58:40.135	MOVE	44.62300109863281	0	0	\N	1791	2026-02-01 07:02:03.541
1792	1	1	55.1067379	82.9524134	2026-02-01 06:59:14.065	MOVE	45.9739990234375	0	0	\N	1792	2026-02-01 07:02:03.541
1793	1	1	55.106777	82.9522504	2026-02-01 06:59:31.006	MOVE	15.73799991607666	0	0	\N	1793	2026-02-01 07:02:03.541
1794	1	1	55.1066229	82.9529035	2026-02-01 07:01:46.481	MOVE	42.91699981689453	0	0	\N	1794	2026-02-01 07:02:03.541
1795	1	1	55.1067575	82.9522254	2026-02-01 07:02:03.4	MOVE	30.92200088500977	0	0	\N	1795	2026-02-01 07:02:03.541
1796	1	1	55.1068366	82.9521123	2026-02-01 07:02:20.359	MOVE	24.79100036621094	0	0	\N	1796	2026-02-01 07:02:19.955
1797	1	1	55.1065829	82.9528648	2026-02-01 07:02:37.323	MOVE	32.75099945068359	0	0	\N	1797	2026-02-01 07:02:36.909
1798	1	1	55.1067902	82.9522553	2026-02-01 07:02:54.289	MOVE	15.51799964904785	0	0	\N	1798	2026-02-01 07:02:53.869
1799	1	1	55.1067781	82.9521352	2026-02-01 07:03:45.098	MOVE	29.71100044250488	0	0	\N	1799	2026-02-01 07:03:44.757
1800	1	1	55.1065841	82.9527473	2026-02-01 07:04:02.002	MOVE	52.14300155639648	0	0	\N	1800	2026-02-01 07:04:01.589
1801	1	1	55.1067642	82.9521936	2026-02-01 07:04:18.952	MOVE	36.08499908447266	0	0	\N	1801	2026-02-01 07:10:11.069
1802	1	1	55.1068892	82.9519349	2026-02-01 07:05:26.69	MOVE	20.89699935913086	0	0	\N	1802	2026-02-01 07:10:11.069
1803	1	1	55.1067746	82.9521903	2026-02-01 07:05:55.682	MOVE	30.4950008392334	1.042610645294189	126.0329055786133	\N	1803	2026-02-01 07:10:11.069
1804	1	1	55.1066577	82.9526109	2026-02-01 07:06:31.204	MOVE	51.89599990844727	0	0	\N	1804	2026-02-01 07:10:11.069
1805	1	1	55.1067561	82.95219	2026-02-01 07:07:05.05	MOVE	26.81999969482422	0	0	\N	1805	2026-02-01 07:10:11.069
1806	1	1	55.1067782	82.9522674	2026-02-01 07:07:21.951	MOVE	14.85499954223633	0	0	\N	1806	2026-02-01 07:10:11.069
1807	1	1	55.1065923	82.952856	2026-02-01 07:07:55.832	MOVE	45.84600067138672	0	0	\N	1807	2026-02-01 07:10:11.069
1808	1	1	55.1067745	82.952271	2026-02-01 07:08:12.739	MOVE	14.25	0	0	\N	1808	2026-02-01 07:10:11.069
1809	1	1	55.1067625	82.9521875	2026-02-01 07:10:45.13	MOVE	28.38999938964844	0	0	\N	1809	2026-02-01 07:23:21.698
1810	1	1	55.1101665	82.947072	2026-02-01 07:11:51.561	MOVE	225.5599975585938	0	0	\N	1810	2026-02-01 07:23:21.698
1811	1	1	55.106659	82.9529424	2026-02-01 07:12:07.398	MOVE	40	2.779999971389771	193	\N	1811	2026-02-01 07:23:21.698
1812	1	1	55.1066949	82.9524519	2026-02-01 07:12:32.352	MOVE	43.63299942016602	0	0	\N	1812	2026-02-01 07:23:21.698
1813	1	1	55.1067699	82.9522054	2026-02-01 07:12:49.378	MOVE	30.88100051879883	0	0	\N	1813	2026-02-01 07:23:21.698
1814	1	1	55.1068745	82.9521831	2026-02-01 07:14:14.144	MOVE	21.97299957275391	0	0	\N	1814	2026-02-01 07:23:21.698
1815	1	1	55.1066075	82.9528739	2026-02-01 07:14:31.113	MOVE	39.1510009765625	0	0	\N	1815	2026-02-01 07:23:21.698
1816	1	1	55.1067461	82.9526122	2026-02-01 07:14:48.106	MOVE	47.38000106811523	0	0	\N	1816	2026-02-01 07:23:21.698
1817	1	1	55.1068399	82.9521299	2026-02-01 07:15:05.09	MOVE	38.29499816894531	0	0	\N	1817	2026-02-01 07:23:21.698
1818	1	1	55.1067864	82.952251	2026-02-01 07:15:22.017	MOVE	14.80399990081787	0	0	\N	1818	2026-02-01 07:23:21.698
1819	1	1	55.1067277	82.9526575	2026-02-01 07:15:38.965	MOVE	46.26499938964844	0	0	\N	1819	2026-02-01 07:23:21.698
1820	1	1	55.1067604	82.9522366	2026-02-01 07:15:55.901	MOVE	31.82299995422363	0	0	\N	1820	2026-02-01 07:23:21.698
1821	1	1	55.1068874	82.9518946	2026-02-01 07:16:29.891	MOVE	43.41299819946289	0	0	\N	1821	2026-02-01 07:23:21.698
1822	1	1	55.1065625	82.9529704	2026-02-01 07:16:46.921	MOVE	16.78700065612793	0	0	\N	1822	2026-02-01 07:23:21.698
1823	1	1	55.1067715	82.9522532	2026-02-01 07:17:03.887	MOVE	21.14100074768066	0	0	\N	1823	2026-02-01 07:23:21.698
1824	1	1	55.1065756	82.9528907	2026-02-01 07:18:11.657	MOVE	47.10699844360352	0	0	\N	1824	2026-02-01 07:23:21.698
1825	1	1	55.1067216	82.9523889	2026-02-01 07:18:28.638	MOVE	44.7140007019043	0	0	\N	1825	2026-02-01 07:23:21.698
1826	1	1	55.1066244	82.952809	2026-02-01 07:18:45.57	MOVE	47.5	0	0	\N	1826	2026-02-01 07:23:21.698
1827	1	1	55.1067655	82.9522465	2026-02-01 07:19:02.516	MOVE	20.77499961853027	0	0	\N	1827	2026-02-01 07:23:21.698
1828	1	1	55.1068115	82.9520878	2026-02-01 07:19:19.479	MOVE	27.97200012207031	0	0	\N	1828	2026-02-01 07:23:21.698
1829	1	1	55.1067875	82.9522655	2026-02-01 07:19:36.449	MOVE	17.88800048828125	0	0	\N	1829	2026-02-01 07:23:21.698
1830	1	1	55.1067603	82.9521782	2026-02-01 07:21:01.602	MOVE	30.67799949645996	0	0	\N	1830	2026-02-01 07:23:21.698
1831	1	1	55.106773	82.9522632	2026-02-01 07:21:32.444	MOVE	20.40500068664551	0	0	\N	1831	2026-02-01 07:23:21.698
1832	1	1	55.1067429	82.9523487	2026-02-01 07:22:40.54	MOVE	41.35400009155273	0	0	\N	1832	2026-02-01 07:23:21.698
1833	1	1	55.1067992	82.9523112	2026-02-01 07:22:57.587	MOVE	33.84400177001953	0	0	\N	1833	2026-02-01 07:23:21.698
1834	1	1	55.106754	82.9521916	2026-02-01 07:26:37.689	MOVE	33.04399871826172	0	0	\N	1834	2026-02-01 07:34:33.512
1835	1	1	55.1066074	82.9529076	2026-02-01 07:27:45.663	MOVE	48.84600067138672	0	0	\N	1835	2026-02-01 07:34:33.512
1836	1	1	55.1067721	82.952224	2026-02-01 07:28:02.657	MOVE	33.04499816894531	0	0	\N	1836	2026-02-01 07:34:33.512
1837	1	1	55.1066485	82.95273	2026-02-01 07:28:53.767	MOVE	53.09500122070312	0	0	\N	1837	2026-02-01 07:34:33.512
1838	1	1	55.106695	82.9526254	2026-02-01 07:29:10.757	MOVE	50.27000045776367	0	0	\N	1838	2026-02-01 07:34:33.512
1839	1	1	55.1067562	82.9522255	2026-02-01 07:29:27.785	MOVE	34.17300033569336	0	0	\N	1839	2026-02-01 07:34:33.512
1840	1	1	55.106703	82.9526073	2026-02-01 07:30:01.863	MOVE	50.07699966430664	0	0	\N	1840	2026-02-01 07:34:33.512
1841	1	1	55.1067571	82.9521961	2026-02-01 07:30:18.881	MOVE	33.95000076293945	0	0	\N	1841	2026-02-01 07:34:33.512
1842	1	1	55.1068043	82.9523092	2026-02-01 07:31:09.895	MOVE	12.65999984741211	0	0	\N	1842	2026-02-01 07:34:33.512
1843	1	1	55.106757	82.9523504	2026-02-01 07:31:43.99	MOVE	35.11000061035156	0	0	\N	1843	2026-02-01 07:34:33.512
1844	1	1	55.1067588	82.9521979	2026-02-01 07:32:01.16	MOVE	31.97400093078613	0	0	\N	1844	2026-02-01 07:34:33.512
1845	1	1	55.1065905	82.9529147	2026-02-01 07:32:35.201	MOVE	49.94300079345703	0	0	\N	1845	2026-02-01 07:34:33.512
1846	1	1	55.1067716	82.9522542	2026-02-01 07:32:52.241	MOVE	33.3129997253418	0	0	\N	1846	2026-02-01 07:34:33.512
1847	1	1	55.1065858	82.9528738	2026-02-01 07:33:26.263	MOVE	44.59500122070312	0	0	\N	1847	2026-02-01 07:34:33.512
1848	1	1	55.1067602	82.952248	2026-02-01 07:33:43.301	MOVE	32.57899856567383	0	0	\N	1848	2026-02-01 07:34:33.512
1849	1	1	55.106675	82.9526052	2026-02-01 07:34:36.658	MOVE	38.00799942016602	1.088239550590515	111.7571182250977	\N	1849	2026-02-01 07:46:39.502
1850	1	1	55.1067752	82.9522414	2026-02-01 07:35:05.249	MOVE	30.41799926757812	0	0	\N	1850	2026-02-01 07:46:39.502
1851	1	1	55.106649	82.9527099	2026-02-01 07:35:22.27	MOVE	52.81900024414062	0	0	\N	1851	2026-02-01 07:46:39.502
1852	1	1	55.1067671	82.952258	2026-02-01 07:35:39.228	MOVE	29.87899971008301	0	0	\N	1852	2026-02-01 07:46:39.502
1853	1	1	55.1067439	82.9524368	2026-02-01 07:35:56.248	MOVE	45.21900177001953	0	0	\N	1853	2026-02-01 07:46:39.502
1854	1	1	55.1067768	82.9523407	2026-02-01 07:36:13.233	MOVE	29.6299991607666	0	0	\N	1854	2026-02-01 07:46:39.502
1855	1	1	55.1067579	82.9522063	2026-02-01 07:36:30.256	MOVE	33.87300109863281	0	0	\N	1855	2026-02-01 07:46:39.502
1856	1	1	55.1067959	82.952289	2026-02-01 07:37:38.272	MOVE	13.2810001373291	0	0	\N	1856	2026-02-01 07:46:39.502
1857	1	1	55.1066095	82.9528472	2026-02-01 07:37:55.307	MOVE	45.84099960327148	0	0	\N	1857	2026-02-01 07:46:39.502
1858	1	1	55.1067515	82.9521741	2026-02-01 07:38:12.408	MOVE	34.125	0	0	\N	1858	2026-02-01 07:46:39.502
1859	1	1	55.1067743	82.9523271	2026-02-01 07:38:46.44	MOVE	27.04100036621094	0	0	\N	1859	2026-02-01 07:46:39.502
1860	1	1	55.1067624	82.9521744	2026-02-01 07:39:03.398	MOVE	36.51200103759766	0	0	\N	1860	2026-02-01 07:46:39.502
1861	1	1	55.1066184	82.9528113	2026-02-01 07:39:54.436	MOVE	47.29499816894531	0	0	\N	1861	2026-02-01 07:46:39.502
1862	1	1	55.1067529	82.9521941	2026-02-01 07:40:11.37	MOVE	33.19400024414062	0	0	\N	1862	2026-02-01 07:46:39.502
1863	1	1	55.1066209	82.9527971	2026-02-01 07:40:28.422	MOVE	47.59099960327148	0	0	\N	1863	2026-02-01 07:46:39.502
1864	1	1	55.106753	82.952181	2026-02-01 07:41:02.439	MOVE	33.23699951171875	0	0	\N	1864	2026-02-01 07:46:39.502
1865	1	1	55.1068152	82.9522539	2026-02-01 07:41:19.452	MOVE	22.48200035095215	0	0	\N	1865	2026-02-01 07:46:39.502
1866	1	1	55.1065956	82.9528759	2026-02-01 07:41:36.426	MOVE	46.84500122070312	0	0	\N	1866	2026-02-01 07:46:39.502
1867	1	1	55.1070123	82.9521408	2026-02-01 07:41:52.417	MOVE	64	6.659284114837646	280.2745361328125	\N	1867	2026-02-01 07:46:39.502
1868	1	1	55.1066544	82.9527223	2026-02-01 07:42:10.509	MOVE	54.37200164794922	0	0	\N	1868	2026-02-01 07:46:39.502
1869	1	1	55.1067561	82.9521904	2026-02-01 07:42:27.526	MOVE	32.79700088500977	0	0	\N	1869	2026-02-01 07:46:39.502
1870	1	1	55.1067505	82.9524183	2026-02-01 07:43:01.557	MOVE	43.24700164794922	0	0	\N	1870	2026-02-01 07:46:39.502
1871	1	1	55.106649	82.9528039	2026-02-01 07:43:24.585	MOVE	47.69200134277344	0	0	\N	1871	2026-02-01 07:46:39.502
1872	1	1	55.1067588	82.9522109	2026-02-01 07:43:41.602	MOVE	32.77099990844727	0	0	\N	1872	2026-02-01 07:46:39.502
1873	1	1	55.1067936	82.9538331	2026-02-01 07:43:55.425	MOVE	217.5	0.8399999737739563	274	\N	1873	2026-02-01 07:46:39.502
1874	1	1	55.1067845	82.9522475	2026-02-01 07:44:12.091	MOVE	31.28700065612793	0	0	\N	1874	2026-02-01 07:46:39.502
1875	1	1	55.1066195	82.9529011	2026-02-01 07:44:29.148	MOVE	48.35499954223633	0	0	\N	1875	2026-02-01 07:46:39.502
1876	1	1	55.1067881	82.9523265	2026-02-01 07:44:46.196	MOVE	16.14999961853027	0	0	\N	1876	2026-02-01 07:46:39.502
1877	1	1	55.1001282	82.9776153	2026-02-01 07:45:03.581	MOVE	667.3619995117188	56.56488418579102	296.7438049316406	\N	1877	2026-02-01 07:46:39.502
1878	1	1	55.103462	82.9555272	2026-02-01 07:45:19.424	MOVE	83.5	106.0400009155273	272	\N	1878	2026-02-01 07:46:39.502
1879	1	1	55.1034878	82.9542376	2026-02-01 07:45:20.518	MOVE	199.4980010986328	105.1626663208008	272.0033874511719	\N	1879	2026-02-01 07:46:39.502
1880	1	1	55.1035531	82.9509897	2026-02-01 07:45:22.714	MOVE	432.3619995117188	102.9139938354492	272.0102233886719	\N	1880	2026-02-01 07:46:39.502
1881	1	1	55.1067959	82.9530712	2026-02-01 07:45:39.576	MOVE	36.5	2.599999904632568	146	\N	1881	2026-02-01 07:46:39.502
1882	1	1	55.1071093	82.9602502	2026-02-01 07:46:01.578	MOVE	127	57.06999969482422	82	\N	1882	2026-02-01 07:46:39.502
1883	1	1	55.1070609	82.9515742	2026-02-01 07:46:25.387	MOVE	98.5	11.63000011444092	71	\N	1883	2026-02-01 07:46:39.502
1884	1	1	55.1070979	82.951761	2026-02-01 07:46:27.653	MOVE	121.1589965820312	11.54193210601807	70.88972473144531	\N	1884	2026-02-01 07:46:42.295
1885	1	1	55.1067019	82.9526416	2026-02-01 07:46:49.217	MOVE	50.04700088500977	0	0	\N	1885	2026-02-01 07:46:48.876
1886	1	1	55.1067825	82.9523406	2026-02-01 07:47:06.216	MOVE	28.72900009155273	0	0	\N	1886	2026-02-01 07:47:05.886
1887	1	1	55.1066107	82.9528691	2026-02-01 07:47:23.231	MOVE	49.28799819946289	0	0	\N	1887	2026-02-01 07:47:22.979
1888	1	1	55.1070088	82.9509289	2026-02-01 07:47:39.408	MOVE	190	5.690000057220459	47	\N	1888	2026-02-01 07:47:39.105
1889	1	1	55.1067637	82.9524517	2026-02-01 07:47:59.015	MOVE	48.63600158691406	0	0	\N	1889	2026-02-01 07:47:58.617
1890	1	1	55.1066714	82.9527985	2026-02-01 07:48:16.032	MOVE	50.46500015258789	0	0	\N	1890	2026-02-01 07:48:15.741
1891	1	1	55.1070588	82.9580218	2026-02-01 07:48:24.403	MOVE	244	0	0	\N	1891	2026-02-01 07:48:38.963
1892	1	1	55.1067784	82.9523273	2026-02-01 07:48:52.028	MOVE	24.67900085449219	0	0	\N	1892	2026-02-01 07:53:57.765
1893	1	1	55.1067548	82.9524722	2026-02-01 07:49:09.06	MOVE	47.63299942016602	0	0	\N	1893	2026-02-01 07:53:57.765
1894	1	1	55.106656	82.9527091	2026-02-01 07:49:26.115	MOVE	53.5620002746582	0	0	\N	1894	2026-02-01 07:53:57.765
1895	1	1	55.1067568	82.9521933	2026-02-01 07:49:43.108	MOVE	33.99399948120117	0	0	\N	1895	2026-02-01 07:53:57.765
1896	1	1	55.1066193	82.9528536	2026-02-01 07:51:25.339	MOVE	45.39699935913086	0	0	\N	1896	2026-02-01 07:53:57.765
1897	1	1	55.1067609	82.9522529	2026-02-01 07:51:42.367	MOVE	31.58399963378906	0	0	\N	1897	2026-02-01 07:53:57.765
1898	1	1	55.1067978	82.9521117	2026-02-01 07:53:58.513	MOVE	30.65500068664551	0	0	\N	1898	2026-02-01 07:53:59.03
1899	1	1	55.1067621	82.9521751	2026-02-01 07:54:32.345	MOVE	28.35700035095215	0	0	\N	1899	2026-02-01 07:54:31.892
1900	1	1	55.1076031	82.9563682	2026-02-01 07:54:49.24	MOVE	142.5	0	0	\N	1900	2026-02-01 07:54:48.742
1901	1	1	55.1067549	82.9521839	2026-02-01 07:55:06.185	MOVE	27.5359992980957	0	0	\N	1901	2026-02-01 07:55:05.703
1902	1	1	55.1065768	82.9529132	2026-02-01 07:55:23.098	MOVE	42.25400161743164	0	0	\N	1902	2026-02-01 07:55:22.638
1903	1	1	55.106791	82.9522103	2026-02-01 07:55:40.122	MOVE	20.04100036621094	0	0	\N	1903	2026-02-01 07:55:39.61
1904	1	1	55.1076033	82.9563684	2026-02-01 07:55:57.025	MOVE	149.6000061035156	0	0	\N	1904	2026-02-01 07:55:56.616
1905	1	1	55.1068869	82.9519845	2026-02-01 07:56:13.923	MOVE	20.72100067138672	0	0	\N	1905	2026-02-01 07:56:13.433
1906	1	1	55.1076027	82.95637	2026-02-01 07:56:30.819	MOVE	164.3999938964844	0	0	\N	1906	2026-02-01 07:56:30.307
1907	1	1	55.1067469	82.9525719	2026-02-01 07:56:47.743	MOVE	38.22700119018555	0	0	\N	1907	2026-02-01 07:56:47.281
1908	1	1	55.1067669	82.9521646	2026-02-01 07:57:04.708	MOVE	28.76499938964844	0	0	\N	1908	2026-02-01 07:57:04.207
1909	1	1	55.1067632	82.9522694	2026-02-01 07:57:21.626	MOVE	24.4379997253418	0	0	\N	1909	2026-02-01 07:57:21.13
1910	1	1	55.1067659	82.9521511	2026-02-01 07:57:38.543	MOVE	30.60600090026855	0	0	\N	1910	2026-02-01 07:57:38.113
1911	1	1	55.1068705	82.9519996	2026-02-01 07:57:55.45	MOVE	22.50200080871582	0	0	\N	1911	2026-02-01 07:57:55.017
1912	1	1	55.1068194	82.9520921	2026-02-01 07:57:58.848	MOVE	26.3120002746582	0.7223883867263794	134.0172271728516	\N	1912	2026-02-01 07:58:09.942
1913	1	1	55.1067599	82.9522142	2026-02-01 07:58:26.115	MOVE	27.36700057983398	0	0	\N	1913	2026-02-01 07:58:25.595
1914	1	1	55.1067391	82.9524876	2026-02-01 07:58:43.026	MOVE	39.77199935913086	0	0	\N	1914	2026-02-01 07:58:42.573
1915	1	1	55.1068736	82.9520021	2026-02-01 07:58:59.943	MOVE	22.4330005645752	0	0	\N	1915	2026-02-01 07:58:59.467
1916	1	1	55.1067877	82.9521629	2026-02-01 07:59:50.786	MOVE	30.9379997253418	0	0	\N	1916	2026-02-01 07:59:50.344
1917	1	1	55.1068632	82.9520107	2026-02-01 08:00:41.617	MOVE	22.50099945068359	0	0	\N	1917	2026-02-01 08:00:41.19
1918	1	1	55.1068083	82.9520794	2026-02-01 08:01:15.436	MOVE	31.25300025939941	0	0	\N	1918	2026-02-01 08:01:14.944
1919	1	1	55.1066236	82.9528653	2026-02-01 08:01:32.355	MOVE	37.11899948120117	0	0	\N	1919	2026-02-01 08:01:31.838
1920	1	1	55.1068202	82.9523986	2026-02-01 08:01:49.424	MOVE	45.69400024414062	0	0	\N	1920	2026-02-01 08:01:48.931
1921	1	1	55.1067344	82.9526126	2026-02-01 08:02:06.339	MOVE	40.00099945068359	0	0	\N	1921	2026-02-01 08:02:05.854
1922	1	1	55.1068035	82.9521116	2026-02-01 08:02:23.285	MOVE	30.94899940490723	0	0	\N	1922	2026-02-01 08:02:22.829
\.


--
-- Data for Name: SpecialPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SpecialPrice" (id, guid, "productId", "counterpartyId", "agreementId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockBalance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StockBalance" (id, "productId", "warehouseId", quantity, reserved, "updatedAt", "sourceUpdatedAt", "lastSyncedAt") FROM stdin;
\.


--
-- Data for Name: SupplierProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SupplierProfile" (id, "userId", "addressId", phone, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SyncRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRun" (id, "requestId", entity, direction, status, "totalCount", "successCount", "errorCount", "startedAt", "finishedAt", notes, meta) FROM stdin;
\.


--
-- Data for Name: SyncRunItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRunItem" (id, "runId", key, status, error, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: Unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Unit" (id, guid, name, code, symbol, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, "passwordHash", "isActive", "roleId", "createdAt", "updatedAt", "avatarUrl", "deletedAt", phone, "profileStatus", "currentProfileType", "firstName", "lastName", "middleName") FROM stdin;
1	extectick@yandex.ru	$2b$10$qtw/KkpQmdPjfU.CDnPVgeM9EoS9QXsl/pidSdkZARfNxirNZazF6	t	4	2026-01-27 10:13:43.621	2026-01-27 10:56:02.766	\N	\N	\N	ACTIVE	EMPLOYEE	Алексей	Борховецкий	Евгеньевич
\.


--
-- Data for Name: UserRoute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserRoute" (id, "userId", status, "startedAt", "endedAt", "createdAt", "updatedAt") FROM stdin;
1	1	ACTIVE	2026-01-31 18:30:18.777	\N	2026-01-31 18:32:14.913	2026-01-31 18:32:14.913
\.


--
-- Data for Name: Warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warehouse" (id, guid, name, code, "isActive", "isDefault", "isPickup", address, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _EmployeeDepartmentRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_EmployeeDepartmentRoles" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
955730ab-6db5-4229-95c3-7cb19d4d2a3d	78141557caab0d9539a7057374e6c88112968e8c2575d37c48b188b5ddeda659	2026-01-27 07:50:21.132678+00	20250712083400_init	\N	\N	2026-01-27 07:50:20.222764+00	1
464f8b09-2c00-4c8b-8068-2d338245ad79	ead7416b7215d43ef8974f5eb0d77c0af5b1fccc33a7bb94beb1d0031d7515af	2026-01-27 07:50:21.476899+00	20250713095849_add_parent_role_id_to_role	\N	\N	2026-01-27 07:50:21.146523+00	1
ea66c9bf-a8b4-4fb9-8cca-37016d79354f	6e1f44737c7ec8af4de6bc2e68cccce4031411481ffa3885e4f1eaa6f77c683e	2026-01-27 07:50:21.916619+00	20250715070749_update_schema	\N	\N	2026-01-27 07:50:21.502113+00	1
0bb387b2-fa2e-4d22-bed6-60240a608011	100a6ec3d37dd55753a9e7fb731f43a360b3c49ab82745339538b3c2292edbc4	2026-01-27 07:50:21.991932+00	20250715072640_update_schema	\N	\N	2026-01-27 07:50:21.927859+00	1
34d5152b-8bd2-4118-b59a-14f70ee9b818	0564d26e8de4d7877c41cb4985c5efa40bbec9623811b40715a58edce90db1e7	2026-01-27 07:50:22.096673+00	20250716073009_add_user_name_fields	\N	\N	2026-01-27 07:50:22.016109+00	1
b729110b-475f-4571-8409-b49a576a905a	91d5a16ee8795b785fb4412eec6dba91b329a165876b879bae2b10db7b194b5e	2026-01-27 07:50:22.456581+00	20250729130102_added_qr_codes	\N	\N	2026-01-27 07:50:22.125497+00	1
8c664302-b47c-4c67-bae7-9bf01c598194	22899d4df0ab0576dfbf396644d304f77a5b206c1925ac1573cff3f5223f3c07	2026-01-27 07:50:22.519534+00	20250729151622_add_qr_type	\N	\N	2026-01-27 07:50:22.469923+00	1
e7b1ca81-47ca-4e2c-90e9-4c87448d6feb	c8a85dfdfb42127a014456b6aba5cbabda061a00353a2ba18766e3348ca98d4d	2026-01-27 07:50:22.603091+00	20250729154453_add_qr_type	\N	\N	2026-01-27 07:50:22.543505+00	1
adb14e01-2771-4001-939d-4bb87850fafb	cd5fdb5da5c2b999d69ba1887acb6dffb302c345cbb31db60abbdb77eea028fb	2026-01-27 07:50:22.994772+00	20250821153051_add_appeals	\N	\N	2026-01-27 07:50:22.616369+00	1
2b049c31-94e3-47f7-8e20-f4f984e31a1b	77950141ad20bbf408a1922deba80dba980850153d2e072bbe18c52738b07b2e	2026-01-27 07:50:23.183081+00	20251115185222_test1	\N	\N	2026-01-27 07:50:23.00605+00	1
8711074f-2787-4ac7-b1e5-5fdc34c414d3	9d8aa51e399151371c0402eda209794c35c68edefb5c37f6aab43474fab51917	2026-01-27 07:50:23.564439+00	20251222130000_add_app_updates	\N	\N	2026-01-27 07:50:23.196153+00	1
\.


--
-- Name: Address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Address_id_seq"', 1, false);


--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdateEvent_id_seq"', 12, true);


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdate_id_seq"', 5, true);


--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAssignee_id_seq"', 1, false);


--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAttachment_id_seq"', 1, false);


--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessageRead_id_seq"', 1, false);


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessage_id_seq"', 1, false);


--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealStatusHistory_id_seq"', 1, false);


--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealWatcher_id_seq"', 1, false);


--
-- Name: Appeal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Appeal_id_seq"', 1, false);


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 7, true);


--
-- Name: ClientProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ClientProfile_id_seq"', 1, false);


--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DepartmentRole_id_seq"', 1, false);


--
-- Name: Department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Department_id_seq"', 4, true);


--
-- Name: DeviceToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DeviceToken_id_seq"', 1, false);


--
-- Name: EmailVerification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailVerification_id_seq"', 1, true);


--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmployeeProfile_id_seq"', 1, true);


--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoginAttempt_id_seq"', 7, true);


--
-- Name: PasswordReset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordReset_id_seq"', 1, false);


--
-- Name: Permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Permission_id_seq"', 25, true);


--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."QRAnalytic_id_seq"', 1, false);


--
-- Name: RefreshToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RefreshToken_id_seq"', 32, true);


--
-- Name: Role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Role_id_seq"', 4, true);


--
-- Name: RoutePoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RoutePoint_id_seq"', 1951, true);


--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SupplierProfile_id_seq"', 1, false);


--
-- Name: UserRoute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserRoute_id_seq"', 1, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdateEvent AppUpdateEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdate AppUpdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate"
    ADD CONSTRAINT "AppUpdate_pkey" PRIMARY KEY (id);


--
-- Name: AppealAssignee AppealAssignee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_pkey" PRIMARY KEY (id);


--
-- Name: AppealAttachment AppealAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessageRead AppealMessageRead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessage AppealMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_pkey" PRIMARY KEY (id);


--
-- Name: AppealStatusHistory AppealStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: AppealWatcher AppealWatcher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_pkey" PRIMARY KEY (id);


--
-- Name: Appeal Appeal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ClientAgreement ClientAgreement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_pkey" PRIMARY KEY (id);


--
-- Name: ClientContract ClientContract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: Counterparty Counterparty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Counterparty"
    ADD CONSTRAINT "Counterparty_pkey" PRIMARY KEY (id);


--
-- Name: DeliveryAddress DeliveryAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_pkey" PRIMARY KEY (id);


--
-- Name: DepartmentRole DepartmentRole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_pkey" PRIMARY KEY (id);


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY (id);


--
-- Name: DeviceToken DeviceToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_pkey" PRIMARY KEY (id);


--
-- Name: EmailVerification EmailVerification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeProfile EmployeeProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_pkey" PRIMARY KEY (id);


--
-- Name: LoginAttempt LoginAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PriceType PriceType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceType"
    ADD CONSTRAINT "PriceType_pkey" PRIMARY KEY (id);


--
-- Name: ProductGroup ProductGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_pkey" PRIMARY KEY (id);


--
-- Name: ProductPackage ProductPackage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_pkey" PRIMARY KEY (id);


--
-- Name: ProductPrice ProductPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: QRAnalytic QRAnalytic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_pkey" PRIMARY KEY (id);


--
-- Name: QRList QRList_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: RolePermissions RolePermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_pkey" PRIMARY KEY ("roleId", "permissionId");


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: RoutePoint RoutePoint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_pkey" PRIMARY KEY (id);


--
-- Name: SpecialPrice SpecialPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_pkey" PRIMARY KEY (id);


--
-- Name: StockBalance StockBalance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_pkey" PRIMARY KEY (id);


--
-- Name: SupplierProfile SupplierProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_pkey" PRIMARY KEY (id);


--
-- Name: SyncRunItem SyncRunItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_pkey" PRIMARY KEY (id);


--
-- Name: SyncRun SyncRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRun"
    ADD CONSTRAINT "SyncRun_pkey" PRIMARY KEY (id);


--
-- Name: Unit Unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unit"
    ADD CONSTRAINT "Unit_pkey" PRIMARY KEY (id);


--
-- Name: UserRoute UserRoute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY (id);


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AppUpdateEvent_deviceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_deviceId_idx" ON public."AppUpdateEvent" USING btree ("deviceId");


--
-- Name: AppUpdateEvent_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_platform_channel_versionCode_idx" ON public."AppUpdateEvent" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdateEvent_updateId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_updateId_idx" ON public."AppUpdateEvent" USING btree ("updateId");


--
-- Name: AppUpdate_platform_channel_minSupportedVersionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_minSupportedVersionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "minSupportedVersionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_versionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppUpdate_platform_channel_versionCode_key" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppealAssignee_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealAssignee_appealId_userId_key" ON public."AppealAssignee" USING btree ("appealId", "userId");


--
-- Name: AppealMessageRead_messageId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealMessageRead_messageId_userId_key" ON public."AppealMessageRead" USING btree ("messageId", "userId");


--
-- Name: AppealWatcher_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealWatcher_appealId_userId_key" ON public."AppealWatcher" USING btree ("appealId", "userId");


--
-- Name: Appeal_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Appeal_number_key" ON public."Appeal" USING btree (number);


--
-- Name: ClientAgreement_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_contractId_idx" ON public."ClientAgreement" USING btree ("contractId");


--
-- Name: ClientAgreement_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_counterpartyId_idx" ON public."ClientAgreement" USING btree ("counterpartyId");


--
-- Name: ClientAgreement_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientAgreement_guid_key" ON public."ClientAgreement" USING btree (guid);


--
-- Name: ClientAgreement_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_isActive_idx" ON public."ClientAgreement" USING btree ("isActive");


--
-- Name: ClientAgreement_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_priceTypeId_idx" ON public."ClientAgreement" USING btree ("priceTypeId");


--
-- Name: ClientAgreement_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_sourceUpdatedAt_idx" ON public."ClientAgreement" USING btree ("sourceUpdatedAt");


--
-- Name: ClientAgreement_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_warehouseId_idx" ON public."ClientAgreement" USING btree ("warehouseId");


--
-- Name: ClientContract_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_counterpartyId_idx" ON public."ClientContract" USING btree ("counterpartyId");


--
-- Name: ClientContract_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientContract_guid_key" ON public."ClientContract" USING btree (guid);


--
-- Name: ClientContract_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_isActive_idx" ON public."ClientContract" USING btree ("isActive");


--
-- Name: ClientContract_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_sourceUpdatedAt_idx" ON public."ClientContract" USING btree ("sourceUpdatedAt");


--
-- Name: ClientProfile_activeAgreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeAgreementId_idx" ON public."ClientProfile" USING btree ("activeAgreementId");


--
-- Name: ClientProfile_activeContractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeContractId_idx" ON public."ClientProfile" USING btree ("activeContractId");


--
-- Name: ClientProfile_activeDeliveryAddressId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeDeliveryAddressId_idx" ON public."ClientProfile" USING btree ("activeDeliveryAddressId");


--
-- Name: ClientProfile_activePriceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activePriceTypeId_idx" ON public."ClientProfile" USING btree ("activePriceTypeId");


--
-- Name: ClientProfile_activeWarehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeWarehouseId_idx" ON public."ClientProfile" USING btree ("activeWarehouseId");


--
-- Name: ClientProfile_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_counterpartyId_idx" ON public."ClientProfile" USING btree ("counterpartyId");


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: Counterparty_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Counterparty_guid_key" ON public."Counterparty" USING btree (guid);


--
-- Name: Counterparty_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_isActive_idx" ON public."Counterparty" USING btree ("isActive");


--
-- Name: Counterparty_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_sourceUpdatedAt_idx" ON public."Counterparty" USING btree ("sourceUpdatedAt");


--
-- Name: DeliveryAddress_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_counterpartyId_idx" ON public."DeliveryAddress" USING btree ("counterpartyId");


--
-- Name: DeliveryAddress_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeliveryAddress_guid_key" ON public."DeliveryAddress" USING btree (guid);


--
-- Name: DeliveryAddress_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_isActive_idx" ON public."DeliveryAddress" USING btree ("isActive");


--
-- Name: DeliveryAddress_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_sourceUpdatedAt_idx" ON public."DeliveryAddress" USING btree ("sourceUpdatedAt");


--
-- Name: DepartmentRole_userId_roleId_departmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DepartmentRole_userId_roleId_departmentId_key" ON public."DepartmentRole" USING btree ("userId", "roleId", "departmentId");


--
-- Name: Department_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Department_name_key" ON public."Department" USING btree (name);


--
-- Name: DeviceToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeviceToken_token_key" ON public."DeviceToken" USING btree (token);


--
-- Name: EmployeeProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmployeeProfile_userId_key" ON public."EmployeeProfile" USING btree ("userId");


--
-- Name: OrderItem_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_orderId_idx" ON public."OrderItem" USING btree ("orderId");


--
-- Name: OrderItem_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_productId_idx" ON public."OrderItem" USING btree ("productId");


--
-- Name: OrderItem_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_sourceUpdatedAt_idx" ON public."OrderItem" USING btree ("sourceUpdatedAt");


--
-- Name: Order_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_agreementId_idx" ON public."Order" USING btree ("agreementId");


--
-- Name: Order_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_contractId_idx" ON public."Order" USING btree ("contractId");


--
-- Name: Order_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_counterpartyId_idx" ON public."Order" USING btree ("counterpartyId");


--
-- Name: Order_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_guid_key" ON public."Order" USING btree (guid);


--
-- Name: Order_queuedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_queuedAt_idx" ON public."Order" USING btree ("queuedAt");


--
-- Name: Order_sentTo1cAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sentTo1cAt_idx" ON public."Order" USING btree ("sentTo1cAt");


--
-- Name: Order_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sourceUpdatedAt_idx" ON public."Order" USING btree ("sourceUpdatedAt");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: Order_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_warehouseId_idx" ON public."Order" USING btree ("warehouseId");


--
-- Name: Permission_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Permission_name_key" ON public."Permission" USING btree (name);


--
-- Name: PriceType_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PriceType_guid_key" ON public."PriceType" USING btree (guid);


--
-- Name: PriceType_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_isActive_idx" ON public."PriceType" USING btree ("isActive");


--
-- Name: PriceType_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_sourceUpdatedAt_idx" ON public."PriceType" USING btree ("sourceUpdatedAt");


--
-- Name: ProductGroup_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductGroup_guid_key" ON public."ProductGroup" USING btree (guid);


--
-- Name: ProductGroup_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_isActive_idx" ON public."ProductGroup" USING btree ("isActive");


--
-- Name: ProductGroup_parentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_parentId_idx" ON public."ProductGroup" USING btree ("parentId");


--
-- Name: ProductGroup_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_sourceUpdatedAt_idx" ON public."ProductGroup" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPackage_barcode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_barcode_idx" ON public."ProductPackage" USING btree (barcode);


--
-- Name: ProductPackage_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPackage_guid_key" ON public."ProductPackage" USING btree (guid);


--
-- Name: ProductPackage_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_productId_idx" ON public."ProductPackage" USING btree ("productId");


--
-- Name: ProductPackage_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_sourceUpdatedAt_idx" ON public."ProductPackage" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_guid_key" ON public."ProductPrice" USING btree (guid);


--
-- Name: ProductPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_isActive_idx" ON public."ProductPrice" USING btree ("isActive");


--
-- Name: ProductPrice_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_priceTypeId_idx" ON public."ProductPrice" USING btree ("priceTypeId");


--
-- Name: ProductPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_productId_idx" ON public."ProductPrice" USING btree ("productId");


--
-- Name: ProductPrice_productId_priceTypeId_startDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_productId_priceTypeId_startDate_key" ON public."ProductPrice" USING btree ("productId", "priceTypeId", "startDate");


--
-- Name: ProductPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_sourceUpdatedAt_idx" ON public."ProductPrice" USING btree ("sourceUpdatedAt");


--
-- Name: Product_article_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_article_idx" ON public."Product" USING btree (article);


--
-- Name: Product_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_groupId_idx" ON public."Product" USING btree ("groupId");


--
-- Name: Product_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Product_guid_key" ON public."Product" USING btree (guid);


--
-- Name: Product_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_isActive_idx" ON public."Product" USING btree ("isActive");


--
-- Name: Product_sku_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sku_idx" ON public."Product" USING btree (sku);


--
-- Name: Product_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sourceUpdatedAt_idx" ON public."Product" USING btree ("sourceUpdatedAt");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: RoutePoint_routeId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_routeId_recordedAt_idx" ON public."RoutePoint" USING btree ("routeId", "recordedAt");


--
-- Name: RoutePoint_userId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_userId_recordedAt_idx" ON public."RoutePoint" USING btree ("userId", "recordedAt");


--
-- Name: SpecialPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_guid_key" ON public."SpecialPrice" USING btree (guid);


--
-- Name: SpecialPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_isActive_idx" ON public."SpecialPrice" USING btree ("isActive");


--
-- Name: SpecialPrice_productId_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_agreementId_idx" ON public."SpecialPrice" USING btree ("productId", "agreementId");


--
-- Name: SpecialPrice_productId_counterpartyId_agreementId_priceType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_productId_counterpartyId_agreementId_priceType_key" ON public."SpecialPrice" USING btree ("productId", "counterpartyId", "agreementId", "priceTypeId", "startDate");


--
-- Name: SpecialPrice_productId_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_counterpartyId_idx" ON public."SpecialPrice" USING btree ("productId", "counterpartyId");


--
-- Name: SpecialPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_idx" ON public."SpecialPrice" USING btree ("productId");


--
-- Name: SpecialPrice_productId_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_priceTypeId_idx" ON public."SpecialPrice" USING btree ("productId", "priceTypeId");


--
-- Name: SpecialPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_sourceUpdatedAt_idx" ON public."SpecialPrice" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_productId_warehouseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StockBalance_productId_warehouseId_key" ON public."StockBalance" USING btree ("productId", "warehouseId");


--
-- Name: StockBalance_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_sourceUpdatedAt_idx" ON public."StockBalance" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_updatedAt_idx" ON public."StockBalance" USING btree ("updatedAt");


--
-- Name: StockBalance_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_warehouseId_idx" ON public."StockBalance" USING btree ("warehouseId");


--
-- Name: SupplierProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SupplierProfile_userId_key" ON public."SupplierProfile" USING btree ("userId");


--
-- Name: SyncRunItem_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_key_idx" ON public."SyncRunItem" USING btree (key);


--
-- Name: SyncRunItem_runId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_runId_idx" ON public."SyncRunItem" USING btree ("runId");


--
-- Name: SyncRunItem_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_status_idx" ON public."SyncRunItem" USING btree (status);


--
-- Name: SyncRun_entity_direction_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_entity_direction_startedAt_idx" ON public."SyncRun" USING btree (entity, direction, "startedAt");


--
-- Name: SyncRun_requestId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SyncRun_requestId_key" ON public."SyncRun" USING btree ("requestId");


--
-- Name: SyncRun_status_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_status_startedAt_idx" ON public."SyncRun" USING btree (status, "startedAt");


--
-- Name: Unit_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Unit_guid_key" ON public."Unit" USING btree (guid);


--
-- Name: Unit_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Unit_sourceUpdatedAt_idx" ON public."Unit" USING btree ("sourceUpdatedAt");


--
-- Name: UserRoute_userId_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserRoute_userId_startedAt_idx" ON public."UserRoute" USING btree ("userId", "startedAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Warehouse_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Warehouse_guid_key" ON public."Warehouse" USING btree (guid);


--
-- Name: Warehouse_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isActive_idx" ON public."Warehouse" USING btree ("isActive");


--
-- Name: Warehouse_isDefault_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isDefault_idx" ON public."Warehouse" USING btree ("isDefault");


--
-- Name: Warehouse_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_sourceUpdatedAt_idx" ON public."Warehouse" USING btree ("sourceUpdatedAt");


--
-- Name: _EmployeeDepartmentRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_EmployeeDepartmentRoles_B_index" ON public."_EmployeeDepartmentRoles" USING btree ("B");


--
-- Name: AppUpdateEvent AppUpdateEvent_updateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_updateId_fkey" FOREIGN KEY ("updateId") REFERENCES public."AppUpdate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppUpdateEvent AppUpdateEvent_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppealAssignee AppealAssignee_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAssignee AppealAssignee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAttachment AppealAttachment_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessageRead AppealMessageRead_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessageRead AppealMessageRead_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessage AppealMessage_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessage AppealMessage_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_changedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_changedById_fkey" FOREIGN KEY ("changedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_fromDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_fromDepartmentId_fkey" FOREIGN KEY ("fromDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appeal Appeal_toDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_toDepartmentId_fkey" FOREIGN KEY ("toDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientContract ClientContract_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientProfile ClientProfile_activeAgreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeAgreementId_fkey" FOREIGN KEY ("activeAgreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeContractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeContractId_fkey" FOREIGN KEY ("activeContractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeDeliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeDeliveryAddressId_fkey" FOREIGN KEY ("activeDeliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activePriceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activePriceTypeId_fkey" FOREIGN KEY ("activePriceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeWarehouseId_fkey" FOREIGN KEY ("activeWarehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeliveryAddress DeliveryAddress_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeviceToken DeviceToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailVerification EmailVerification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeProfile EmployeeProfile_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmployeeProfile EmployeeProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LoginAttempt LoginAttempt_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_packageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES public."ProductPackage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_deliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_deliveryAddressId_fkey" FOREIGN KEY ("deliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductGroup ProductGroup_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPackage ProductPackage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPackage ProductPackage_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPrice ProductPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPrice ProductPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_baseUnitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_baseUnitId_fkey" FOREIGN KEY ("baseUnitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QRAnalytic QRAnalytic_qrListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_qrListId_fkey" FOREIGN KEY ("qrListId") REFERENCES public."QRList"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QRList QRList_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Role Role_parentRoleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_parentRoleId_fkey" FOREIGN KEY ("parentRoleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RoutePoint RoutePoint_routeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_routeId_fkey" FOREIGN KEY ("routeId") REFERENCES public."UserRoute"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RoutePoint RoutePoint_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SpecialPrice SpecialPrice_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SupplierProfile SupplierProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SupplierProfile SupplierProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SyncRunItem SyncRunItem_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."SyncRun"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRoute UserRoute_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."DepartmentRole"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."EmployeeProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uxaaTUx5JE6ybY1ZZoN1tlMLBsPdvKWvCPUWISaC3wZ9SkJr8zqVK9xHfMf04dD

