--
-- PostgreSQL database dump
--

\restrict 5QgOfEMcWP0q1OVBrwr6AdTqOba8NDluI8Tg6wVmxygfeHrvUsg0NSAxNrZJoPk

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActionType" AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'LOGIN',
    'LOGOUT',
    'PASSWORD_RESET',
    'EMAIL_VERIFICATION',
    'OTHER'
);


ALTER TYPE public."ActionType" OWNER TO postgres;

--
-- Name: AppPlatform; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppPlatform" AS ENUM (
    'ANDROID',
    'IOS'
);


ALTER TYPE public."AppPlatform" OWNER TO postgres;

--
-- Name: AppUpdateEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppUpdateEventType" AS ENUM (
    'CHECK',
    'PROMPT_SHOWN',
    'UPDATE_CLICK',
    'DISMISS'
);


ALTER TYPE public."AppUpdateEventType" OWNER TO postgres;

--
-- Name: AppealPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."AppealPriority" OWNER TO postgres;

--
-- Name: AppealStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AppealStatus" AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'COMPLETED',
    'DECLINED',
    'RESOLVED'
);


ALTER TYPE public."AppealStatus" OWNER TO postgres;

--
-- Name: AttachmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AttachmentType" AS ENUM (
    'IMAGE',
    'AUDIO',
    'FILE'
);


ALTER TYPE public."AttachmentType" OWNER TO postgres;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'DRAFT',
    'QUEUED',
    'SENT_TO_1C',
    'CONFIRMED',
    'PARTIAL',
    'REJECTED',
    'CANCELLED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- Name: ProfileStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'BLOCKED'
);


ALTER TYPE public."ProfileStatus" OWNER TO postgres;

--
-- Name: ProfileType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProfileType" AS ENUM (
    'CLIENT',
    'SUPPLIER',
    'EMPLOYEE'
);


ALTER TYPE public."ProfileType" OWNER TO postgres;

--
-- Name: QRStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'DELETED'
);


ALTER TYPE public."QRStatus" OWNER TO postgres;

--
-- Name: QRType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QRType" AS ENUM (
    'PHONE',
    'LINK',
    'EMAIL',
    'TEXT',
    'WHATSAPP',
    'CONTACT',
    'TELEGRAM'
);


ALTER TYPE public."QRType" OWNER TO postgres;

--
-- Name: RouteEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteEventType" AS ENUM (
    'MOVE',
    'STOP'
);


ALTER TYPE public."RouteEventType" OWNER TO postgres;

--
-- Name: RouteStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RouteStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."RouteStatus" OWNER TO postgres;

--
-- Name: SyncDirection; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncDirection" AS ENUM (
    'IMPORT',
    'EXPORT'
);


ALTER TYPE public."SyncDirection" OWNER TO postgres;

--
-- Name: SyncEntityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncEntityType" AS ENUM (
    'NOMENCLATURE',
    'WAREHOUSES',
    'COUNTERPARTIES',
    'AGREEMENTS',
    'PRODUCT_PRICES',
    'SPECIAL_PRICES',
    'STOCK',
    'ORDERS_EXPORT',
    'ORDERS_STATUS'
);


ALTER TYPE public."SyncEntityType" OWNER TO postgres;

--
-- Name: SyncItemStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncItemStatus" AS ENUM (
    'OK',
    'ERROR',
    'SKIPPED'
);


ALTER TYPE public."SyncItemStatus" OWNER TO postgres;

--
-- Name: SyncStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SyncStatus" AS ENUM (
    'STARTED',
    'COMPLETED',
    'PARTIAL',
    'FAILED'
);


ALTER TYPE public."SyncStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    id integer NOT NULL,
    street text NOT NULL,
    city text NOT NULL,
    state text,
    "postalCode" text,
    country text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Address_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Address_id_seq" OWNER TO postgres;

--
-- Name: Address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Address_id_seq" OWNED BY public."Address".id;


--
-- Name: AppUpdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdate" (
    id integer NOT NULL,
    platform public."AppPlatform" NOT NULL,
    channel text DEFAULT 'prod'::text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text NOT NULL,
    "minSupportedVersionCode" integer NOT NULL,
    "isMandatory" boolean DEFAULT false NOT NULL,
    "rolloutPercent" integer DEFAULT 100 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "releaseNotes" text,
    "storeUrl" text,
    "apkKey" text,
    "fileSize" integer,
    checksum text,
    "checksumMd5" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AppUpdate" OWNER TO postgres;

--
-- Name: AppUpdateEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppUpdateEvent" (
    id integer NOT NULL,
    "updateId" integer,
    platform public."AppPlatform" NOT NULL,
    channel text NOT NULL,
    "versionCode" integer NOT NULL,
    "versionName" text,
    "deviceId" text,
    "eventType" public."AppUpdateEventType" NOT NULL,
    "userId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppUpdateEvent" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdateEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNER TO postgres;

--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdateEvent_id_seq" OWNED BY public."AppUpdateEvent".id;


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppUpdate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppUpdate_id_seq" OWNER TO postgres;

--
-- Name: AppUpdate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppUpdate_id_seq" OWNED BY public."AppUpdate".id;


--
-- Name: Appeal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appeal" (
    id integer NOT NULL,
    number integer NOT NULL,
    "fromDepartmentId" integer,
    "toDepartmentId" integer NOT NULL,
    "createdById" integer NOT NULL,
    status public."AppealStatus" DEFAULT 'OPEN'::public."AppealStatus" NOT NULL,
    priority public."AppealPriority" DEFAULT 'MEDIUM'::public."AppealPriority" NOT NULL,
    deadline timestamp(3) without time zone,
    title text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Appeal" OWNER TO postgres;

--
-- Name: AppealAssignee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAssignee" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealAssignee" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAssignee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAssignee_id_seq" OWNER TO postgres;

--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAssignee_id_seq" OWNED BY public."AppealAssignee".id;


--
-- Name: AppealAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealAttachment" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "fileUrl" text NOT NULL,
    "fileName" text NOT NULL,
    "fileType" public."AttachmentType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealAttachment" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealAttachment_id_seq" OWNER TO postgres;

--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealAttachment_id_seq" OWNED BY public."AppealAttachment".id;


--
-- Name: AppealMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessage" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "senderId" integer NOT NULL,
    text text,
    "editedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessage" OWNER TO postgres;

--
-- Name: AppealMessageRead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealMessageRead" (
    id integer NOT NULL,
    "messageId" integer NOT NULL,
    "userId" integer NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealMessageRead" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessageRead_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNER TO postgres;

--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessageRead_id_seq" OWNED BY public."AppealMessageRead".id;


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealMessage_id_seq" OWNER TO postgres;

--
-- Name: AppealMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealMessage_id_seq" OWNED BY public."AppealMessage".id;


--
-- Name: AppealStatusHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealStatusHistory" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "oldStatus" public."AppealStatus" NOT NULL,
    "newStatus" public."AppealStatus" NOT NULL,
    "changedById" integer NOT NULL,
    "changedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AppealStatusHistory" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealStatusHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNER TO postgres;

--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealStatusHistory_id_seq" OWNED BY public."AppealStatusHistory".id;


--
-- Name: AppealWatcher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppealWatcher" (
    id integer NOT NULL,
    "appealId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."AppealWatcher" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppealWatcher_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AppealWatcher_id_seq" OWNER TO postgres;

--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppealWatcher_id_seq" OWNED BY public."AppealWatcher".id;


--
-- Name: Appeal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Appeal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Appeal_id_seq" OWNER TO postgres;

--
-- Name: Appeal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Appeal_id_seq" OWNED BY public."Appeal".id;


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id integer NOT NULL,
    "userId" integer,
    "targetType" text,
    "targetId" integer,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details text,
    action public."ActionType" NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AuditLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AuditLog_id_seq" OWNER TO postgres;

--
-- Name: AuditLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AuditLog_id_seq" OWNED BY public."AuditLog".id;


--
-- Name: ClientAgreement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientAgreement" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "counterpartyId" text,
    "contractId" text,
    "priceTypeId" text,
    "warehouseId" text,
    currency text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientAgreement" OWNER TO postgres;

--
-- Name: ClientContract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientContract" (
    id text NOT NULL,
    guid text NOT NULL,
    "counterpartyId" text NOT NULL,
    number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "validFrom" timestamp(3) without time zone,
    "validTo" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ClientContract" OWNER TO postgres;

--
-- Name: ClientProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClientProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "activeAgreementId" text,
    "activeContractId" text,
    "activeDeliveryAddressId" text,
    "activePriceTypeId" text,
    "activeWarehouseId" text,
    "counterpartyId" text
);


ALTER TABLE public."ClientProfile" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ClientProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ClientProfile_id_seq" OWNER TO postgres;

--
-- Name: ClientProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ClientProfile_id_seq" OWNED BY public."ClientProfile".id;


--
-- Name: Counterparty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Counterparty" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    "fullName" text,
    inn text,
    kpp text,
    phone text,
    email text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Counterparty" OWNER TO postgres;

--
-- Name: DeliveryAddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeliveryAddress" (
    id text NOT NULL,
    guid text,
    "counterpartyId" text NOT NULL,
    name text,
    "fullAddress" text NOT NULL,
    city text,
    street text,
    house text,
    building text,
    apartment text,
    postcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DeliveryAddress" OWNER TO postgres;

--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: DepartmentRole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DepartmentRole" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "roleId" integer NOT NULL,
    "departmentId" integer NOT NULL
);


ALTER TABLE public."DepartmentRole" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DepartmentRole_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DepartmentRole_id_seq" OWNER TO postgres;

--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DepartmentRole_id_seq" OWNED BY public."DepartmentRole".id;


--
-- Name: Department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Department_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Department_id_seq" OWNER TO postgres;

--
-- Name: Department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Department_id_seq" OWNED BY public."Department".id;


--
-- Name: DeviceToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DeviceToken" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    platform text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DeviceToken" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DeviceToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DeviceToken_id_seq" OWNER TO postgres;

--
-- Name: DeviceToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DeviceToken_id_seq" OWNED BY public."DeviceToken".id;


--
-- Name: EmailVerification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailVerification" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "attemptsCount" integer DEFAULT 0 NOT NULL,
    "lastSentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."EmailVerification" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailVerification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailVerification_id_seq" OWNER TO postgres;

--
-- Name: EmailVerification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailVerification_id_seq" OWNED BY public."EmailVerification".id;


--
-- Name: EmployeeProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmployeeProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "departmentId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmployeeProfile" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmployeeProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNER TO postgres;

--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmployeeProfile_id_seq" OWNED BY public."EmployeeProfile".id;


--
-- Name: LoginAttempt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoginAttempt" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    success boolean NOT NULL,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginAttempt" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoginAttempt_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoginAttempt_id_seq" OWNER TO postgres;

--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoginAttempt_id_seq" OWNED BY public."LoginAttempt".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    guid text,
    number1c text,
    date1c timestamp(3) without time zone,
    "counterpartyId" text NOT NULL,
    "agreementId" text,
    "contractId" text,
    "warehouseId" text,
    "deliveryAddressId" text,
    status public."OrderStatus" DEFAULT 'DRAFT'::public."OrderStatus" NOT NULL,
    comment text,
    "deliveryDate" timestamp(3) without time zone,
    "totalAmount" numeric(18,2),
    currency text,
    "queuedAt" timestamp(3) without time zone,
    "sentTo1cAt" timestamp(3) without time zone,
    "lastStatusSyncAt" timestamp(3) without time zone,
    "exportAttempts" integer DEFAULT 0 NOT NULL,
    "lastExportError" text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    "packageId" text,
    "unitId" text,
    quantity numeric(18,3) NOT NULL,
    "quantityBase" numeric(18,3),
    price numeric(18,4) NOT NULL,
    "discountPercent" numeric(5,2),
    "lineAmount" numeric(18,2),
    comment text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrderItem" OWNER TO postgres;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordReset_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordReset_id_seq" OWNER TO postgres;

--
-- Name: PasswordReset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordReset_id_seq" OWNED BY public."PasswordReset".id;


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Permission" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Permission" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Permission_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Permission_id_seq" OWNER TO postgres;

--
-- Name: Permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Permission_id_seq" OWNED BY public."Permission".id;


--
-- Name: PriceType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PriceType" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PriceType" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    article text,
    sku text,
    "groupId" text,
    "isWeight" boolean DEFAULT false NOT NULL,
    "isService" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "baseUnitId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: ProductGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductGroup" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductGroup" OWNER TO postgres;

--
-- Name: ProductPackage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPackage" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "unitId" text NOT NULL,
    name text NOT NULL,
    multiplier numeric(18,4) NOT NULL,
    barcode text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPackage" OWNER TO postgres;

--
-- Name: ProductPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductPrice" OWNER TO postgres;

--
-- Name: QRAnalytic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRAnalytic" (
    id integer NOT NULL,
    ip text,
    location text,
    browser text,
    device text,
    "scanDuration" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "qrListId" text NOT NULL
);


ALTER TABLE public."QRAnalytic" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."QRAnalytic_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QRAnalytic_id_seq" OWNER TO postgres;

--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."QRAnalytic_id_seq" OWNED BY public."QRAnalytic".id;


--
-- Name: QRList; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QRList" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    status public."QRStatus" DEFAULT 'ACTIVE'::public."QRStatus" NOT NULL,
    "createdById" integer NOT NULL,
    "qrData" text NOT NULL,
    description text,
    "qrType" public."QRType" DEFAULT 'TEXT'::public."QRType" NOT NULL
);


ALTER TABLE public."QRList" OWNER TO postgres;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RefreshToken" (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked boolean DEFAULT false NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RefreshToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RefreshToken_id_seq" OWNER TO postgres;

--
-- Name: RefreshToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RefreshToken_id_seq" OWNED BY public."RefreshToken".id;


--
-- Name: Role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Role" (
    id integer NOT NULL,
    name text NOT NULL,
    "parentRoleId" integer
);


ALTER TABLE public."Role" OWNER TO postgres;

--
-- Name: RolePermissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RolePermissions" (
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public."RolePermissions" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Role_id_seq" OWNER TO postgres;

--
-- Name: Role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Role_id_seq" OWNED BY public."Role".id;


--
-- Name: RoutePoint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RoutePoint" (
    id integer NOT NULL,
    "routeId" integer NOT NULL,
    "userId" integer NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    "recordedAt" timestamp(3) without time zone NOT NULL,
    "eventType" public."RouteEventType" DEFAULT 'MOVE'::public."RouteEventType" NOT NULL,
    accuracy double precision,
    speed double precision,
    heading double precision,
    "stayDurationSeconds" integer,
    sequence integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RoutePoint" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RoutePoint_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RoutePoint_id_seq" OWNER TO postgres;

--
-- Name: RoutePoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RoutePoint_id_seq" OWNED BY public."RoutePoint".id;


--
-- Name: SpecialPrice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SpecialPrice" (
    id text NOT NULL,
    guid text,
    "productId" text NOT NULL,
    "counterpartyId" text,
    "agreementId" text,
    "priceTypeId" text,
    price numeric(18,4) NOT NULL,
    currency text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "minQty" numeric(18,3),
    "isActive" boolean DEFAULT true NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SpecialPrice" OWNER TO postgres;

--
-- Name: StockBalance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StockBalance" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "warehouseId" text NOT NULL,
    quantity numeric(18,3) NOT NULL,
    reserved numeric(18,3),
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone
);


ALTER TABLE public."StockBalance" OWNER TO postgres;

--
-- Name: SupplierProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SupplierProfile" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "addressId" integer,
    phone text,
    status public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SupplierProfile" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SupplierProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SupplierProfile_id_seq" OWNER TO postgres;

--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SupplierProfile_id_seq" OWNED BY public."SupplierProfile".id;


--
-- Name: SyncRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRun" (
    id text NOT NULL,
    "requestId" text NOT NULL,
    entity public."SyncEntityType" NOT NULL,
    direction public."SyncDirection" NOT NULL,
    status public."SyncStatus" DEFAULT 'STARTED'::public."SyncStatus" NOT NULL,
    "totalCount" integer DEFAULT 0 NOT NULL,
    "successCount" integer DEFAULT 0 NOT NULL,
    "errorCount" integer DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    notes text,
    meta jsonb
);


ALTER TABLE public."SyncRun" OWNER TO postgres;

--
-- Name: SyncRunItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SyncRunItem" (
    id text NOT NULL,
    "runId" text NOT NULL,
    key text NOT NULL,
    status public."SyncItemStatus" NOT NULL,
    error text,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SyncRunItem" OWNER TO postgres;

--
-- Name: Unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Unit" (
    id text NOT NULL,
    guid text,
    name text NOT NULL,
    code text,
    symbol text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Unit" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "roleId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    "deletedAt" timestamp(3) without time zone,
    phone text,
    "profileStatus" public."ProfileStatus" DEFAULT 'PENDING'::public."ProfileStatus" NOT NULL,
    "currentProfileType" public."ProfileType",
    "firstName" text,
    "lastName" text,
    "middleName" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserRoute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserRoute" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    status public."RouteStatus" DEFAULT 'ACTIVE'::public."RouteStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserRoute" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserRoute_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserRoute_id_seq" OWNER TO postgres;

--
-- Name: UserRoute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserRoute_id_seq" OWNED BY public."UserRoute".id;


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Warehouse" (
    id text NOT NULL,
    guid text NOT NULL,
    name text NOT NULL,
    code text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isPickup" boolean DEFAULT false NOT NULL,
    address text,
    "sourceUpdatedAt" timestamp(3) without time zone,
    "lastSyncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Warehouse" OWNER TO postgres;

--
-- Name: _EmployeeDepartmentRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_EmployeeDepartmentRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_EmployeeDepartmentRoles" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address" ALTER COLUMN id SET DEFAULT nextval('public."Address_id_seq"'::regclass);


--
-- Name: AppUpdate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdate_id_seq"'::regclass);


--
-- Name: AppUpdateEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent" ALTER COLUMN id SET DEFAULT nextval('public."AppUpdateEvent_id_seq"'::regclass);


--
-- Name: Appeal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal" ALTER COLUMN id SET DEFAULT nextval('public."Appeal_id_seq"'::regclass);


--
-- Name: AppealAssignee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee" ALTER COLUMN id SET DEFAULT nextval('public."AppealAssignee_id_seq"'::regclass);


--
-- Name: AppealAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment" ALTER COLUMN id SET DEFAULT nextval('public."AppealAttachment_id_seq"'::regclass);


--
-- Name: AppealMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessage_id_seq"'::regclass);


--
-- Name: AppealMessageRead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead" ALTER COLUMN id SET DEFAULT nextval('public."AppealMessageRead_id_seq"'::regclass);


--
-- Name: AppealStatusHistory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory" ALTER COLUMN id SET DEFAULT nextval('public."AppealStatusHistory_id_seq"'::regclass);


--
-- Name: AppealWatcher id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher" ALTER COLUMN id SET DEFAULT nextval('public."AppealWatcher_id_seq"'::regclass);


--
-- Name: AuditLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog" ALTER COLUMN id SET DEFAULT nextval('public."AuditLog_id_seq"'::regclass);


--
-- Name: ClientProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile" ALTER COLUMN id SET DEFAULT nextval('public."ClientProfile_id_seq"'::regclass);


--
-- Name: Department id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department" ALTER COLUMN id SET DEFAULT nextval('public."Department_id_seq"'::regclass);


--
-- Name: DepartmentRole id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole" ALTER COLUMN id SET DEFAULT nextval('public."DepartmentRole_id_seq"'::regclass);


--
-- Name: DeviceToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken" ALTER COLUMN id SET DEFAULT nextval('public."DeviceToken_id_seq"'::regclass);


--
-- Name: EmailVerification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification" ALTER COLUMN id SET DEFAULT nextval('public."EmailVerification_id_seq"'::regclass);


--
-- Name: EmployeeProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile" ALTER COLUMN id SET DEFAULT nextval('public."EmployeeProfile_id_seq"'::regclass);


--
-- Name: LoginAttempt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt" ALTER COLUMN id SET DEFAULT nextval('public."LoginAttempt_id_seq"'::regclass);


--
-- Name: PasswordReset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset" ALTER COLUMN id SET DEFAULT nextval('public."PasswordReset_id_seq"'::regclass);


--
-- Name: Permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission" ALTER COLUMN id SET DEFAULT nextval('public."Permission_id_seq"'::regclass);


--
-- Name: QRAnalytic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic" ALTER COLUMN id SET DEFAULT nextval('public."QRAnalytic_id_seq"'::regclass);


--
-- Name: RefreshToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken" ALTER COLUMN id SET DEFAULT nextval('public."RefreshToken_id_seq"'::regclass);


--
-- Name: Role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role" ALTER COLUMN id SET DEFAULT nextval('public."Role_id_seq"'::regclass);


--
-- Name: RoutePoint id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint" ALTER COLUMN id SET DEFAULT nextval('public."RoutePoint_id_seq"'::regclass);


--
-- Name: SupplierProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile" ALTER COLUMN id SET DEFAULT nextval('public."SupplierProfile_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserRoute id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute" ALTER COLUMN id SET DEFAULT nextval('public."UserRoute_id_seq"'::regclass);


--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" (id, street, city, state, "postalCode", country, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdate" (id, platform, channel, "versionCode", "versionName", "minSupportedVersionCode", "isMandatory", "rolloutPercent", "isActive", "releaseNotes", "storeUrl", "apkKey", "fileSize", checksum, "checksumMd5", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppUpdateEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppUpdateEvent" (id, "updateId", platform, channel, "versionCode", "versionName", "deviceId", "eventType", "userId", "createdAt") FROM stdin;
1	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	\N	2026-01-27 11:52:55.569
2	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	\N	2026-01-27 11:52:55.653
3	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	UPDATE_CLICK	\N	2026-01-27 11:53:00.764
4	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	DISMISS	\N	2026-01-27 11:53:13.532
5	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	DISMISS	\N	2026-01-27 11:53:13.613
6	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-27 11:54:59.401
7	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	1	2026-01-27 11:54:59.503
8	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-27 11:54:59.505
9	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	UPDATE_CLICK	1	2026-01-27 11:55:04.322
10	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-29 07:32:53.056
11	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	CHECK	1	2026-01-29 07:32:53.181
12	\N	ANDROID	prod	3	1.0.2	inst_mjh35qss_kt5ev71g	PROMPT_SHOWN	1	2026-01-29 07:32:53.183
\.


--
-- Data for Name: Appeal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appeal" (id, number, "fromDepartmentId", "toDepartmentId", "createdById", status, priority, deadline, title, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AppealAssignee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAssignee" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AppealAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealAttachment" (id, "messageId", "fileUrl", "fileName", "fileType", "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessage" (id, "appealId", "senderId", text, "editedAt", deleted, "createdAt") FROM stdin;
\.


--
-- Data for Name: AppealMessageRead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealMessageRead" (id, "messageId", "userId", "readAt") FROM stdin;
\.


--
-- Data for Name: AppealStatusHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealStatusHistory" (id, "appealId", "oldStatus", "newStatus", "changedById", "changedAt") FROM stdin;
\.


--
-- Data for Name: AppealWatcher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppealWatcher" (id, "appealId", "userId") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", "targetType", "targetId", "timestamp", details, action) FROM stdin;
1	1	USER	1	2026-01-27 10:35:19.853	Успешный вход в систему	LOGIN
2	1	USER	1	2026-01-27 11:00:54.637	Успешный вход в систему	LOGIN
3	1	USER	1	2026-01-27 11:04:19.225	Успешный вход в систему	LOGIN
4	1	USER	1	2026-01-27 11:05:09.942	Успешный вход в систему	LOGIN
5	1	USER	1	2026-01-29 07:30:49.607	Успешный вход в систему	LOGIN
6	1	USER	1	2026-01-29 08:56:38.956	Успешный вход в систему	LOGIN
7	1	USER	1	2026-01-31 07:50:30.272	Успешный вход в систему	LOGIN
\.


--
-- Data for Name: ClientAgreement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientAgreement" (id, guid, name, "counterpartyId", "contractId", "priceTypeId", "warehouseId", currency, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientContract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientContract" (id, guid, "counterpartyId", number, date, "validFrom", "validTo", "isActive", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ClientProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClientProfile" (id, "userId", "addressId", phone, status, "createdAt", "updatedAt", "activeAgreementId", "activeContractId", "activeDeliveryAddressId", "activePriceTypeId", "activeWarehouseId", "counterpartyId") FROM stdin;
\.


--
-- Data for Name: Counterparty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Counterparty" (id, guid, name, "fullName", inn, kpp, phone, email, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DeliveryAddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeliveryAddress" (id, guid, "counterpartyId", name, "fullAddress", city, street, house, building, apartment, postcode, "isDefault", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" (id, name) FROM stdin;
1	IT Отдел
2	Бухгалтерия
3	Маркетинг
4	Менеджеры
\.


--
-- Data for Name: DepartmentRole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DepartmentRole" (id, "userId", "roleId", "departmentId") FROM stdin;
\.


--
-- Data for Name: DeviceToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DeviceToken" (id, "userId", token, platform, "createdAt") FROM stdin;
\.


--
-- Data for Name: EmailVerification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailVerification" (id, "userId", code, "expiresAt", used, "attemptsCount", "lastSentAt", "createdAt") FROM stdin;
1	1	746216	2026-01-27 11:13:43.637	t	0	2026-01-27 10:13:43.637	2026-01-27 10:13:43.64
\.


--
-- Data for Name: EmployeeProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmployeeProfile" (id, "userId", "departmentId", phone, status, "createdAt", "updatedAt") FROM stdin;
1	1	1	+7 (961) 223-13-45	PENDING	2026-01-27 10:56:02.762	2026-01-27 10:56:02.762
\.


--
-- Data for Name: LoginAttempt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoginAttempt" (id, "userId", success, ip, "createdAt") FROM stdin;
1	1	t	::ffff:172.20.0.1	2026-01-27 10:35:19.85
2	1	t	::ffff:172.20.0.1	2026-01-27 11:00:54.634
3	1	t	::ffff:172.20.0.1	2026-01-27 11:04:19.222
4	1	t	::ffff:172.20.0.1	2026-01-27 11:05:09.94
5	1	t	::ffff:172.20.0.1	2026-01-29 07:30:49.603
6	1	t	::ffff:172.20.0.1	2026-01-29 08:56:38.954
7	1	t	::ffff:172.20.0.1	2026-01-31 07:50:30.269
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, guid, number1c, date1c, "counterpartyId", "agreementId", "contractId", "warehouseId", "deliveryAddressId", status, comment, "deliveryDate", "totalAmount", currency, "queuedAt", "sentTo1cAt", "lastStatusSyncAt", "exportAttempts", "lastExportError", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderItem" (id, "orderId", "productId", "packageId", "unitId", quantity, "quantityBase", price, "discountPercent", "lineAmount", comment, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordReset" (id, "userId", code, "expiresAt", used, "createdAt") FROM stdin;
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Permission" (id, name) FROM stdin;
1	view_profile
2	update_profile
3	logout
4	manage_roles
5	manage_permissions
6	assign_roles
7	assign_permissions
8	manage_departments
9	manage_users
10	view_fin_reports
11	approve_payments
12	manage_payroll
13	view_shipments
14	manage_shipments
15	manage_inventory
16	create_appeal
17	view_appeal
18	assign_appeal
19	update_appeal_status
20	add_appeal_message
21	edit_appeal_message
22	delete_appeal_message
23	manage_appeal_watchers
24	export_appeals
25	manage_updates
\.


--
-- Data for Name: PriceType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PriceType" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, guid, name, code, article, sku, "groupId", "isWeight", "isService", "isActive", "sourceUpdatedAt", "lastSyncedAt", "baseUnitId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductGroup" (id, guid, name, code, "isActive", "sourceUpdatedAt", "lastSyncedAt", "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPackage" (id, guid, "productId", "unitId", name, multiplier, barcode, "isDefault", "sortOrder", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductPrice" (id, guid, "productId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: QRAnalytic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRAnalytic" (id, ip, location, browser, device, "scanDuration", "createdAt", "qrListId") FROM stdin;
\.


--
-- Data for Name: QRList; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QRList" (id, "createdAt", "updatedAt", status, "createdById", "qrData", description, "qrType") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt", revoked) FROM stdin;
1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijg0OGYyNDhiLWUyMjMtNDdkZC1hOTQyLTgyMTNjZjY0YTY4ZCIsImlhdCI6MTc2OTUxMDExOSwiZXhwIjoxNzcyMTAyMTE5fQ.6x2KCqtCbSfq6X4WmqnmJr5bwgT430itvPgse7Xe9PA	1	2026-02-26 10:35:19.844	2026-01-27 10:35:19.845	f
2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjNmY2YwZWNkLTZmYjAtNDEzMi1hOTFjLTc4MWY2NjVmYWRiMSIsImlhdCI6MTc2OTUxMTY1NCwiZXhwIjoxNzcyMTAzNjU0fQ.kQsj529-DRXCTYucDx5DHckWM-Fpow4wKbprNAynSug	1	2026-02-26 11:00:54.629	2026-01-27 11:00:54.629	f
3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImJiZGQwZWJlLTc0ZTAtNDhjZi05Y2MxLTYyMjg5NGMyOGFkNyIsImlhdCI6MTc2OTUxMTg1OSwiZXhwIjoxNzcyMTAzODU5fQ.vLw1b1toM3_7Qhjzzw6k_yywKSBL9dG-ZkWU6JjmKu0	1	2026-02-26 11:04:19.216	2026-01-27 11:04:19.217	t
4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjY2MzM1OGYxLWUxYWEtNGI1YS1hYTUzLTczNzllZmZjMTBlYiIsImlhdCI6MTc2OTUxMTkwOSwiZXhwIjoxNzcyMTAzOTA5fQ.W4fzSPkUispAvAimT4nsGxP1f6Dg_I7TAQemcxKoZ-g	1	2026-02-26 11:05:09.936	2026-01-27 11:05:09.937	t
5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImFjMWRhNDVjLWUyMGMtNGE4Zi05ZTUwLWNkZDNmNTM5YmRmYSIsImlhdCI6MTc2OTUxMzk0NywiZXhwIjoxNzcyMTA1OTQ3fQ.0XajzuBKrYW3y463QxWu1lynBzDi9RMihpVTOwem8rU	1	2026-02-26 11:39:07.337	2026-01-27 11:39:07.343	t
7	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjkxMWNmNzliLTQ5MWMtNGViOS04Njc1LTFiY2FmMTc1YTBjYSIsImlhdCI6MTc2OTUxNTg5MCwiZXhwIjoxNzcyMTA3ODkwfQ.mFYjNSQFlKwDXehc1URkAY8CAEvzzIWAXwqbTlA-yFQ	1	2026-02-26 12:11:30.961	2026-01-27 12:11:30.965	t
8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjJkOThjMzE3LTY0YTEtNGY5Zi1hYWE4LWY1ODFlZGUyOWRhNyIsImlhdCI6MTc2OTUyMzEyNywiZXhwIjoxNzcyMTE1MTI3fQ.lE-p3wjxMC2JrhVx1pEQz8D9cwGb6UQguh8OhrlNKxI	1	2026-02-26 14:12:07.001	2026-01-27 14:12:07.006	t
9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijc3NjUzMjJjLTkzNjMtNGU3Yy05OWQ5LTc2YjkyOWI1ZDU0NyIsImlhdCI6MTc2OTUzNTE3MSwiZXhwIjoxNzcyMTI3MTcxfQ.ScbAiaTl9_FgcJrd4jWB4ZoEptuUWiaZMQiAXx4QJm0	1	2026-02-26 17:32:51.523	2026-01-27 17:32:51.528	f
6	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjUzMjJhMTA4LWM1MmUtNDJmMy05M2Q1LWZhZjhlYWYzZGJjYiIsImlhdCI6MTc2OTUxNDg5MywiZXhwIjoxNzcyMTA2ODkzfQ.nzxA9dbpGvxChM62rjGsZgauthTAQoNDzzjicrRawrQ	1	2026-02-26 11:54:53.282	2026-01-27 11:54:53.283	t
10	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjMzOGExMzBmLTU0NGYtNGRjZi04ODljLTA5ODdkZjJkNzMyNCIsImlhdCI6MTc2OTY3MTg0OSwiZXhwIjoxNzcyMjYzODQ5fQ.j6eGvAErCnHStinnZrx1IX90V3Tt2cTOGqOVlxLHDSc	1	2026-02-28 07:30:49.592	2026-01-29 07:30:49.596	t
11	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6Ijk5MDRlNDQ5LWUxNTAtNGM4Mi1hMWFlLWI2ZjA1ZjM2NzNlNSIsImlhdCI6MTc2OTY3MTk3MiwiZXhwIjoxNzcyMjYzOTcyfQ.bE7uu_mKhafW9lH7AaS3xXPrfVObH-ex3bsblF6p7hw	1	2026-02-28 07:32:52.549	2026-01-29 07:32:52.549	t
12	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjUyMmM3YzZlLTk2YWEtNGQwMC05MzlhLTcyN2UzMzg4ZjZiNSIsImlhdCI6MTc2OTY3NDcyNCwiZXhwIjoxNzcyMjY2NzI0fQ.6Ruruaap8XR6pKf9qVAT_p3KBTIc4xzgFYosa4y6rZo	1	2026-02-28 08:18:44.042	2026-01-29 08:18:44.043	t
14	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjFjZGRmMGIzLTEzOTYtNDhiZS04MzMxLTc0NWI1MjQyZjUzNSIsImlhdCI6MTc2OTY3Njk2NCwiZXhwIjoxNzcyMjY4OTY0fQ.L2X6xuiA2cEggvhfo2XCaFa9ZnzuMV0lIzlxZmKSwr0	1	2026-02-28 08:56:04.02	2026-01-29 08:56:04.021	f
15	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjcxY2NmMDk5LWZhYmMtNGViMy1iM2YxLTY0ZTE4ZTQ1NjUyYiIsImlhdCI6MTc2OTY3Njk5OCwiZXhwIjoxNzcyMjY4OTk4fQ.wB2LBMvX-UemdbQj8UrbJQynZK5T-nNtslRRidbuJ3w	1	2026-02-28 08:56:38.949	2026-01-29 08:56:38.95	f
16	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjNlM2Q4YzM4LWFlNDAtNDEzYy1hOTEwLWY1OWZiNWU3OTMxNCIsImlhdCI6MTc2OTg0NTgzMCwiZXhwIjoxNzcyNDM3ODMwfQ.erV_iOi30RpU3veuDp273_wQkRoOg6Qsx2HwTeWU3Xc	1	2026-03-02 07:50:30.261	2026-01-31 07:50:30.266	f
13	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImY1NjI0MDE5LThiZjItNDhlYS1hMWFjLTdmZjY1ZjE0N2JmNiIsImlhdCI6MTc2OTY3NjY0NCwiZXhwIjoxNzcyMjY4NjQ0fQ.bbOGMA7UpY1XScxTk_e0E0z4A3C9WHI6wt6np05eTHA	1	2026-02-28 08:50:44.407	2026-01-29 08:50:44.408	t
17	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjJiMGZmYzc2LTgyMWEtNDIyOC05N2EzLTIxZDI3YWViNzE2OSIsImlhdCI6MTc2OTg4NDI0MywiZXhwIjoxNzcyNDc2MjQzfQ.jKitCDhCPOSIaTd1n0iGapcTp5YcBz23n8Hx3gmBMdo	1	2026-03-02 18:30:43.973	2026-01-31 18:30:43.973	t
18	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImIzM2Y1OWY1LThlMzctNDQyNC1hODVjLTgwZTJjOGFkYTZlYSIsImlhdCI6MTc2OTg4NjQ1OCwiZXhwIjoxNzcyNDc4NDU4fQ.yDU6obdsHzyowvlIqwu05LCNz0qrniUN1z9pblhrUR4	1	2026-03-02 19:07:38.257	2026-01-31 19:07:38.257	t
19	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImVhOWY4NzY1LTUzNDUtNGFkNy05ZWM1LWY3MDU3MzAwOTM0MyIsImlhdCI6MTc2OTg4ODk1NCwiZXhwIjoxNzcyNDgwOTU0fQ.XqoXUuXgp9Dl68ol363xZnLAREGYaB8Ghg9lAqtYvDY	1	2026-03-02 19:49:14.09	2026-01-31 19:49:14.09	t
20	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6IjM0MWRjODcwLWIzNjMtNDcyMy04NThhLTM1Y2YzMzY5MzNjZSIsImlhdCI6MTc2OTg5MjU2MiwiZXhwIjoxNzcyNDg0NTYyfQ.zlAA5xd-519mJgO5sPsUoboWJjJj2X-ifUWP8LJaIvo	1	2026-03-02 20:49:22.341	2026-01-31 20:49:22.341	t
21	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImp0aSI6ImMwNTZmM2I1LTM4YTctNDU3OC1hOWQzLTEwMDdiM2E1YWJmZiIsImlhdCI6MTc2OTg5OTgwOSwiZXhwIjoxNzcyNDkxODA5fQ.K9bn51oiBCRxwgVDtQRLxSTPqIbdDmaVk3rJKJzizUQ	1	2026-03-02 22:50:09.319	2026-01-31 22:50:09.32	f
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Role" (id, name, "parentRoleId") FROM stdin;
1	user	\N
2	employee	1
3	department_manager	2
4	admin	3
\.


--
-- Data for Name: RolePermissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RolePermissions" ("roleId", "permissionId") FROM stdin;
1	1
1	2
1	3
2	16
2	17
2	20
2	21
2	22
2	23
3	18
3	19
3	24
4	1
4	2
4	3
4	4
4	5
4	6
4	7
4	8
4	9
4	10
4	11
4	12
4	13
4	14
4	15
4	16
4	17
4	18
4	19
4	20
4	21
4	22
4	23
4	24
4	25
\.


--
-- Data for Name: RoutePoint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RoutePoint" (id, "routeId", "userId", latitude, longitude, "recordedAt", "eventType", accuracy, speed, heading, "stayDurationSeconds", sequence, "createdAt") FROM stdin;
1	1	1	55.1067804	82.952315	2026-01-31 18:30:18.777	MOVE	32.34199905395508	0	0	\N	1	2026-01-31 18:32:14.917
2	1	1	55.1068347	82.9525492	2026-01-31 18:33:39.323	MOVE	49.5	5.559999942779541	275	\N	2	2026-01-31 18:33:40.737
3	1	1	55.1068094	82.9521735	2026-01-31 18:33:57.304	MOVE	21.27300071716309	2.345026969909668	289.0368957519531	\N	3	2026-01-31 18:34:01.541
4	1	1	55.1067822	82.952432	2026-01-31 18:34:14.548	MOVE	32.0099983215332	1.624506711959839	103.758674621582	\N	4	2026-01-31 18:34:17.411
5	1	1	55.1067813	82.9522236	2026-01-31 18:34:28.291	MOVE	45.5	0.7097352147102356	253.0186157226562	\N	5	2026-01-31 18:34:30.638
6	1	1	55.1068677	82.9519751	2026-01-31 18:34:48.592	MOVE	40.31000137329102	0	0	\N	6	2026-01-31 18:34:57.266
7	1	1	55.10686	82.952056	2026-01-31 18:35:05.499	MOVE	18.97500038146973	0.009505301713943481	0	\N	7	2026-01-31 18:35:08.337
8	1	1	55.1067665	82.9522499	2026-01-31 18:35:22.396	MOVE	21.86199951171875	0	0	\N	8	2026-01-31 18:35:25.376
9	1	1	55.1068038	82.9522039	2026-01-31 18:37:03.842	MOVE	24.69700050354004	0	0	\N	9	2026-01-31 18:37:06.843
10	1	1	55.1067804	82.9522821	2026-01-31 18:37:37.786	MOVE	31.48100090026855	0	0	\N	10	2026-01-31 18:37:40.848
11	1	1	55.1067579	82.9521811	2026-01-31 18:40:26.991	MOVE	22.48200035095215	2.547088146209717	245.0231475830078	\N	11	2026-01-31 18:40:29.956
12	1	1	55.1067711	82.9522644	2026-01-31 18:41:00.847	MOVE	20.1830005645752	0	0	\N	12	2026-01-31 18:41:03.853
13	1	1	55.1070828	82.9518576	2026-01-31 18:41:15.265	MOVE	134	2.492164134979248	313.2636108398438	\N	13	2026-01-31 18:41:18.196
14	1	1	55.1067832	82.9522366	2026-01-31 18:41:17.753	MOVE	23.7140007019043	2.466213941574097	312.9832153320312	\N	14	2026-01-31 18:41:35.655
15	1	1	55.1068135	82.9523214	2026-01-31 18:42:23.266	MOVE	49	2.871767520904541	273.0154418945312	\N	15	2026-01-31 18:42:26.172
16	1	1	55.106857	82.9521305	2026-01-31 18:42:27.292	MOVE	35.73099899291992	5.332225799560547	287.1360778808594	\N	16	2026-01-31 18:42:45.207
17	1	1	55.1067747	82.9523117	2026-01-31 18:42:42.352	MOVE	31.15800094604492	0	0	\N	17	2026-01-31 18:43:00.233
18	1	1	55.1069044	82.9521234	2026-01-31 18:42:57.287	MOVE	37.5	6.63052225112915	267.9819946289062	\N	18	2026-01-31 18:43:00.233
19	1	1	55.1069014	82.9519467	2026-01-31 18:42:59.253	MOVE	46.94300079345703	6.577614784240723	267.9765014648438	\N	19	2026-01-31 18:43:17.171
20	1	1	55.1067983	82.9522813	2026-01-31 18:43:16.16	MOVE	30.77899932861328	0	0	\N	20	2026-01-31 18:43:19.072
21	1	1	55.1069991	82.9519669	2026-01-31 18:43:33.083	MOVE	145.3849945068359	0.9503021240234375	292.0162963867188	\N	21	2026-01-31 18:43:36.058
22	1	1	55.1068004	82.9522785	2026-01-31 18:43:50.043	MOVE	31.30299949645996	0	0	\N	22	2026-01-31 18:43:53.025
23	1	1	55.1072316	82.9504367	2026-01-31 18:44:07.008	MOVE	171.1499938964844	12.17535305023193	286.3936157226562	\N	23	2026-01-31 18:44:09.995
24	1	1	55.1067736	82.9523021	2026-01-31 18:44:23.916	MOVE	23.9419994354248	0	0	\N	24	2026-01-31 18:44:26.874
25	1	1	55.1067438	82.9521105	2026-01-31 18:44:40.886	MOVE	30.88100051879883	8.220898628234863	268.7593383789062	\N	25	2026-01-31 18:44:43.883
26	1	1	55.1067805	82.9522556	2026-01-31 18:44:57.78	MOVE	23.43600082397461	1.006226658821106	258.369140625	\N	26	2026-01-31 18:45:00.759
27	1	1	55.106957	82.9515958	2026-01-31 18:45:12.266	MOVE	29.5	1.0501788854599	327.1939086914062	\N	27	2026-01-31 18:45:15.151
28	1	1	55.1067706	82.9522484	2026-01-31 18:45:31.584	MOVE	23.05299949645996	0	0	\N	28	2026-01-31 18:45:34.537
29	1	1	55.1067131	82.9528056	2026-01-31 18:45:46.267	MOVE	55	19.99742126464844	133.92529296875	\N	29	2026-01-31 18:45:49.168
30	1	1	55.1065	82.9532138	2026-01-31 18:45:48.501	MOVE	78.27300262451172	19.42607688903809	133.7977142333984	\N	30	2026-01-31 18:46:06.396
31	1	1	55.1067689	82.9522685	2026-01-31 18:46:05.416	MOVE	22.3799991607666	0	0	\N	31	2026-01-31 18:46:08.356
32	1	1	55.1068231	82.9523067	2026-01-31 18:46:22.316	MOVE	192.2740020751953	1.595034003257751	95.0837631225586	\N	32	2026-01-31 18:46:25.265
33	1	1	55.1067775	82.9522512	2026-01-31 18:46:56.107	MOVE	21.11199951171875	0.6079869866371155	319.3273315429688	\N	33	2026-01-31 18:46:59.069
34	1	1	55.1066716	82.9538616	2026-01-31 18:48:23.289	MOVE	165.5	0	0	\N	34	2026-01-31 18:48:26.36
35	1	1	55.1067802	82.9523926	2026-01-31 18:48:40.902	MOVE	32.625	0.4307666420936584	307.3108215332031	\N	35	2026-01-31 18:48:44.07
36	1	1	55.1067886	82.9522454	2026-01-31 18:48:57.897	MOVE	19.4109992980957	0	0	\N	36	2026-01-31 18:49:01.031
37	1	1	55.1067864	82.9521496	2026-01-31 18:49:31.267	MOVE	73	5.900000095367432	117	\N	37	2026-01-31 18:55:24.728
38	1	1	55.1067612	82.9523147	2026-01-31 18:50:15.517	MOVE	19.95999908447266	4.201371669769287	115.1215209960938	\N	38	2026-01-31 18:55:24.728
39	1	1	55.106787	82.9528762	2026-01-31 18:50:31.314	MOVE	92	3.519999980926514	94	\N	39	2026-01-31 18:55:24.728
40	1	1	55.1067746	82.9522073	2026-01-31 18:50:49.653	MOVE	26.36300086975098	0	0	\N	40	2026-01-31 18:55:24.728
41	1	1	55.10704	82.9517681	2026-01-31 18:51:31.34	MOVE	78.5	5.400000095367432	294	\N	41	2026-01-31 18:55:24.728
42	1	1	55.1067577	82.9522462	2026-01-31 18:51:49.245	MOVE	24.69000053405762	0	0	\N	42	2026-01-31 18:55:24.728
43	1	1	55.1067632	82.9526776	2026-01-31 18:52:01.322	MOVE	84.5	2.355393886566162	117.9621276855469	\N	43	2026-01-31 18:55:24.728
44	1	1	55.1067641	82.9522221	2026-01-31 18:52:16.385	MOVE	33.37699890136719	0	0	\N	44	2026-01-31 18:55:24.728
45	1	1	55.1067792	82.9525959	2026-01-31 18:52:31.307	MOVE	112.5	0.9802989363670349	49.20003128051758	\N	45	2026-01-31 18:55:24.728
46	1	1	55.106769	82.9522102	2026-01-31 18:52:51.414	MOVE	27.85099983215332	0	0	\N	46	2026-01-31 18:55:24.728
47	1	1	55.1068605	82.9522504	2026-01-31 18:54:01.267	MOVE	80.5	5.072478771209717	107.24853515625	\N	47	2026-01-31 18:55:24.728
48	1	1	55.1067637	82.9522614	2026-01-31 18:54:15.231	MOVE	21.68400001525879	2.583331108093262	122.0659713745117	\N	48	2026-01-31 18:55:24.728
49	1	1	55.106967	82.9520405	2026-01-31 18:54:31.292	MOVE	159	1.819999933242798	301	\N	49	2026-01-31 18:55:24.728
50	1	1	55.1067614	82.9522276	2026-01-31 18:54:49.309	MOVE	26.60199928283691	0	0	\N	50	2026-01-31 18:55:24.728
51	1	1	55.1068024	82.952323	2026-01-31 18:55:15.312	MOVE	35.16299819946289	2.62878680229187	104.2093276977539	\N	51	2026-01-31 18:55:24.728
52	1	1	55.1069029	82.9524417	2026-01-31 18:55:31.287	MOVE	113	0.5299999713897705	131	\N	52	2026-01-31 19:07:38.582
53	1	1	55.1067723	82.9522504	2026-01-31 18:55:49.432	MOVE	27.07200050354004	0	0	\N	53	2026-01-31 19:07:38.582
54	1	1	55.1069553	82.952046	2026-01-31 18:56:31.262	MOVE	70	3.199999809265137	304	\N	54	2026-01-31 19:07:38.582
55	1	1	55.1067646	82.9521823	2026-01-31 18:56:50.225	MOVE	37.58100128173828	0	0	\N	55	2026-01-31 19:07:38.582
56	1	1	55.1067648	82.9525475	2026-01-31 18:57:01.299	MOVE	90.5	0.9408352375030518	304.2814636230469	\N	56	2026-01-31 19:07:38.582
57	1	1	55.1067616	82.9522316	2026-01-31 18:57:16.482	MOVE	35.87400054931641	0	0	\N	57	2026-01-31 19:07:38.582
58	1	1	55.1068563	82.9524348	2026-01-31 18:57:31.303	MOVE	80.5	0.3029271364212036	91.89619445800781	\N	58	2026-01-31 19:07:38.582
59	1	1	55.1067766	82.9522551	2026-01-31 18:57:45.368	MOVE	36.29000091552734	0.0931115448474884	0	\N	59	2026-01-31 19:07:38.582
60	1	1	55.1069183	82.9521763	2026-01-31 18:58:01.29	MOVE	73.5	1.169999957084656	295	\N	60	2026-01-31 19:07:38.582
61	1	1	55.1067682	82.9522256	2026-01-31 18:58:19.416	MOVE	36.80099868774414	0	0	\N	61	2026-01-31 19:07:38.582
62	1	1	55.1069319	82.9522304	2026-01-31 18:59:01.286	MOVE	66	1.799999952316284	285	\N	62	2026-01-31 19:07:38.582
63	1	1	55.106766	82.9522187	2026-01-31 18:59:19.884	MOVE	36.29000091552734	0	0	\N	63	2026-01-31 19:07:38.582
64	1	1	55.1067722	82.9523005	2026-01-31 18:59:45.746	MOVE	17.16500091552734	0.4143889546394348	148.2273712158203	\N	64	2026-01-31 19:07:38.582
65	1	1	55.1069731	82.9522918	2026-01-31 19:00:01.299	MOVE	136	2.609999895095825	105	\N	65	2026-01-31 19:07:38.582
66	1	1	55.1067351	82.9522089	2026-01-31 19:00:19.811	MOVE	45.75899887084961	0	0	\N	66	2026-01-31 19:07:38.582
67	1	1	55.1067801	82.9522266	2026-01-31 19:00:46.175	MOVE	27.1560001373291	0.5965769290924072	293.7528991699219	\N	67	2026-01-31 19:07:38.582
68	1	1	55.1068402	82.9524624	2026-01-31 19:01:01.265	MOVE	103.5	0.2800000011920929	94	\N	68	2026-01-31 19:07:38.582
69	1	1	55.106766	82.9522228	2026-01-31 19:01:20.226	MOVE	35.54499816894531	0	0	\N	69	2026-01-31 19:07:38.582
70	1	1	55.1067704	82.9526974	2026-01-31 19:02:01.289	MOVE	106	1.120000004768372	97	\N	70	2026-01-31 19:07:38.582
71	1	1	55.1067727	82.9522161	2026-01-31 19:02:19.402	MOVE	37.63100051879883	0	0	\N	71	2026-01-31 19:07:38.582
72	1	1	55.1068385	82.9524306	2026-01-31 19:05:01.282	MOVE	133.5	1.669999957084656	112	\N	72	2026-01-31 19:07:38.582
73	1	1	55.1067833	82.9522268	2026-01-31 19:05:20.434	MOVE	23.46699905395508	0	0	\N	73	2026-01-31 19:07:38.582
74	1	1	55.1067957	82.9526507	2026-01-31 19:06:01.267	MOVE	169	1.049999952316284	305	\N	74	2026-01-31 19:07:38.582
75	1	1	55.1067941	82.9522395	2026-01-31 19:06:19.35	MOVE	31.28800010681152	0	0	\N	75	2026-01-31 19:07:38.582
76	1	1	55.1068934	82.9526857	2026-01-31 19:07:01.304	MOVE	52.5	0.8299999833106995	73	\N	76	2026-01-31 19:07:38.582
77	1	1	55.1067954	82.952242	2026-01-31 19:07:19.374	MOVE	36.45800018310547	0	0	\N	77	2026-01-31 19:07:38.582
78	1	1	55.1068316	82.9523313	2026-01-31 19:07:36.449	MOVE	192.4490051269531	1.126964449882507	299.3040771484375	\N	78	2026-01-31 19:07:39.449
79	1	1	55.1067907	82.9522664	2026-01-31 19:07:53.448	MOVE	33.75899887084961	0	0	\N	79	2026-01-31 19:07:56.568
80	1	1	55.1067982	82.9524169	2026-01-31 19:08:31.276	MOVE	39.17699813842773	0.6857903599739075	270.0035095214844	\N	80	2026-01-31 19:08:49.224
81	1	1	55.1067963	82.9522293	2026-01-31 19:08:46.188	MOVE	37.36600112915039	0.7352138757705688	269.9897155761719	\N	81	2026-01-31 19:09:04.339
82	1	1	55.1068895	82.9527033	2026-01-31 19:09:01.251	MOVE	70.5	3.629999876022339	298	\N	82	2026-01-31 19:09:04.339
83	1	1	55.1067853	82.9522052	2026-01-31 19:09:20.224	MOVE	36.70999908447266	0	0	\N	83	2026-01-31 19:09:23.304
84	1	1	55.1067926	82.9522944	2026-01-31 19:09:44.932	MOVE	32.74700164794922	0.3890503942966461	108.4889831542969	\N	84	2026-01-31 19:49:14.345
85	1	1	55.1069371	82.951809	2026-01-31 19:10:01.274	MOVE	88	0.7999999523162842	131	\N	85	2026-01-31 19:49:14.345
86	1	1	55.1067764	82.952235	2026-01-31 19:10:19.019	MOVE	23.12400054931641	0	0	\N	86	2026-01-31 19:49:14.345
87	1	1	55.1069674	82.9521176	2026-01-31 19:10:36.08	MOVE	186.2940063476562	1.133079051971436	280.1195373535156	\N	87	2026-01-31 19:49:14.345
88	1	1	55.1067757	82.9522424	2026-01-31 19:10:53.039	MOVE	22.66699981689453	0	0	\N	88	2026-01-31 19:49:14.345
89	1	1	55.1069025	82.9520186	2026-01-31 19:12:01.235	MOVE	85	0.9300000071525574	316	\N	89	2026-01-31 19:49:14.345
90	1	1	55.1067934	82.952208	2026-01-31 19:12:20.247	MOVE	24.33600044250488	0	0	\N	90	2026-01-31 19:49:14.345
91	1	1	55.1068594	82.9527303	2026-01-31 19:13:01.286	MOVE	59	4.949999809265137	126	\N	91	2026-01-31 19:49:14.345
92	1	1	55.106789	82.9522035	2026-01-31 19:13:19.43	MOVE	24.00699996948242	0	0	\N	92	2026-01-31 19:49:14.345
93	1	1	55.1067117	82.9525452	2026-01-31 19:14:01.236	MOVE	100	0.4899999797344208	60	\N	93	2026-01-31 19:49:14.345
94	1	1	55.1067796	82.9522649	2026-01-31 19:14:20.208	MOVE	31.0580005645752	0	0	\N	94	2026-01-31 19:49:14.345
95	1	1	55.1070239	82.9520018	2026-01-31 19:15:02.238	MOVE	79.5	12.72999954223633	299	\N	95	2026-01-31 19:49:14.345
96	1	1	55.1070736	82.9518455	2026-01-31 19:15:04.098	MOVE	98.0979995727539	12.66694450378418	299.0753784179688	\N	96	2026-01-31 19:49:14.345
97	1	1	55.1067906	82.9522162	2026-01-31 19:15:21.101	MOVE	22.74600028991699	0	0	\N	97	2026-01-31 19:49:14.345
98	1	1	55.1069677	82.9521905	2026-01-31 19:16:04.251	MOVE	88.5	2.109999895095825	308	\N	98	2026-01-31 19:49:14.345
99	1	1	55.1067823	82.9522417	2026-01-31 19:16:23.259	MOVE	22.13199996948242	0	0	\N	99	2026-01-31 19:49:14.345
100	1	1	55.1068595	82.9522962	2026-01-31 19:17:14.167	MOVE	395.5759887695312	1.072343945503235	51.55415725708008	\N	100	2026-01-31 19:49:14.345
101	1	1	55.1068026	82.9522102	2026-01-31 19:17:31.205	MOVE	40.39699935913086	0	0	\N	101	2026-01-31 19:49:14.345
102	1	1	55.1056167	82.9586883	2026-01-31 19:17:45.36	MOVE	75.83300018310547	34.43742370605469	106.1299819946289	\N	102	2026-01-31 19:49:14.345
103	1	1	55.1068659	82.9523061	2026-01-31 19:18:09.247	MOVE	75	1.059999942779541	83	\N	103	2026-01-31 19:49:14.345
104	1	1	55.1067985	82.9522361	2026-01-31 19:18:31.23	MOVE	18.67000007629395	0	0	\N	104	2026-01-31 19:49:14.345
105	1	1	55.1069333	82.9523435	2026-01-31 19:18:45.241	MOVE	56	4.972354412078857	277.3412475585938	\N	105	2026-01-31 19:49:14.345
106	1	1	55.1068285	82.9522131	2026-01-31 19:18:58.225	MOVE	22.63599967956543	1.713366985321045	285.5112609863281	\N	106	2026-01-31 19:49:14.345
107	1	1	55.1069484	82.9519191	2026-01-31 19:19:14.255	MOVE	76	0.6800000071525574	321	\N	107	2026-01-31 19:49:14.345
108	1	1	55.1067726	82.952246	2026-01-31 19:19:32.214	MOVE	23.03499984741211	0	0	\N	108	2026-01-31 19:49:14.345
109	1	1	55.1068495	82.9522244	2026-01-31 19:20:14.233	MOVE	61	0.8390747904777527	111.0488510131836	\N	109	2026-01-31 19:49:14.345
110	1	1	55.1067929	82.9522341	2026-01-31 19:20:30.831	MOVE	33.91500091552734	0	0	\N	110	2026-01-31 19:49:14.345
111	1	1	55.1069011	82.9522823	2026-01-31 19:21:22.483	MOVE	329.1690063476562	1.633522748947144	37.64657974243164	\N	111	2026-01-31 19:49:14.345
112	1	1	55.1067723	82.9522373	2026-01-31 19:21:39.445	MOVE	42.07199859619141	0	0	\N	112	2026-01-31 19:49:14.345
113	1	1	55.1068213	82.9521225	2026-01-31 19:22:14.281	MOVE	73.5	2.187945127487183	320.8595275878906	\N	113	2026-01-31 19:49:14.345
114	1	1	55.1067827	82.9522465	2026-01-31 19:22:30.186	MOVE	30.14699935913086	0	0	\N	114	2026-01-31 19:49:14.345
115	1	1	55.1068474	82.952512	2026-01-31 19:22:44.255	MOVE	72.5	2.222326040267944	61.31353378295898	\N	115	2026-01-31 19:49:14.345
116	1	1	55.1067869	82.9522647	2026-01-31 19:23:00.193	MOVE	27.8390007019043	0	0	\N	116	2026-01-31 19:49:14.345
117	1	1	55.1068425	82.9520447	2026-01-31 19:23:14.241	MOVE	68.5	1.13027036190033	114.1530380249023	\N	117	2026-01-31 19:49:14.345
118	1	1	55.1067738	82.9522321	2026-01-31 19:23:32.2	MOVE	37.28099822998047	0	0	\N	118	2026-01-31 19:49:14.345
119	1	1	55.1068464	82.9522112	2026-01-31 19:24:14.224	MOVE	55.5	3.479134321212769	309.0774841308594	\N	119	2026-01-31 19:49:14.345
120	1	1	55.1067861	82.9522251	2026-01-31 19:24:30.12	MOVE	23.37599945068359	0	0	\N	120	2026-01-31 19:49:14.345
121	1	1	55.106784	82.9523616	2026-01-31 19:24:44.243	MOVE	78	3.917104721069336	311.0588073730469	\N	121	2026-01-31 19:49:14.345
122	1	1	55.1067831	82.9522227	2026-01-31 19:25:00.425	MOVE	23.67799949645996	0	0	\N	122	2026-01-31 19:49:14.345
123	1	1	55.1068421	82.9520626	2026-01-31 19:25:14.229	MOVE	67.5	3.264548301696777	299.2003479003906	\N	123	2026-01-31 19:49:14.345
124	1	1	55.1067765	82.952239	2026-01-31 19:25:29.44	MOVE	22.74600028991699	0	0	\N	124	2026-01-31 19:49:14.345
125	1	1	55.106838	82.9524126	2026-01-31 19:25:44.251	MOVE	82	2.693152666091919	311.2552795410156	\N	125	2026-01-31 19:49:14.345
126	1	1	55.1068101	82.9522097	2026-01-31 19:25:59.181	MOVE	22.64100074768066	1.749419093132019	302.6126403808594	\N	126	2026-01-31 19:49:14.345
127	1	1	55.1068009	82.952294	2026-01-31 19:26:17.209	MOVE	43.26499938964844	5.08620548248291	65.8900146484375	\N	127	2026-01-31 19:49:14.345
128	1	1	55.1070279	82.9516035	2026-01-31 19:27:10.229	MOVE	38.5	4.336557388305664	282.8895568847656	\N	128	2026-01-31 19:49:14.345
129	1	1	55.1067662	82.9522491	2026-01-31 19:27:27.829	MOVE	21.60499954223633	0	0	\N	129	2026-01-31 19:49:14.345
130	1	1	55.1067988	82.9524789	2026-01-31 19:27:44.214	MOVE	72.5	1.059999942779541	228	\N	130	2026-01-31 19:49:14.345
131	1	1	55.106772	82.9522515	2026-01-31 19:28:01.742	MOVE	21.61499977111816	0	0	\N	131	2026-01-31 19:49:14.345
132	1	1	55.1067274	82.9529113	2026-01-31 19:28:45.233	MOVE	121.5	0.6699999570846558	326	\N	132	2026-01-31 19:49:14.345
133	1	1	55.1067785	82.9522609	2026-01-31 19:29:02.23	MOVE	20.85300064086914	0	0	\N	133	2026-01-31 19:49:14.345
134	1	1	55.1068189	82.9524644	2026-01-31 19:29:19.286	MOVE	151.4199981689453	0.06730148196220398	0	\N	134	2026-01-31 19:49:14.345
135	1	1	55.1067755	82.9522568	2026-01-31 19:29:36.235	MOVE	31.19799995422363	0	0	\N	135	2026-01-31 19:49:14.345
136	1	1	55.1068174	82.9521754	2026-01-31 19:29:57.413	MOVE	31.6569995880127	1.147831678390503	287.922119140625	\N	136	2026-01-31 19:49:14.345
137	1	1	55.1069319	82.9525581	2026-01-31 19:30:14.252	MOVE	60.5	2.069999933242798	73	\N	137	2026-01-31 19:49:14.345
138	1	1	55.1067742	82.9522517	2026-01-31 19:30:31.425	MOVE	31.05200004577637	0	0	\N	138	2026-01-31 19:49:14.345
139	1	1	55.1068927	82.9521504	2026-01-31 19:31:14.254	MOVE	46	0.9799999594688416	111	\N	139	2026-01-31 19:49:14.345
140	1	1	55.1067951	82.9522403	2026-01-31 19:31:32.003	MOVE	18.5359992980957	0	0	\N	140	2026-01-31 19:49:14.345
141	1	1	55.1068805	82.9527118	2026-01-31 19:31:49.01	MOVE	146.0769958496094	0.152097687125206	270.0281066894531	\N	141	2026-01-31 19:49:14.345
142	1	1	55.1067796	82.9522378	2026-01-31 19:32:06.076	MOVE	22.01899909973145	0	0	\N	142	2026-01-31 19:49:14.345
143	1	1	55.1068278	82.9528036	2026-01-31 19:33:14.246	MOVE	161.5	1.961196303367615	82.06017303466797	\N	143	2026-01-31 19:49:14.345
144	1	1	55.1067925	82.9523005	2026-01-31 19:33:27.797	MOVE	28.09900093078613	2.169147491455078	263.0561828613281	\N	144	2026-01-31 19:49:14.345
145	1	1	55.1069014	82.9518177	2026-01-31 19:33:44.242	MOVE	146	12.69999980926514	94	\N	145	2026-01-31 19:49:14.345
146	1	1	55.1067672	82.9522211	2026-01-31 19:34:02.049	MOVE	33.88899993896484	0	0	\N	146	2026-01-31 19:49:14.345
147	1	1	55.1068049	82.9523014	2026-01-31 19:34:29.133	MOVE	40.39500045776367	0.03305279836058617	0	\N	147	2026-01-31 19:49:14.345
148	1	1	55.1070215	82.9517737	2026-01-31 19:34:45.247	MOVE	75	15.21000003814697	278	\N	148	2026-01-31 19:49:14.345
149	1	1	55.1067709	82.9522516	2026-01-31 19:35:03.163	MOVE	21.72200012207031	0	0	\N	149	2026-01-31 19:49:14.345
150	1	1	55.1069501	82.9522274	2026-01-31 19:35:44.229	MOVE	75.5	0.4599999785423279	283	\N	150	2026-01-31 19:49:14.345
151	1	1	55.1067922	82.9522845	2026-01-31 19:36:03.056	MOVE	42.80799865722656	0	0	\N	151	2026-01-31 19:49:14.345
152	1	1	55.1068007	82.952745	2026-01-31 19:36:45.229	MOVE	232	5.509999752044678	283	\N	152	2026-01-31 19:49:14.345
153	1	1	55.1067976	82.952254	2026-01-31 19:37:03.055	MOVE	41.3380012512207	0	0	\N	153	2026-01-31 19:49:14.345
154	1	1	55.1066537	82.9528102	2026-01-31 19:37:45.234	MOVE	72.5	6.259999752044678	145	\N	154	2026-01-31 19:49:14.345
155	1	1	55.1067744	82.9522673	2026-01-31 19:38:03.39	MOVE	20.33699989318848	0	0	\N	155	2026-01-31 19:49:14.345
156	1	1	55.1066622	82.9524778	2026-01-31 19:39:45.224	MOVE	120.5	4.839999675750732	312	\N	156	2026-01-31 19:49:14.345
157	1	1	55.106795	82.9522392	2026-01-31 19:40:02.579	MOVE	36.99700164794922	0	0	\N	157	2026-01-31 19:49:14.345
158	1	1	55.1067861	82.952384	2026-01-31 19:40:28.141	MOVE	28.67799949645996	1.211562037467957	152.8260955810547	\N	158	2026-01-31 19:49:14.345
159	1	1	55.1067793	82.9522533	2026-01-31 19:40:45.201	MOVE	22.56399917602539	0	0	\N	159	2026-01-31 19:49:14.345
160	1	1	55.1068067	82.9521806	2026-01-31 19:41:03.352	MOVE	37.98799896240234	0	0	\N	160	2026-01-31 19:49:14.345
161	1	1	55.1067825	82.9522791	2026-01-31 19:41:29.14	MOVE	31.97299957275391	0.7278210520744324	240.4758605957031	\N	161	2026-01-31 19:49:14.345
162	1	1	55.1068968	82.9526558	2026-01-31 19:41:45.233	MOVE	173.5	2.190000057220459	270	\N	162	2026-01-31 19:49:14.345
163	1	1	55.1067894	82.9522519	2026-01-31 19:42:03.369	MOVE	20.86899948120117	0	0	\N	163	2026-01-31 19:49:14.345
164	1	1	55.1068485	82.9526727	2026-01-31 19:42:44.229	MOVE	85	8.149999618530273	83	\N	164	2026-01-31 19:49:14.345
165	1	1	55.1067683	82.9522654	2026-01-31 19:43:02.716	MOVE	38.82799911499023	0	0	\N	165	2026-01-31 19:49:14.345
166	1	1	55.1069695	82.9523101	2026-01-31 19:43:44.216	MOVE	168.5	2.440000057220459	262	\N	166	2026-01-31 19:49:14.345
167	1	1	55.1067764	82.9522453	2026-01-31 19:44:01.387	MOVE	22.68400001525879	0	0	\N	167	2026-01-31 19:49:14.345
168	1	1	55.1069178	82.9522793	2026-01-31 19:45:18.252	MOVE	228.5	7.659999847412109	84	\N	168	2026-01-31 19:49:14.345
169	1	1	55.1067984	82.9522335	2026-01-31 19:45:42.181	MOVE	37.17300033569336	0	0	\N	169	2026-01-31 19:49:14.345
170	1	1	55.106896	82.9526594	2026-01-31 19:47:00.227	MOVE	150	1.449999928474426	78	\N	170	2026-01-31 19:49:14.345
171	1	1	55.1067799	82.9522373	2026-01-31 19:47:17.491	MOVE	22.89200019836426	0	0	\N	171	2026-01-31 19:49:14.345
172	1	1	55.1068893	82.9527489	2026-01-31 19:47:44.122	MOVE	47.99200057983398	5.769267082214355	73.23225402832031	\N	172	2026-01-31 19:49:14.345
173	1	1	55.106862	82.9524895	2026-01-31 19:47:59.222	MOVE	101	4	248	\N	173	2026-01-31 19:49:14.345
174	1	1	55.1068013	82.9522353	2026-01-31 19:48:20.381	MOVE	32.04800033569336	0	0	\N	174	2026-01-31 19:49:14.345
175	1	1	55.1068722	82.9525658	2026-01-31 19:49:29.18	MOVE	82.5	4.587444305419922	81.87248229980469	\N	175	2026-01-31 20:49:22.597
176	1	1	55.1067904	82.952314	2026-01-31 19:49:44.107	MOVE	22.26300048828125	1.428903818130493	66.1718521118164	\N	176	2026-01-31 20:49:22.597
177	1	1	55.1069217	82.9526237	2026-01-31 19:49:59.196	MOVE	78.5	2.089999914169312	267	\N	177	2026-01-31 20:49:22.597
178	1	1	55.1067735	82.9522548	2026-01-31 19:50:18.351	MOVE	34.10900115966797	0	0	\N	178	2026-01-31 20:49:22.597
179	1	1	55.1068119	82.9522114	2026-01-31 19:51:43.18	MOVE	38.99900054931641	0.3738274276256561	250.4691925048828	\N	179	2026-01-31 20:49:22.597
180	1	1	55.1068941	82.9529029	2026-01-31 19:51:59.221	MOVE	99.5	1.419999957084656	266	\N	180	2026-01-31 20:49:22.597
181	1	1	55.1067718	82.9522516	2026-01-31 19:52:17.817	MOVE	22.25799942016602	0	0	\N	181	2026-01-31 20:49:22.597
182	1	1	55.1069353	82.9525594	2026-01-31 19:53:59.218	MOVE	68.5	1.899999976158142	49	\N	182	2026-01-31 20:49:22.597
183	1	1	55.1067754	82.9522614	2026-01-31 19:54:17.114	MOVE	20.57099914550781	0	0	\N	183	2026-01-31 20:49:22.597
184	1	1	55.1068124	82.9524657	2026-01-31 19:54:43.095	MOVE	37.27799987792969	1.116198897361755	79.69657897949219	\N	184	2026-01-31 20:49:22.597
185	1	1	55.1069019	82.9520174	2026-01-31 19:54:59.203	MOVE	79	1.319999933242798	259	\N	185	2026-01-31 20:49:22.597
186	1	1	55.1067758	82.9522629	2026-01-31 19:55:17.635	MOVE	20.49900054931641	0	0	\N	186	2026-01-31 20:49:22.597
187	1	1	55.1067858	82.9523636	2026-01-31 19:55:44.187	MOVE	27.01700019836426	0.3681509494781494	178.3578491210938	\N	187	2026-01-31 20:49:22.597
188	1	1	55.1069162	82.951796	2026-01-31 19:55:58.19	MOVE	48	5.876004695892334	271.0030212402344	\N	188	2026-01-31 20:49:22.597
189	1	1	55.106919	82.9515476	2026-01-31 19:56:01.453	MOVE	113.2470016479492	5.844490051269531	271.0083923339844	\N	189	2026-01-31 20:49:22.597
190	1	1	55.1067712	82.9522524	2026-01-31 19:56:25.084	MOVE	20.99600028991699	0	0	\N	190	2026-01-31 20:49:22.597
191	1	1	55.1067843	82.9521572	2026-01-31 19:57:12.77	MOVE	23.67799949645996	3.918256282806396	260.3797607421875	\N	191	2026-01-31 20:49:22.597
192	1	1	55.1068414	82.95231	2026-01-31 19:57:29.203	MOVE	50.5	0.3499999940395355	90	\N	192	2026-01-31 20:49:22.597
193	1	1	55.1067879	82.9522572	2026-01-31 19:57:55.093	MOVE	22.26300048828125	0	0	\N	193	2026-01-31 20:49:22.597
194	1	1	55.1068229	82.9524459	2026-01-31 19:58:59.201	MOVE	67	1.02417266368866	252.9115753173828	\N	194	2026-01-31 20:49:22.597
195	1	1	55.1067863	82.9522489	2026-01-31 19:59:25.117	MOVE	18.93099975585938	0	0	\N	195	2026-01-31 20:49:22.597
196	1	1	55.1069269	82.9523828	2026-01-31 19:59:59.351	MOVE	60.5	0.1599999964237213	140	\N	196	2026-01-31 20:49:22.597
197	1	1	55.1067839	82.9522373	2026-01-31 20:00:25.077	MOVE	42.72600173950195	0	0	\N	197	2026-01-31 20:49:22.597
198	1	1	55.1069219	82.9518779	2026-01-31 20:00:59.195	MOVE	59.5	0.03999999910593033	0	\N	198	2026-01-31 20:49:22.597
199	1	1	55.1067832	82.9522446	2026-01-31 20:01:18.325	MOVE	21.66799926757812	0	0	\N	199	2026-01-31 20:49:22.597
200	1	1	55.1068261	82.9523451	2026-01-31 20:02:11.868	MOVE	21.5359992980957	1.471130132675171	55.39438247680664	\N	200	2026-01-31 20:49:22.597
201	1	1	55.106943	82.9526956	2026-01-31 20:02:29.203	MOVE	90	1.519999980926514	260	\N	201	2026-01-31 20:49:22.597
202	1	1	55.1068022	82.9522333	2026-01-31 20:02:53.254	MOVE	38.94100189208984	0	0	\N	202	2026-01-31 20:49:22.597
203	1	1	55.1068123	82.9523965	2026-01-31 20:03:43.094	MOVE	37.83399963378906	1.115727186203003	93.457275390625	\N	203	2026-01-31 20:49:22.597
204	1	1	55.1069524	82.9533896	2026-01-31 20:04:25.391	MOVE	45.75	3.23774528503418	83.04176330566406	\N	204	2026-01-31 20:49:22.597
205	1	1	55.1067842	82.9522906	2026-01-31 20:04:43.02	MOVE	32.80300140380859	0	0	\N	205	2026-01-31 20:49:22.597
206	1	1	55.1068623	82.9523635	2026-01-31 20:04:59.187	MOVE	72	0.5099999904632568	106	\N	206	2026-01-31 20:49:22.597
207	1	1	55.1067912	82.9522449	2026-01-31 20:05:17.415	MOVE	37.15599822998047	0	0	\N	207	2026-01-31 20:49:22.597
208	1	1	55.1068761	82.9524455	2026-01-31 20:06:29.186	MOVE	57.5	0.429999977350235	259	\N	208	2026-01-31 20:49:22.597
209	1	1	55.1067716	82.9522451	2026-01-31 20:06:47.249	MOVE	21.61599922180176	0	0	\N	209	2026-01-31 20:49:22.597
210	1	1	55.1068312	82.9521452	2026-01-31 20:07:12.22	MOVE	42.82199859619141	1.00437343120575	107.6745223999023	\N	210	2026-01-31 20:49:22.597
211	1	1	55.1067809	82.9522503	2026-01-31 20:07:41.192	MOVE	40.52199935913086	0	0	\N	211	2026-01-31 20:49:22.597
212	1	1	55.1070383	82.9522183	2026-01-31 20:07:55.33	MOVE	48.5	1.627725124359131	301.0705261230469	\N	212	2026-01-31 20:49:22.597
213	1	1	55.1071123	82.9520761	2026-01-31 20:08:02.498	MOVE	172.4869995117188	1.315057277679443	303.910400390625	\N	213	2026-01-31 20:49:22.597
214	1	1	55.1067824	82.9522706	2026-01-31 20:08:23.133	MOVE	21.76899909973145	0	0	\N	214	2026-01-31 20:49:22.597
215	1	1	55.1068303	82.9521651	2026-01-31 20:09:13.069	MOVE	21.27000045776367	4.794684886932373	312.1956481933594	\N	215	2026-01-31 20:49:22.597
216	1	1	55.1067645	82.9527178	2026-01-31 20:09:29.175	MOVE	68.5	1.490000009536743	344	\N	216	2026-01-31 20:49:22.597
217	1	1	55.1067829	82.952333	2026-01-31 20:09:52.338	MOVE	31.27099990844727	0	0	\N	217	2026-01-31 20:49:22.597
218	1	1	55.1067831	82.9522303	2026-01-31 20:10:13.445	MOVE	20.94300079345703	0.7738791704177856	254.7453918457031	\N	218	2026-01-31 20:49:22.597
219	1	1	55.1069291	82.9518337	2026-01-31 20:10:29.18	MOVE	52.5	2.690000057220459	9	\N	219	2026-01-31 20:49:22.597
220	1	1	55.106807	82.9520747	2026-01-31 20:10:47.676	MOVE	47.30099868774414	0	0	\N	220	2026-01-31 20:49:22.597
221	1	1	55.1067756	82.9522594	2026-01-31 20:11:15.034	MOVE	22.02799987792969	0	0	\N	221	2026-01-31 20:49:22.597
222	1	1	55.1068715	82.9521065	2026-01-31 20:11:29.321	MOVE	56	1.875422120094299	279.0238952636719	\N	222	2026-01-31 20:49:22.597
223	1	1	55.1068527	82.9524167	2026-01-31 20:11:52.376	MOVE	49	0.8969982266426086	288.0661010742188	\N	223	2026-01-31 20:49:22.597
224	1	1	55.1068468	82.9523031	2026-01-31 20:11:56.517	MOVE	54.83700180053711	0.2153297364711761	285.6163940429688	\N	224	2026-01-31 20:49:22.597
225	1	1	55.1068014	82.9522833	2026-01-31 20:12:23.097	MOVE	21.44700050354004	0	0	\N	225	2026-01-31 20:49:22.597
226	1	1	55.1069621	82.9522315	2026-01-31 20:12:59.188	MOVE	57.5	2.190000057220459	82	\N	226	2026-01-31 20:49:22.597
227	1	1	55.1067709	82.9522515	2026-01-31 20:13:23.125	MOVE	22.19700050354004	0	0	\N	227	2026-01-31 20:49:22.597
228	1	1	55.1068175	82.9522322	2026-01-31 20:14:42.147	MOVE	34.90999984741211	1.177339553833008	299.2871704101562	\N	228	2026-01-31 20:49:22.597
229	1	1	55.1068687	82.9521768	2026-01-31 20:15:03.143	MOVE	194.7539978027344	1.367183804512024	271.0213928222656	\N	229	2026-01-31 20:49:22.597
230	1	1	55.1067823	82.9522086	2026-01-31 20:15:24.314	MOVE	35.93500137329102	0	0	\N	230	2026-01-31 20:49:22.597
231	1	1	55.1068077	82.9525849	2026-01-31 20:16:29.352	MOVE	84	0.5276336669921875	153.687255859375	\N	231	2026-01-31 20:49:22.597
232	1	1	55.1067825	82.9523448	2026-01-31 20:16:44.107	MOVE	36.90200042724609	0.4234292507171631	164.4731597900391	\N	232	2026-01-31 20:49:22.597
233	1	1	55.1069147	82.9527014	2026-01-31 20:16:59.144	MOVE	80.5	0.550000011920929	233	\N	233	2026-01-31 20:49:22.597
234	1	1	55.1067889	82.9522708	2026-01-31 20:17:14.053	MOVE	34.82899856567383	0.6841033101081848	237.3109588623047	\N	234	2026-01-31 20:49:22.597
235	1	1	55.1068342	82.9528421	2026-01-31 20:17:29.346	MOVE	73.5	0.5999999642372131	110	\N	235	2026-01-31 20:49:22.597
236	1	1	55.1067916	82.9523166	2026-01-31 20:17:43.085	MOVE	27.47400093078613	0.2791429460048676	138.3221893310547	\N	236	2026-01-31 20:49:22.597
237	1	1	55.10705	82.9517424	2026-01-31 20:17:59.159	MOVE	63.5	1.709999918937683	280	\N	237	2026-01-31 20:49:22.597
238	1	1	55.106853	82.9524625	2026-01-31 20:18:25.141	MOVE	46.5	8.260000228881836	99	\N	238	2026-01-31 20:49:22.597
239	1	1	55.1067823	82.9523076	2026-01-31 20:18:44.967	MOVE	31.78000068664551	0	0	\N	239	2026-01-31 20:49:22.597
240	1	1	55.1069047	82.9526592	2026-01-31 20:18:59.306	MOVE	57	0.06263799965381622	0	\N	240	2026-01-31 20:49:22.597
241	1	1	55.1068465	82.9528262	2026-01-31 20:19:21.33	MOVE	46	3	73	\N	241	2026-01-31 20:49:22.597
242	1	1	55.1067851	82.9522607	2026-01-31 20:19:53.073	MOVE	40.35699844360352	0	0	\N	242	2026-01-31 20:49:22.597
243	1	1	55.1068744	82.951791	2026-01-31 20:21:13.091	MOVE	36.61100006103516	9.953685760498047	283.5340881347656	\N	243	2026-01-31 20:49:22.597
244	1	1	55.1070239	82.9521596	2026-01-31 20:21:29.143	MOVE	150.5	0.5600000023841858	88	\N	244	2026-01-31 20:49:22.597
245	1	1	55.1067733	82.9522511	2026-01-31 20:21:47.449	MOVE	21.90900039672852	0	0	\N	245	2026-01-31 20:49:22.597
246	1	1	55.106904	82.9526329	2026-01-31 20:22:29.125	MOVE	66	1.009999990463257	261	\N	246	2026-01-31 20:49:22.597
247	1	1	55.1067872	82.9522884	2026-01-31 20:22:46.086	MOVE	36.47800064086914	0	0	\N	247	2026-01-31 20:49:22.597
248	1	1	55.1068944	82.9524067	2026-01-31 20:23:03.196	MOVE	148.9859924316406	0.5349803566932678	260.9423828125	\N	248	2026-01-31 20:49:22.597
249	1	1	55.1068097	82.9522218	2026-01-31 20:23:20.321	MOVE	39.57500076293945	0	0	\N	249	2026-01-31 20:49:22.597
250	1	1	55.1067848	82.9523608	2026-01-31 20:23:54.588	MOVE	29.29999923706055	0	0	\N	250	2026-01-31 20:49:22.597
251	1	1	55.1067687	82.9522555	2026-01-31 20:24:28.851	MOVE	22.01300048828125	0	0	\N	251	2026-01-31 20:49:22.597
252	1	1	55.1068698	82.9525845	2026-01-31 20:25:03.063	MOVE	149.8309936523438	0.2749110162258148	238.6690368652344	\N	252	2026-01-31 20:49:22.597
253	1	1	55.1067677	82.9522673	2026-01-31 20:25:20.167	MOVE	36.9739990234375	0	0	\N	253	2026-01-31 20:49:22.597
254	1	1	55.106805	82.9524731	2026-01-31 20:25:37.307	MOVE	32.2859992980957	1.687585949897766	88.7199478149414	\N	254	2026-01-31 20:49:22.597
255	1	1	55.1067747	82.9522583	2026-01-31 20:25:54.453	MOVE	31.20800018310547	0	0	\N	255	2026-01-31 20:49:22.597
256	1	1	55.106907	82.9527445	2026-01-31 20:26:59.155	MOVE	128	2.859999895095825	276	\N	256	2026-01-31 20:49:22.597
257	1	1	55.106769	82.952253	2026-01-31 20:27:17.399	MOVE	22.30299949645996	0	0	\N	257	2026-01-31 20:49:22.597
258	1	1	55.1067854	82.9523394	2026-01-31 20:27:44.006	MOVE	33.19699859619141	0.6611502170562744	115.1650161743164	\N	258	2026-01-31 20:49:22.597
259	1	1	55.1068719	82.9526985	2026-01-31 20:27:59.286	MOVE	84	1.610000014305115	82	\N	259	2026-01-31 20:49:22.597
260	1	1	55.1067951	82.9522921	2026-01-31 20:28:24.203	MOVE	27.35600090026855	0	0	\N	260	2026-01-31 20:49:22.597
261	1	1	55.1068285	82.9522309	2026-01-31 20:30:00.289	MOVE	68.447998046875	0.9994944930076599	280.0047302246094	\N	261	2026-01-31 20:49:22.597
262	1	1	55.1067759	82.9522547	2026-01-31 20:30:25.2	MOVE	22.13599967956543	0	0	\N	262	2026-01-31 20:49:22.597
263	1	1	55.1068935	82.952487	2026-01-31 20:31:06.314	MOVE	222.72900390625	1.703203082084656	92.00617980957031	\N	263	2026-01-31 20:49:22.597
264	1	1	55.1067721	82.9522568	2026-01-31 20:31:25.241	MOVE	21.7450008392334	0	0	\N	264	2026-01-31 20:49:22.597
265	1	1	55.1067819	82.9521701	2026-01-31 20:32:41.109	MOVE	23.07999992370605	3.710431098937988	262.6717834472656	\N	265	2026-01-31 20:49:22.597
266	1	1	55.1067893	82.9522646	2026-01-31 20:32:58.279	MOVE	33.14199829101562	0	0	\N	266	2026-01-31 20:49:22.597
267	1	1	55.1067971	82.9525654	2026-01-31 20:33:29.295	MOVE	69.5	0.8545770645141602	258.9325866699219	\N	267	2026-01-31 20:49:22.597
268	1	1	55.1067976	82.9522602	2026-01-31 20:33:41.983	MOVE	37.5629997253418	0.9456618428230286	260.1221313476562	\N	268	2026-01-31 20:49:22.597
269	1	1	55.1069641	82.9521536	2026-01-31 20:34:44.122	MOVE	170	1.5	65	\N	269	2026-01-31 20:49:22.597
270	1	1	55.1067922	82.9521873	2026-01-31 20:35:02.431	MOVE	38.54499816894531	0	0	\N	270	2026-01-31 20:49:22.597
271	1	1	55.1068753	82.9520183	2026-01-31 20:35:44.119	MOVE	68	4.059999942779541	267	\N	271	2026-01-31 20:49:22.597
272	1	1	55.1067823	82.9522249	2026-01-31 20:36:02.456	MOVE	23.52000045776367	0	0	\N	272	2026-01-31 20:49:22.597
273	1	1	55.1068941	82.9518556	2026-01-31 20:36:44.141	MOVE	70	5.329999923706055	278	\N	273	2026-01-31 20:49:22.597
274	1	1	55.1067744	82.9522403	2026-01-31 20:37:02.294	MOVE	35.70500183105469	0	0	\N	274	2026-01-31 20:49:22.597
275	1	1	55.1067936	82.9523175	2026-01-31 20:39:16.271	MOVE	249	0.3078335523605347	64.77597045898438	\N	275	2026-01-31 20:49:22.597
276	1	1	55.106838	82.9524822	2026-01-31 20:39:23.764	MOVE	398.8460083007812	1.374834775924683	64.77597045898438	\N	276	2026-01-31 20:49:22.597
277	1	1	55.106792	82.9521772	2026-01-31 20:39:41.263	MOVE	48.88100051879883	0	0	\N	277	2026-01-31 20:49:22.597
278	1	1	55.1067771	82.9522547	2026-01-31 20:39:58.937	MOVE	20.88699913024902	0.5159613490104675	272.5592346191406	\N	278	2026-01-31 20:49:22.597
279	1	1	55.1069111	82.9527602	2026-01-31 20:40:59.127	MOVE	48.5	4.809999942779541	81	\N	279	2026-01-31 20:49:22.597
280	1	1	55.1067826	82.9522352	2026-01-31 20:41:17.182	MOVE	21.70899963378906	0	0	\N	280	2026-01-31 20:49:22.597
281	1	1	55.1068019	82.952384	2026-01-31 20:41:31.118	MOVE	197	7.190710067749023	101.0550765991211	\N	281	2026-01-31 20:49:22.597
282	1	1	55.1067752	82.9522963	2026-01-31 20:41:42.163	MOVE	42.29999923706055	2.107070922851562	121.8306121826172	\N	282	2026-01-31 20:49:22.597
283	1	1	55.107019	82.952054	2026-01-31 20:41:59.126	MOVE	115.5	0.9099999666213989	295	\N	283	2026-01-31 20:49:22.597
284	1	1	55.1067837	82.9522231	2026-01-31 20:42:17.243	MOVE	29.04500007629395	0	0	\N	284	2026-01-31 20:49:22.597
285	1	1	55.1069806	82.9526138	2026-01-31 20:42:59.111	MOVE	109.5	3.509999990463257	272	\N	285	2026-01-31 20:49:22.597
286	1	1	55.1067941	82.9522793	2026-01-31 20:43:16.405	MOVE	34.45500183105469	0	0	\N	286	2026-01-31 20:49:22.597
287	1	1	55.1068706	82.9520077	2026-01-31 20:44:41.579	MOVE	40.29399871826172	3.710165500640869	276.90576171875	\N	287	2026-01-31 20:49:22.597
288	1	1	55.1069182	82.952708	2026-01-31 20:44:59.118	MOVE	132	1.679999947547913	302	\N	288	2026-01-31 20:49:22.597
289	1	1	55.1067936	82.952268	2026-01-31 20:45:16.334	MOVE	30.28899955749512	0	0	\N	289	2026-01-31 20:49:22.597
290	1	1	55.1069531	82.952576	2026-01-31 20:45:59.106	MOVE	218	2.240000009536743	305	\N	290	2026-01-31 20:49:22.597
291	1	1	55.1067686	82.9522533	2026-01-31 20:46:16.457	MOVE	21.63999938964844	0	0	\N	291	2026-01-31 20:49:22.597
292	1	1	55.1070504	82.9518829	2026-01-31 20:46:34.107	MOVE	154.5	1.100000023841858	93	\N	292	2026-01-31 20:49:22.597
293	1	1	55.1067746	82.9522589	2026-01-31 20:47:00.169	MOVE	20.9950008392334	0	0	\N	293	2026-01-31 20:49:22.597
294	1	1	55.1068622	82.9524319	2026-01-31 20:47:14.102	MOVE	144	4.031574726104736	95.0305404663086	\N	294	2026-01-31 20:49:22.597
295	1	1	55.1067762	82.9522811	2026-01-31 20:47:27.681	MOVE	21.32799911499023	2.968671321868896	96.92539978027344	\N	295	2026-01-31 20:49:22.597
296	1	1	55.1067903	82.952197	2026-01-31 20:47:44.938	MOVE	39.05300140380859	0	0	\N	296	2026-01-31 20:49:22.597
297	1	1	55.1068421	82.9527637	2026-01-31 20:48:44.114	MOVE	176.5	2.759999990463257	91	\N	297	2026-01-31 20:49:22.597
298	1	1	55.1067809	82.9522502	2026-01-31 20:49:01.862	MOVE	21.67099952697754	0	0	\N	298	2026-01-31 20:49:22.597
299	1	1	55.1068685	82.9527054	2026-01-31 20:50:14.098	MOVE	59.5	4.995705604553223	104.0338745117188	\N	299	2026-01-31 22:50:09.841
300	1	1	55.1068372	82.9529425	2026-01-31 20:50:17.382	MOVE	190.7989959716797	4.989573955535889	104.0475845336914	\N	300	2026-01-31 22:50:09.841
301	1	1	55.1067846	82.9522387	2026-01-31 20:50:39.517	MOVE	22.79299926757812	0	0	\N	301	2026-01-31 22:50:09.841
302	1	1	55.1068641	82.9523218	2026-01-31 20:51:14.092	MOVE	134	1.629999995231628	275	\N	302	2026-01-31 22:50:09.841
303	1	1	55.1067736	82.9522429	2026-01-31 20:51:32.238	MOVE	22.57099914550781	0	0	\N	303	2026-01-31 22:50:09.841
304	1	1	55.1069924	82.9518574	2026-01-31 20:53:15.075	MOVE	142	3.349999904632568	289	\N	304	2026-01-31 22:50:09.841
305	1	1	55.1067926	82.9521944	2026-01-31 20:53:32.254	MOVE	25.89599990844727	0	0	\N	305	2026-01-31 22:50:09.841
306	1	1	55.1069092	82.9521178	2026-01-31 20:53:49.279	MOVE	245.4819946289062	3.716026067733765	298.0932922363281	\N	306	2026-01-31 22:50:09.841
307	1	1	55.1067606	82.9522537	2026-01-31 20:54:06.351	MOVE	23.91699981689453	0	0	\N	307	2026-01-31 22:50:09.841
308	1	1	55.1067036	82.9523436	2026-01-31 20:54:25.266	MOVE	87	3.835837841033936	133.5947570800781	\N	308	2026-01-31 22:50:09.841
309	1	1	55.1067543	82.9522597	2026-01-31 20:54:42.884	MOVE	36.85400009155273	0	0	\N	309	2026-01-31 22:50:09.841
310	1	1	55.1069084	82.9523853	2026-01-31 20:56:00.084	MOVE	156	0.8199999928474426	288	\N	310	2026-01-31 22:50:09.841
311	1	1	55.1067738	82.952248	2026-01-31 20:56:17.223	MOVE	22.77799987792969	0	0	\N	311	2026-01-31 22:50:09.841
312	1	1	55.1067654	82.9528375	2026-01-31 20:56:59.101	MOVE	133.5	2.269999980926514	108	\N	312	2026-01-31 22:50:09.841
313	1	1	55.1067884	82.9522642	2026-01-31 20:57:16.456	MOVE	38.98699951171875	0	0	\N	313	2026-01-31 22:50:09.841
314	1	1	55.1068479	82.9530469	2026-01-31 20:57:59.077	MOVE	162.5	0	0	\N	314	2026-01-31 22:50:09.841
315	1	1	55.1067746	82.9522448	2026-01-31 20:58:17.227	MOVE	22.76499938964844	0	0	\N	315	2026-01-31 22:50:09.841
316	1	1	55.1067368	82.9529561	2026-01-31 20:59:20.097	MOVE	46	15.11999988555908	119	\N	316	2026-01-31 22:50:09.841
317	1	1	55.1067877	82.9523244	2026-01-31 20:59:42.137	MOVE	31.69400024414062	0	0	\N	317	2026-01-31 22:50:09.841
318	1	1	55.1069613	82.9520667	2026-01-31 20:59:59.091	MOVE	93.5	2.359999895095825	270	\N	318	2026-01-31 22:50:09.841
319	1	1	55.1067771	82.9522982	2026-01-31 21:00:16.735	MOVE	31.49300003051758	0	0	\N	319	2026-01-31 22:50:09.841
320	1	1	55.1068363	82.9521113	2026-01-31 21:00:42.181	MOVE	52.35599899291992	0.4308586418628693	265.7720947265625	\N	320	2026-01-31 22:50:09.841
321	1	1	55.107052	82.9517834	2026-01-31 21:00:59.082	MOVE	97.5	2.730000019073486	101	\N	321	2026-01-31 22:50:09.841
322	1	1	55.1068245	82.9520945	2026-01-31 21:01:17.22	MOVE	56.02199935913086	0	0	\N	322	2026-01-31 22:50:09.841
323	1	1	55.1067805	82.9522191	2026-01-31 21:01:43.221	MOVE	23.05999946594238	0.5907383561134338	75.83576202392578	\N	323	2026-01-31 22:50:09.841
324	1	1	55.1068726	82.9523443	2026-01-31 21:01:59.078	MOVE	92	2.210000038146973	279	\N	324	2026-01-31 22:50:09.841
325	1	1	55.1068583	82.9525085	2026-01-31 21:02:25.047	MOVE	49.5	12.26999950408936	83	\N	325	2026-01-31 22:50:09.841
326	1	1	55.1067896	82.9522614	2026-01-31 21:02:43.499	MOVE	40.75199890136719	0	0	\N	326	2026-01-31 22:50:09.841
327	1	1	55.1068908	82.9520345	2026-01-31 21:03:29.091	MOVE	124.5	0.9099999666213989	125	\N	327	2026-01-31 22:50:09.841
328	1	1	55.1067816	82.9522477	2026-01-31 21:03:47.204	MOVE	44.29800033569336	0	0	\N	328	2026-01-31 22:50:09.841
329	1	1	55.1068233	82.9521544	2026-01-31 21:04:18.085	MOVE	248.5	1.72874927520752	300.013427734375	\N	329	2026-01-31 22:50:09.841
330	1	1	55.1067837	82.9522707	2026-01-31 21:04:45.961	MOVE	35.37200164794922	0	0	\N	330	2026-01-31 22:50:09.841
331	1	1	55.1068512	82.9523613	2026-01-31 21:05:00.089	MOVE	103.5	1.358542919158936	261.9388732910156	\N	331	2026-01-31 22:50:09.841
332	1	1	55.1067944	82.9522383	2026-01-31 21:05:12.064	MOVE	23.83399963378906	1.22563910484314	260.9055786132812	\N	332	2026-01-31 22:50:09.841
333	1	1	55.1065949	82.9479523	2026-01-31 21:06:01.24	MOVE	200.5	0	0	\N	333	2026-01-31 22:50:09.841
334	1	1	55.1067707	82.9522622	2026-01-31 21:06:25.584	MOVE	22.58600044250488	0	0	\N	334	2026-01-31 22:50:09.841
335	1	1	55.1068904	82.9522219	2026-01-31 21:07:00.081	MOVE	104	6.639999866485596	88	\N	335	2026-01-31 22:50:09.841
336	1	1	55.1067755	82.9522504	2026-01-31 21:07:18.524	MOVE	23.42700004577637	0	0	\N	336	2026-01-31 22:50:09.841
337	1	1	55.106762	82.9519487	2026-01-31 21:08:01.07	MOVE	184.5	0.3618844747543335	275.2065734863281	\N	337	2026-01-31 22:50:09.841
338	1	1	55.1067734	82.9522766	2026-01-31 21:08:16.37	MOVE	32.22800064086914	0	0	\N	338	2026-01-31 22:50:09.841
339	1	1	55.1068739	82.9519979	2026-01-31 21:08:59.094	MOVE	155.5	1.129999995231628	237	\N	339	2026-01-31 22:50:09.841
340	1	1	55.1067884	82.9522495	2026-01-31 21:09:17.235	MOVE	38.06800079345703	0	0	\N	340	2026-01-31 22:50:09.841
341	1	1	55.1069216	82.9519848	2026-01-31 21:10:14.069	MOVE	76	0.8899999856948853	285	\N	341	2026-01-31 22:50:09.841
342	1	1	55.1067848	82.9522319	2026-01-31 21:10:32.373	MOVE	23.86700057983398	0	0	\N	342	2026-01-31 22:50:09.841
343	1	1	55.1069298	82.9525905	2026-01-31 21:10:48.047	MOVE	187.5	4.299999713897705	93	\N	343	2026-01-31 22:50:09.841
344	1	1	55.1067581	82.9522659	2026-01-31 21:11:12.043	MOVE	48.03300094604492	0	0	\N	344	2026-01-31 22:50:09.841
345	1	1	55.1070231	82.9511084	2026-01-31 21:11:29.063	MOVE	151.5	0	0	\N	345	2026-01-31 22:50:09.841
346	1	1	55.1067719	82.9522554	2026-01-31 21:11:50.073	MOVE	22.02700042724609	0	0	\N	346	2026-01-31 22:50:09.841
347	1	1	55.1068625	82.9517113	2026-01-31 21:13:29.06	MOVE	138.5	1.71999990940094	113	\N	347	2026-01-31 22:50:09.841
348	1	1	55.1067892	82.95234	2026-01-31 21:13:47.142	MOVE	30.51199913024902	0	0	\N	348	2026-01-31 22:50:09.841
349	1	1	55.1069083	82.9524055	2026-01-31 21:14:29.068	MOVE	101.5	5.279999732971191	298	\N	349	2026-01-31 22:50:09.841
350	1	1	55.1067573	82.9522908	2026-01-31 21:14:46.27	MOVE	40.58700180053711	0	0	\N	350	2026-01-31 22:50:09.841
351	1	1	55.1069688	82.9520641	2026-01-31 21:15:29.079	MOVE	59.5	0.1599999964237213	7	\N	351	2026-01-31 22:50:09.841
352	1	1	55.1067891	82.9523263	2026-01-31 21:15:53.956	MOVE	30.21299934387207	0	0	\N	352	2026-01-31 22:50:09.841
353	1	1	55.106742	82.9523335	2026-01-31 21:16:13.316	MOVE	43.63700103759766	0.3515543937683105	143.4240112304688	\N	353	2026-01-31 22:50:09.841
354	1	1	55.1069302	82.9511784	2026-01-31 21:16:29.202	MOVE	115.5	0	0	\N	354	2026-01-31 22:50:09.841
355	1	1	55.1067705	82.9522556	2026-01-31 21:16:48.283	MOVE	22.29800033569336	0	0	\N	355	2026-01-31 22:50:09.841
356	1	1	55.106939	82.9519637	2026-01-31 21:17:29.059	MOVE	104	1.429999947547913	261	\N	356	2026-01-31 22:50:09.841
357	1	1	55.1067689	82.9522691	2026-01-31 21:17:46.444	MOVE	20.89900016784668	0	0	\N	357	2026-01-31 22:50:09.841
358	1	1	55.1067925	82.9521832	2026-01-31 21:18:12.016	MOVE	25.95899963378906	1.910335302352905	286.7178344726562	\N	358	2026-01-31 22:50:09.841
359	1	1	55.1071783	82.9498887	2026-01-31 21:18:29.047	MOVE	143.5	0	0	\N	359	2026-01-31 22:50:09.841
360	1	1	55.1067786	82.952262	2026-01-31 21:18:46.196	MOVE	19.26000022888184	0	0	\N	360	2026-01-31 22:50:09.841
361	1	1	55.1069224	82.9515628	2026-01-31 21:19:30.056	MOVE	184.5	0	0	\N	361	2026-01-31 22:50:09.841
362	1	1	55.1067702	82.9522489	2026-01-31 21:19:47.402	MOVE	33.5629997253418	0	0	\N	362	2026-01-31 22:50:09.841
363	1	1	55.1067736	82.9521669	2026-01-31 21:20:12.098	MOVE	26.53300094604492	2.834284067153931	264.6310424804688	\N	363	2026-01-31 22:50:09.841
364	1	1	55.1069071	82.9524141	2026-01-31 21:20:29.049	MOVE	79.5	2.139999866485596	89	\N	364	2026-01-31 22:50:09.841
365	1	1	55.1067712	82.9522562	2026-01-31 21:20:47.174	MOVE	31.91300010681152	0	0	\N	365	2026-01-31 22:50:09.841
366	1	1	55.1068313	82.9525646	2026-01-31 21:21:11.998	MOVE	41.02999877929688	2.89188289642334	78.20439147949219	\N	366	2026-01-31 22:50:09.841
367	1	1	55.1068409	82.9522299	2026-01-31 21:21:29.047	MOVE	56	2.009999990463257	246	\N	367	2026-01-31 22:50:09.841
368	1	1	55.1067705	82.9522333	2026-01-31 21:21:54.556	MOVE	33.26599884033203	0	0	\N	368	2026-01-31 22:50:09.841
369	1	1	55.1068583	82.9527048	2026-01-31 21:22:29.143	MOVE	98	3.973542451858521	179.8062896728516	\N	369	2026-01-31 22:50:09.841
370	1	1	55.1068055	82.9527683	2026-01-31 21:22:31.67	MOVE	148.5350036621094	3.965963840484619	177.4762573242188	\N	370	2026-01-31 22:50:09.841
371	1	1	55.1067691	82.9522317	2026-01-31 21:22:53.844	MOVE	32.61600112915039	0	0	\N	371	2026-01-31 22:50:09.841
372	1	1	55.1068721	82.9520891	2026-01-31 21:23:59.037	MOVE	54	0.8799999952316284	79	\N	372	2026-01-31 22:50:09.841
373	1	1	55.1067687	82.952229	2026-01-31 21:24:24.27	MOVE	33.12300109863281	0	0	\N	373	2026-01-31 22:50:09.841
374	1	1	55.1067502	82.9526948	2026-01-31 21:24:59.039	MOVE	176.5	0	0	\N	374	2026-01-31 22:50:09.841
375	1	1	55.1067623	82.9522283	2026-01-31 21:25:12.637	MOVE	32.31600189208984	0.2769454121589661	272.6060485839844	\N	375	2026-01-31 22:50:09.841
376	1	1	55.1068154	82.9531419	2026-01-31 21:25:29.035	MOVE	67	2.25	257	\N	376	2026-01-31 22:50:09.841
377	1	1	55.1067678	82.9522211	2026-01-31 21:25:47.228	MOVE	32.8380012512207	0	0	\N	377	2026-01-31 22:50:09.841
378	1	1	55.1068367	82.9523493	2026-01-31 21:26:29.055	MOVE	104.5	0.7799999713897705	43	\N	378	2026-01-31 22:50:09.841
379	1	1	55.1067749	82.9522627	2026-01-31 21:26:46.271	MOVE	17.76600074768066	0	0	\N	379	2026-01-31 22:50:09.841
380	1	1	55.1069151	82.9520776	2026-01-31 21:27:29.065	MOVE	141.5	2.970000028610229	292	\N	380	2026-01-31 22:50:09.841
381	1	1	55.1067629	82.9522724	2026-01-31 21:27:46.237	MOVE	21.5049991607666	0	0	\N	381	2026-01-31 22:50:09.841
382	1	1	55.1068624	82.952681	2026-01-31 21:28:03.368	MOVE	142.2330017089844	0.2405522912740707	162.8533172607422	\N	382	2026-01-31 22:50:09.841
383	1	1	55.1067777	82.9522237	2026-01-31 21:28:20.461	MOVE	24.90999984741211	0	0	\N	383	2026-01-31 22:50:09.841
384	1	1	55.1068882	82.9520354	2026-01-31 21:28:37.585	MOVE	36.86199951171875	3.024530172348022	282.1612854003906	\N	384	2026-01-31 22:50:09.841
385	1	1	55.1067755	82.9522541	2026-01-31 21:28:54.684	MOVE	34.14799880981445	0	0	\N	385	2026-01-31 22:50:09.841
386	1	1	55.1067913	82.9523387	2026-01-31 21:29:12.718	MOVE	37.86100006103516	0.7776498794555664	96.59622955322266	\N	386	2026-01-31 22:50:09.841
387	1	1	55.1069233	82.9520574	2026-01-31 21:29:29.04	MOVE	84	1.199999928474426	289	\N	387	2026-01-31 22:50:09.841
388	1	1	55.1067831	82.9522575	2026-01-31 21:29:46.863	MOVE	19.23200035095215	0	0	\N	388	2026-01-31 22:50:09.841
389	1	1	55.1068217	82.9531753	2026-01-31 21:29:55.038	MOVE	34	6.382963180541992	97.9723129272461	\N	389	2026-01-31 22:50:09.841
390	1	1	55.1068078	82.9521968	2026-01-31 21:30:12.088	MOVE	39.54000091552734	0	0	\N	390	2026-01-31 22:50:09.841
391	1	1	55.1067955	82.9524266	2026-01-31 21:30:29.056	MOVE	68.5	0.6100000143051147	248	\N	391	2026-01-31 22:50:09.841
392	1	1	55.1067779	82.9522457	2026-01-31 21:30:52.333	MOVE	24.83499908447266	0	0	\N	392	2026-01-31 22:50:09.841
393	1	1	55.1068293	82.9521652	2026-01-31 21:31:30.749	MOVE	39.19800186157227	0	0	\N	393	2026-01-31 22:50:09.841
394	1	1	55.1067695	82.952243	2026-01-31 21:32:12.138	MOVE	23.86700057983398	1.168464183807373	275.6223754882812	\N	394	2026-01-31 22:50:09.841
395	1	1	55.106823	82.9527704	2026-01-31 21:32:29.034	MOVE	75.5	4.579999923706055	115	\N	395	2026-01-31 22:50:09.841
396	1	1	55.1067721	82.9522538	2026-01-31 21:32:46.297	MOVE	24.65999984741211	0	0	\N	396	2026-01-31 22:50:09.841
397	1	1	55.1069199	82.9524022	2026-01-31 21:33:03.443	MOVE	139.8950042724609	0.3626612424850464	281.6491394042969	\N	397	2026-01-31 22:50:09.841
398	1	1	55.1067764	82.9522675	2026-01-31 21:33:22.136	MOVE	32.86399841308594	0	0	\N	398	2026-01-31 22:50:09.841
399	1	1	55.1069393	82.9521247	2026-01-31 21:33:59.049	MOVE	75.5	2.230000019073486	307	\N	399	2026-01-31 22:50:09.841
400	1	1	55.1067854	82.9522272	2026-01-31 21:34:23.92	MOVE	24.62899971008301	0	0	\N	400	2026-01-31 22:50:09.841
401	1	1	55.1068396	82.9521407	2026-01-31 21:34:42.965	MOVE	45.84700012207031	1.316002488136292	298.7369689941406	\N	401	2026-01-31 22:50:09.841
402	1	1	55.1067698	82.9522992	2026-01-31 21:34:59.18	MOVE	76.5	0.1299999952316284	259	\N	402	2026-01-31 22:50:09.841
403	1	1	55.1068211	82.9521782	2026-01-31 21:35:23.982	MOVE	38.67200088500977	0	0	\N	403	2026-01-31 22:50:09.841
404	1	1	55.1067828	82.9522483	2026-01-31 21:35:45.19	MOVE	35.57400131225586	0	0	\N	404	2026-01-31 22:50:09.841
405	1	1	55.1065368	82.9546361	2026-01-31 21:36:01.219	MOVE	225.5	0	0	\N	405	2026-01-31 22:50:09.841
406	1	1	55.1068211	82.952189	2026-01-31 21:36:20.479	MOVE	45.95500183105469	0	0	\N	406	2026-01-31 22:50:09.841
407	1	1	55.1067917	82.9520545	2026-01-31 21:36:35.179	MOVE	241	0.4084185063838959	249.1188812255859	\N	407	2026-01-31 22:50:09.841
408	1	1	55.1068537	82.9519737	2026-01-31 21:36:58.742	MOVE	46.74200057983398	0	0	\N	408	2026-01-31 22:50:09.841
409	1	1	55.1068418	82.9520603	2026-01-31 21:37:16.022	MOVE	222	1.879999995231628	107	\N	409	2026-01-31 22:50:09.841
410	1	1	55.1067768	82.9522561	2026-01-31 21:37:42.94	MOVE	33.95800018310547	0	0	\N	410	2026-01-31 22:50:09.841
411	1	1	55.1068337	82.9520975	2026-01-31 21:38:00.236	MOVE	25.71100044250488	0	0	\N	411	2026-01-31 22:50:09.841
412	1	1	55.1067772	82.9522362	2026-01-31 21:38:18.134	MOVE	48.02199935913086	0	0	\N	412	2026-01-31 22:50:09.841
413	1	1	55.1068525	82.9519691	2026-01-31 21:38:36.146	MOVE	47.7130012512207	0	0	\N	413	2026-01-31 22:50:09.841
414	1	1	55.1070187	82.9520318	2026-01-31 21:38:55.184	MOVE	106	6.922497272491455	300.5018615722656	\N	414	2026-01-31 22:50:09.841
415	1	1	55.1067797	82.9522305	2026-01-31 21:39:14.063	MOVE	24.96100044250488	0	0	\N	415	2026-01-31 22:50:09.841
416	1	1	55.1069927	82.9520892	2026-01-31 21:39:29.023	MOVE	94	5.656423091888428	312.0486450195312	\N	416	2026-01-31 22:50:09.841
417	1	1	55.1068669	82.9521169	2026-01-31 21:39:42.13	MOVE	35.44300079345703	4.3858642578125	311.1703491210938	\N	417	2026-01-31 22:50:09.841
418	1	1	55.1067656	82.9522501	2026-01-31 21:40:00.123	MOVE	24.59799957275391	0	0	\N	418	2026-01-31 22:50:09.841
419	1	1	55.1068182	82.952185	2026-01-31 21:40:17.427	MOVE	45.95500183105469	0	0	\N	419	2026-01-31 22:50:09.841
420	1	1	55.1067826	82.9523008	2026-01-31 21:40:42.632	MOVE	33.15000152587891	0.4049935340881348	220.4376525878906	\N	420	2026-01-31 22:50:09.841
421	1	1	55.1068693	82.9526578	2026-01-31 21:40:59.029	MOVE	60	1.730000019073486	55	\N	421	2026-01-31 22:50:09.841
422	1	1	55.1068007	82.9522092	2026-01-31 21:41:17.161	MOVE	37.84400177001953	0	0	\N	422	2026-01-31 22:50:09.841
423	1	1	55.1068566	82.9523969	2026-01-31 21:41:59.13	MOVE	66	0.9699999690055847	255	\N	423	2026-01-31 22:50:09.841
424	1	1	55.106788	82.9522201	2026-01-31 21:42:18.321	MOVE	24.62199974060059	0	0	\N	424	2026-01-31 22:50:09.841
425	1	1	55.1069882	82.9524228	2026-01-31 21:42:59.02	MOVE	62	1.299999952316284	290	\N	425	2026-01-31 22:50:09.841
426	1	1	55.1068012	82.9521978	2026-01-31 21:43:24.869	MOVE	25.24099922180176	0	0	\N	426	2026-01-31 22:50:09.841
427	1	1	55.1067986	82.9523079	2026-01-31 21:44:12.647	MOVE	23.11800003051758	1.731010913848877	45.17999649047852	\N	427	2026-01-31 22:50:09.841
428	1	1	55.1069016	82.9525629	2026-01-31 21:44:29.032	MOVE	121	0.4899999797344208	261	\N	428	2026-01-31 22:50:09.841
429	1	1	55.1067775	82.9522481	2026-01-31 21:44:47.107	MOVE	24.47699928283691	0	0	\N	429	2026-01-31 22:50:09.841
430	1	1	55.1068148	82.9521746	2026-01-31 21:45:12.223	MOVE	46.4640007019043	1.557939291000366	231.3957824707031	\N	430	2026-01-31 22:50:09.841
431	1	1	55.1069048	82.952343	2026-01-31 21:45:28.998	MOVE	103	1.909999966621399	220	\N	431	2026-01-31 22:50:09.841
432	1	1	55.1067753	82.952253	2026-01-31 21:45:46.699	MOVE	24.28800010681152	0	0	\N	432	2026-01-31 22:50:09.841
433	1	1	55.1068401	82.9520785	2026-01-31 21:46:29.313	MOVE	48.49800109863281	0	0	\N	433	2026-01-31 22:50:09.841
434	1	1	55.1068148	82.9521963	2026-01-31 21:47:28.17	MOVE	45.49300003051758	0	0	\N	434	2026-01-31 22:50:09.841
435	1	1	55.1067769	82.9522569	2026-01-31 21:47:45.58	MOVE	34.26800155639648	0	0	\N	435	2026-01-31 22:50:09.841
436	1	1	55.1070358	82.9528002	2026-01-31 21:48:02.011	MOVE	185.5	0.699999988079071	294	\N	436	2026-01-31 22:50:09.841
437	1	1	55.1067906	82.9522258	2026-01-31 21:48:20.379	MOVE	24.69700050354004	0	0	\N	437	2026-01-31 22:50:09.841
438	1	1	55.106831	82.9521502	2026-01-31 21:48:42.917	MOVE	52.59199905395508	0.6345760822296143	134.5877838134766	\N	438	2026-01-31 22:50:09.841
439	1	1	55.1069323	82.9519712	2026-01-31 21:49:00.013	MOVE	72	0.4399999976158142	323	\N	439	2026-01-31 22:50:09.841
440	1	1	55.1067888	82.9522121	2026-01-31 21:49:24.882	MOVE	49.51300048828125	0	0	\N	440	2026-01-31 22:50:09.841
441	1	1	55.1068951	82.9526764	2026-01-31 21:50:00.193	MOVE	84.5	2.819999933242798	295	\N	441	2026-01-31 22:50:09.841
442	1	1	55.1068529	82.9519712	2026-01-31 21:50:19.205	MOVE	46.73400115966797	0	0	\N	442	2026-01-31 22:50:09.841
443	1	1	55.1067806	82.9522372	2026-01-31 21:50:42.891	MOVE	24.45800018310547	1.412545442581177	149.0993957519531	\N	443	2026-01-31 22:50:09.841
444	1	1	55.1070021	82.9520463	2026-01-31 21:50:58.998	MOVE	56.5	1.110000014305115	92	\N	444	2026-01-31 22:50:09.841
445	1	1	55.1068334	82.9521043	2026-01-31 21:51:17.413	MOVE	25.76600074768066	0	0	\N	445	2026-01-31 22:50:09.841
446	1	1	55.1067707	82.95229	2026-01-31 21:51:43.85	MOVE	25.31100082397461	0.8365007638931274	123.5787353515625	\N	446	2026-01-31 22:50:09.841
447	1	1	55.106858	82.9522413	2026-01-31 21:51:59.168	MOVE	72	1.019999980926514	296	\N	447	2026-01-31 22:50:09.841
448	1	1	55.1067664	82.952263	2026-01-31 21:52:15.914	MOVE	21.92700004577637	0	0	\N	448	2026-01-31 22:50:09.841
449	1	1	55.1067784	82.952361	2026-01-31 21:52:44.07	MOVE	30.87100028991699	0	0	\N	449	2026-01-31 22:50:09.841
450	1	1	55.1068475	82.9524662	2026-01-31 21:52:59.019	MOVE	75.5	3.42303466796875	80.9306869506836	\N	450	2026-01-31 22:50:09.841
451	1	1	55.1067805	82.9522567	2026-01-31 21:53:18.248	MOVE	18.79199981689453	0	0	\N	451	2026-01-31 22:50:09.841
452	1	1	55.1067638	82.9523379	2026-01-31 21:53:42.662	MOVE	33.37799835205078	2.144781589508057	122.5307464599609	\N	452	2026-01-31 22:50:09.841
453	1	1	55.1068923	82.9518463	2026-01-31 21:53:59.009	MOVE	77.5	0.1899999976158142	121	\N	453	2026-01-31 22:50:09.841
454	1	1	55.1067779	82.9522415	2026-01-31 21:54:16.682	MOVE	21.57299995422363	0	0	\N	454	2026-01-31 22:50:09.841
455	1	1	55.1069559	82.9521287	2026-01-31 21:54:59.811	MOVE	137.6069946289062	0.172423928976059	109.6708755493164	\N	455	2026-01-31 22:50:09.841
456	1	1	55.1067723	82.9522271	2026-01-31 21:55:16.85	MOVE	27.66699981689453	0	0	\N	456	2026-01-31 22:50:09.841
457	1	1	55.1068247	82.9521482	2026-01-31 21:55:41.986	MOVE	34.38199996948242	0.8463951945304871	303.718505859375	\N	457	2026-01-31 22:50:09.841
458	1	1	55.1068662	82.9524801	2026-01-31 21:55:59.005	MOVE	67.5	0.550000011920929	233	\N	458	2026-01-31 22:50:09.841
459	1	1	55.1067814	82.9522363	2026-01-31 21:56:18.129	MOVE	21.72699928283691	0	0	\N	459	2026-01-31 22:50:09.841
460	1	1	55.1069336	82.9522602	2026-01-31 21:57:28.967	MOVE	65	0.8499999642372131	253	\N	460	2026-01-31 22:50:09.841
461	1	1	55.1067583	82.9522716	2026-01-31 21:57:47.424	MOVE	24.22900009155273	0	0	\N	461	2026-01-31 22:50:09.841
462	1	1	55.1068914	82.9520004	2026-01-31 21:58:29.008	MOVE	57	0.5699999928474426	319	\N	462	2026-01-31 22:50:09.841
463	1	1	55.106783	82.9522866	2026-01-31 21:58:48.135	MOVE	52.30899810791016	0	0	\N	463	2026-01-31 22:50:09.841
464	1	1	55.1068416	82.9527173	2026-01-31 21:59:29.993	MOVE	77.5	1.870000004768372	115	\N	464	2026-01-31 22:50:09.841
465	1	1	55.1067654	82.9522759	2026-01-31 21:59:48.356	MOVE	26.18099975585938	0	0	\N	465	2026-01-31 22:50:09.841
466	1	1	55.1068429	82.952698	2026-01-31 22:00:28.979	MOVE	70	1.079999923706055	270	\N	466	2026-01-31 22:50:09.841
467	1	1	55.1067984	82.9522178	2026-01-31 22:00:47.145	MOVE	25.27000045776367	0	0	\N	467	2026-01-31 22:50:09.841
468	1	1	55.1068807	82.9523757	2026-01-31 22:01:28.978	MOVE	95	1.339999914169312	84	\N	468	2026-01-31 22:50:09.841
469	1	1	55.1067786	82.9522737	2026-01-31 22:01:46.422	MOVE	27.49399948120117	0	0	\N	469	2026-01-31 22:50:09.841
470	1	1	55.1068061	82.9524144	2026-01-31 22:02:00.145	MOVE	127.5	0.6179111003875732	270.0040893554688	\N	470	2026-01-31 22:50:09.841
471	1	1	55.1067717	82.9522346	2026-01-31 22:02:12.737	MOVE	23.52499961853027	0.692289412021637	269.7947082519531	\N	471	2026-01-31 22:50:09.841
472	1	1	55.1069519	82.9520174	2026-01-31 22:02:29.967	MOVE	78.5	2.169999837875366	277	\N	472	2026-01-31 22:50:09.841
473	1	1	55.1068639	82.9529727	2026-01-31 22:02:47.98	MOVE	44	0.4399999976158142	120	\N	473	2026-01-31 22:50:09.841
474	1	1	55.1067791	82.9522145	2026-01-31 22:03:14.829	MOVE	26.98399925231934	0	0	\N	474	2026-01-31 22:50:09.841
475	1	1	55.1067858	82.9526011	2026-01-31 22:03:30.132	MOVE	87	0.5699999928474426	313	\N	475	2026-01-31 22:50:09.841
476	1	1	55.1067844	82.952295	2026-01-31 22:03:45.858	MOVE	45.37900161743164	0	0	\N	476	2026-01-31 22:50:09.841
477	1	1	55.1070136	82.9518713	2026-01-31 22:04:00.056	MOVE	60.5	4.735273838043213	314.00341796875	\N	477	2026-01-31 22:50:09.841
478	1	1	55.1067866	82.9523075	2026-01-31 22:04:15.505	MOVE	38.07799911499023	0	0	\N	478	2026-01-31 22:50:09.841
479	1	1	55.1066182	82.9526928	2026-01-31 22:04:30.141	MOVE	125.5	1.499178647994995	127.3829193115234	\N	479	2026-01-31 22:50:09.841
480	1	1	55.1067809	82.9522621	2026-01-31 22:04:44.165	MOVE	42.10100173950195	2.191009759902954	303.329833984375	\N	480	2026-01-31 22:50:09.841
481	1	1	55.1068248	82.95257	2026-01-31 22:05:28.134	MOVE	46	0.1604227125644684	128.7150115966797	\N	481	2026-01-31 22:50:09.841
482	1	1	55.1068828	82.9522523	2026-01-31 22:05:54.991	MOVE	47.5	0.6065582633018494	160.2215881347656	\N	482	2026-01-31 22:50:09.841
483	1	1	55.1068016	82.9528658	2026-01-31 22:06:23.962	MOVE	33	0.9599999785423279	255	\N	483	2026-01-31 22:50:09.841
484	1	1	55.1067647	82.9530174	2026-01-31 22:06:24.995	MOVE	37.17800140380859	1.167115807533264	259.5088806152344	\N	484	2026-01-31 22:50:09.841
485	1	1	55.1067781	82.9522815	2026-01-31 22:06:51.87	MOVE	35.67200088500977	0	0	\N	485	2026-01-31 22:50:09.841
486	1	1	55.106981	82.9518868	2026-01-31 22:08:00.105	MOVE	70.5	0.6599999666213989	281	\N	486	2026-01-31 22:50:09.841
487	1	1	55.1067689	82.9522438	2026-01-31 22:08:22.099	MOVE	34.13399887084961	0	0	\N	487	2026-01-31 22:50:09.841
488	1	1	55.106854	82.9523552	2026-01-31 22:08:51.132	MOVE	48.5	0.3700000047683716	321	\N	488	2026-01-31 22:50:09.841
489	1	1	55.1068529	82.9521672	2026-01-31 22:09:18.98	MOVE	48.5	2.690000057220459	130	\N	489	2026-01-31 22:50:09.841
490	1	1	55.1067678	82.9522278	2026-01-31 22:09:47.829	MOVE	32.86000061035156	0	0	\N	490	2026-01-31 22:50:09.841
491	1	1	55.1068105	82.952448	2026-01-31 22:10:28.973	MOVE	72.5	0.4058351814746857	267.0191650390625	\N	491	2026-01-31 22:50:09.841
492	1	1	55.1069469	82.9522183	2026-01-31 22:10:49.099	MOVE	45.5	4.630000114440918	301	\N	492	2026-01-31 22:50:09.841
493	1	1	55.1070031	82.9518183	2026-01-31 22:10:55.944	MOVE	32.44499969482422	3.342524290084839	302.9568786621094	\N	493	2026-01-31 22:50:09.841
494	1	1	55.1067639	82.952251	2026-01-31 22:11:23.847	MOVE	33.66799926757812	0	0	\N	494	2026-01-31 22:50:09.841
495	1	1	55.1068062	82.9521364	2026-01-31 22:13:11.206	MOVE	33.79600143432617	1.669740796089172	289.2818603515625	\N	495	2026-01-31 22:50:09.841
496	1	1	55.1069146	82.9523325	2026-01-31 22:13:28.954	MOVE	82.5	1.949999928474426	300	\N	496	2026-01-31 22:50:09.841
497	1	1	55.1067706	82.9522721	2026-01-31 22:13:46.081	MOVE	17.17499923706055	0	0	\N	497	2026-01-31 22:50:09.841
498	1	1	55.1069052	82.9524693	2026-01-31 22:14:57.951	MOVE	48	1.629999995231628	277	\N	498	2026-01-31 22:50:09.841
499	1	1	55.1068934	82.9523439	2026-01-31 22:15:18.113	MOVE	47.5	1.069999933242798	141	\N	499	2026-01-31 22:50:09.841
500	1	1	55.1067637	82.9522081	2026-01-31 22:15:53.306	MOVE	32.98600006103516	0	0	\N	500	2026-01-31 22:50:09.841
501	1	1	55.1067537	82.9528079	2026-01-31 22:17:55.958	MOVE	45.5	3.781919717788696	132.8638763427734	\N	501	2026-01-31 22:50:09.841
502	1	1	55.1067786	82.952212	2026-01-31 22:18:11.62	MOVE	27.01399993896484	0	0	\N	502	2026-01-31 22:50:09.841
503	1	1	55.1069441	82.9517497	2026-01-31 22:18:27.938	MOVE	49.5	2.740000009536743	287	\N	503	2026-01-31 22:50:09.841
504	1	1	55.1067713	82.9522224	2026-01-31 22:18:47.049	MOVE	26.57099914550781	0	0	\N	504	2026-01-31 22:50:09.841
505	1	1	55.1068522	82.9526091	2026-01-31 22:19:29.945	MOVE	51.5	2.409999847412109	287	\N	505	2026-01-31 22:50:09.841
506	1	1	55.1067798	82.9522217	2026-01-31 22:19:54.814	MOVE	26.17099952697754	0	0	\N	506	2026-01-31 22:50:09.841
507	1	1	55.1069812	82.9519036	2026-01-31 22:20:58.925	MOVE	54.5	0.3581851720809937	143.9461975097656	\N	507	2026-01-31 22:50:09.841
508	1	1	55.1068468	82.9520404	2026-01-31 22:21:19.906	MOVE	49.5	4.003366470336914	325.8785705566406	\N	508	2026-01-31 22:50:09.841
509	1	1	55.1070841	82.9517469	2026-01-31 22:21:31.34	MOVE	169.1940002441406	2.712022066116333	322.9872741699219	\N	509	2026-01-31 22:50:09.841
510	1	1	55.1067777	82.9522297	2026-01-31 22:21:54.848	MOVE	26.48800086975098	0	0	\N	510	2026-01-31 22:50:09.841
511	1	1	55.1067382	82.95278	2026-01-31 22:22:29.928	MOVE	67.5	0.25	108	\N	511	2026-01-31 22:50:09.841
512	1	1	55.1067665	82.9522107	2026-01-31 22:22:54.787	MOVE	32.90399932861328	0	0	\N	512	2026-01-31 22:50:09.841
513	1	1	55.1068318	82.9526493	2026-01-31 22:24:00.098	MOVE	46.5	0.7999999523162842	101	\N	513	2026-01-31 22:50:09.841
514	1	1	55.1067647	82.9522499	2026-01-31 22:24:24.238	MOVE	23.47800064086914	0	0	\N	514	2026-01-31 22:50:09.841
515	1	1	55.1068283	82.9521382	2026-01-31 22:24:59.219	MOVE	25.49799919128418	0	0	\N	515	2026-01-31 22:50:09.841
516	1	1	55.1067812	82.9522201	2026-01-31 22:25:16.351	MOVE	36.4119987487793	0	0	\N	516	2026-01-31 22:50:09.841
517	1	1	55.1067453	82.952593	2026-01-31 22:25:30.053	MOVE	211	1.230555534362793	99.55953979492188	\N	517	2026-01-31 22:50:09.841
518	1	1	55.1067072	82.9529878	2026-01-31 22:25:33.499	MOVE	279.906005859375	5.109315872192383	99.55953979492188	\N	518	2026-01-31 22:50:09.841
519	1	1	55.1067914	82.9521994	2026-01-31 22:25:50.559	MOVE	26.21100044250488	0	0	\N	519	2026-01-31 22:50:09.841
520	1	1	55.1068159	82.9526656	2026-01-31 22:26:29.071	MOVE	47	0.3552417755126953	98.85907745361328	\N	520	2026-01-31 22:50:09.841
521	1	1	55.1067603	82.9522484	2026-01-31 22:26:49.592	MOVE	23.4689998626709	0	0	\N	521	2026-01-31 22:50:09.841
522	1	1	55.1068423	82.9525837	2026-01-31 22:27:31.997	MOVE	107.1949996948242	0.8259707689285278	76.26590728759766	\N	522	2026-01-31 22:50:09.841
523	1	1	55.1067787	82.9523337	2026-01-31 22:27:50.21	MOVE	24.26399993896484	0	0	\N	523	2026-01-31 22:50:09.841
524	1	1	55.1067953	82.9522377	2026-01-31 22:28:16.91	MOVE	20.22400093078613	1.005305051803589	312.1269226074219	\N	524	2026-01-31 22:50:09.841
525	1	1	55.1068307	82.9525086	2026-01-31 22:28:32.218	MOVE	64.5	1.5	281	\N	525	2026-01-31 22:50:09.841
526	1	1	55.1067932	82.9521941	2026-01-31 22:28:57.946	MOVE	36.44100189208984	0	0	\N	526	2026-01-31 22:50:09.841
527	1	1	55.1067766	82.9522932	2026-01-31 22:29:45.115	MOVE	31.76600074768066	0.6453158259391785	254.8596649169922	\N	527	2026-01-31 22:50:09.841
528	1	1	55.1067787	82.9522127	2026-01-31 22:30:31.914	MOVE	26.67099952697754	0	0	\N	528	2026-01-31 22:50:09.841
529	1	1	55.1068462	82.9524036	2026-01-31 22:30:48.056	MOVE	77.5	13.47999954223633	282	\N	529	2026-01-31 22:50:09.841
530	1	1	55.1067757	82.9522593	2026-01-31 22:31:07.193	MOVE	17.69899940490723	0	0	\N	530	2026-01-31 22:50:09.841
531	1	1	55.1068567	82.9524127	2026-01-31 22:32:47.053	MOVE	86.5	0.119999997317791	255	\N	531	2026-01-31 22:50:09.841
532	1	1	55.1067856	82.9522213	2026-01-31 22:33:05.011	MOVE	26.06800079345703	0	0	\N	532	2026-01-31 22:50:09.841
533	1	1	55.106736	82.9523817	2026-01-31 22:33:31.046	MOVE	32.18399810791016	2.416833639144897	135.6782684326172	\N	533	2026-01-31 22:50:09.841
534	1	1	55.1068737	82.9525767	2026-01-31 22:33:47.056	MOVE	118.5	1.96999990940094	257	\N	534	2026-01-31 22:50:09.841
535	1	1	55.1067756	82.9522587	2026-01-31 22:34:05.177	MOVE	17.93000030517578	0	0	\N	535	2026-01-31 22:50:09.841
536	1	1	55.1067156	82.952436	2026-01-31 22:34:22.286	MOVE	182.1490020751953	3.073693513870239	203.4781951904297	\N	536	2026-01-31 22:50:09.841
537	1	1	55.1067734	82.9522803	2026-01-31 22:34:39.413	MOVE	17.79199981689453	0	0	\N	537	2026-01-31 22:50:09.841
538	1	1	55.1068097	82.9527582	2026-01-31 22:35:17.045	MOVE	111	1.659999966621399	140	\N	538	2026-01-31 22:50:09.841
539	1	1	55.1067639	82.9522249	2026-01-31 22:35:34.449	MOVE	33.67200088500977	0	0	\N	539	2026-01-31 22:50:09.841
540	1	1	55.1068374	82.9526792	2026-01-31 22:35:51.562	MOVE	142.3600006103516	1.050590753555298	189.9909973144531	\N	540	2026-01-31 22:50:09.841
541	1	1	55.106765	82.9522176	2026-01-31 22:36:09.172	MOVE	32.74200057983398	0	0	\N	541	2026-01-31 22:50:09.841
542	1	1	55.1068336	82.9519232	2026-01-31 22:37:00.035	MOVE	33.14199829101562	7.143816947937012	286.6275939941406	\N	542	2026-01-31 22:50:09.841
543	1	1	55.1068348	82.9526058	2026-01-31 22:37:17.062	MOVE	56.5	0.1599999964237213	293	\N	543	2026-01-31 22:50:09.841
544	1	1	55.1067604	82.9522168	2026-01-31 22:37:40.905	MOVE	34.00199890136719	0	0	\N	544	2026-01-31 22:50:09.841
545	1	1	55.1068559	82.9521843	2026-01-31 22:38:17.208	MOVE	91	5.190000057220459	304	\N	545	2026-01-31 22:50:09.841
546	1	1	55.1067614	82.952216	2026-01-31 22:38:37.164	MOVE	34.00199890136719	0	0	\N	546	2026-01-31 22:50:09.841
547	1	1	55.1067552	82.9523101	2026-01-31 22:39:00.656	MOVE	17.66900062561035	3.726525068283081	137.1744995117188	\N	547	2026-01-31 22:50:09.841
548	1	1	55.1068759	82.9522373	2026-01-31 22:39:18.053	MOVE	76	5.539999961853027	122	\N	548	2026-01-31 22:50:09.841
549	1	1	55.1067795	82.952276	2026-01-31 22:39:35.216	MOVE	16.8700008392334	0	0	\N	549	2026-01-31 22:50:09.841
550	1	1	55.1069545	82.9521195	2026-01-31 22:40:17.042	MOVE	86	6.559999942779541	124	\N	550	2026-01-31 22:50:09.841
551	1	1	55.1067657	82.9522194	2026-01-31 22:40:35.435	MOVE	32.62900161743164	0	0	\N	551	2026-01-31 22:50:09.841
552	1	1	55.1067777	82.9521147	2026-01-31 22:42:31.903	MOVE	34.12900161743164	4.019913673400879	270.8586120605469	\N	552	2026-01-31 22:50:09.841
553	1	1	55.1068227	82.9524331	2026-01-31 22:42:48.04	MOVE	92.5	1.709999918937683	257	\N	553	2026-01-31 22:50:09.841
554	1	1	55.1067748	82.9522705	2026-01-31 22:43:06.45	MOVE	17.94300079345703	0	0	\N	554	2026-01-31 22:50:09.841
555	1	1	55.1068593	82.9522023	2026-01-31 22:43:47.193	MOVE	98.5	4.309999942779541	266	\N	555	2026-01-31 22:50:09.841
556	1	1	55.1067773	82.9522126	2026-01-31 22:44:06.113	MOVE	27.42600059509277	0	0	\N	556	2026-01-31 22:50:09.841
557	1	1	55.1069103	82.9522311	2026-01-31 22:44:48.029	MOVE	68.5	6.75	283	\N	557	2026-01-31 22:50:09.841
558	1	1	55.1067665	82.9522338	2026-01-31 22:45:05.823	MOVE	32.14500045776367	0	0	\N	558	2026-01-31 22:50:09.841
559	1	1	55.1068048	82.9522767	2026-01-31 22:45:31.992	MOVE	27.97999954223633	0.5978361964225769	104.1379547119141	\N	559	2026-01-31 22:50:09.841
560	1	1	55.10683	82.9526877	2026-01-31 22:45:48.026	MOVE	73	0.4099999964237213	268	\N	560	2026-01-31 22:50:09.841
561	1	1	55.106809	82.9522288	2026-01-31 22:46:06.464	MOVE	21.95899963378906	0	0	\N	561	2026-01-31 22:50:09.841
562	1	1	55.1069686	82.952169	2026-01-31 22:46:49.018	MOVE	200	1.559999942779541	92	\N	562	2026-01-31 22:50:09.841
563	1	1	55.1067801	82.9522643	2026-01-31 22:47:12.898	MOVE	27.07500076293945	0	0	\N	563	2026-01-31 22:50:09.841
564	1	1	55.1068051	82.9520493	2026-01-31 22:47:33.197	MOVE	45.09799957275391	0.1529329568147659	210.0837097167969	\N	564	2026-01-31 22:50:09.841
565	1	1	55.106898	82.9527343	2026-01-31 22:47:50.021	MOVE	118	0	0	\N	565	2026-01-31 22:50:09.841
566	1	1	55.1068089	82.9522368	2026-01-31 22:48:09.148	MOVE	21.2859992980957	0	0	\N	566	2026-01-31 22:50:09.841
567	1	1	55.1068342	82.952129	2026-01-31 22:49:20.19	MOVE	172	1.151564359664917	140.07275390625	\N	567	2026-01-31 22:50:09.841
568	1	1	55.1068126	82.952217	2026-01-31 22:49:41.934	MOVE	45.24499893188477	0	0	\N	568	2026-01-31 22:50:09.841
569	1	1	55.10691	82.9521436	2026-01-31 22:49:58.195	MOVE	131	0.1347115635871887	0.1338835209608078	\N	569	2026-01-31 22:50:09.841
570	1	1	55.1067916	82.9522424	2026-01-31 22:50:10.385	MOVE	18.88599967956543	1.113676905632019	154.1900634765625	\N	570	2026-01-31 22:50:25.209
\.


--
-- Data for Name: SpecialPrice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SpecialPrice" (id, guid, "productId", "counterpartyId", "agreementId", "priceTypeId", price, currency, "startDate", "endDate", "minQty", "isActive", "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockBalance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StockBalance" (id, "productId", "warehouseId", quantity, reserved, "updatedAt", "sourceUpdatedAt", "lastSyncedAt") FROM stdin;
\.


--
-- Data for Name: SupplierProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SupplierProfile" (id, "userId", "addressId", phone, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SyncRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRun" (id, "requestId", entity, direction, status, "totalCount", "successCount", "errorCount", "startedAt", "finishedAt", notes, meta) FROM stdin;
\.


--
-- Data for Name: SyncRunItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SyncRunItem" (id, "runId", key, status, error, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: Unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Unit" (id, guid, name, code, symbol, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, "passwordHash", "isActive", "roleId", "createdAt", "updatedAt", "avatarUrl", "deletedAt", phone, "profileStatus", "currentProfileType", "firstName", "lastName", "middleName") FROM stdin;
1	extectick@yandex.ru	$2b$10$qtw/KkpQmdPjfU.CDnPVgeM9EoS9QXsl/pidSdkZARfNxirNZazF6	t	4	2026-01-27 10:13:43.621	2026-01-27 10:56:02.766	\N	\N	\N	ACTIVE	EMPLOYEE	Алексей	Борховецкий	Евгеньевич
\.


--
-- Data for Name: UserRoute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserRoute" (id, "userId", status, "startedAt", "endedAt", "createdAt", "updatedAt") FROM stdin;
1	1	ACTIVE	2026-01-31 18:30:18.777	\N	2026-01-31 18:32:14.913	2026-01-31 18:32:14.913
\.


--
-- Data for Name: Warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Warehouse" (id, guid, name, code, "isActive", "isDefault", "isPickup", address, "sourceUpdatedAt", "lastSyncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _EmployeeDepartmentRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_EmployeeDepartmentRoles" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
955730ab-6db5-4229-95c3-7cb19d4d2a3d	78141557caab0d9539a7057374e6c88112968e8c2575d37c48b188b5ddeda659	2026-01-27 07:50:21.132678+00	20250712083400_init	\N	\N	2026-01-27 07:50:20.222764+00	1
464f8b09-2c00-4c8b-8068-2d338245ad79	ead7416b7215d43ef8974f5eb0d77c0af5b1fccc33a7bb94beb1d0031d7515af	2026-01-27 07:50:21.476899+00	20250713095849_add_parent_role_id_to_role	\N	\N	2026-01-27 07:50:21.146523+00	1
ea66c9bf-a8b4-4fb9-8cca-37016d79354f	6e1f44737c7ec8af4de6bc2e68cccce4031411481ffa3885e4f1eaa6f77c683e	2026-01-27 07:50:21.916619+00	20250715070749_update_schema	\N	\N	2026-01-27 07:50:21.502113+00	1
0bb387b2-fa2e-4d22-bed6-60240a608011	100a6ec3d37dd55753a9e7fb731f43a360b3c49ab82745339538b3c2292edbc4	2026-01-27 07:50:21.991932+00	20250715072640_update_schema	\N	\N	2026-01-27 07:50:21.927859+00	1
34d5152b-8bd2-4118-b59a-14f70ee9b818	0564d26e8de4d7877c41cb4985c5efa40bbec9623811b40715a58edce90db1e7	2026-01-27 07:50:22.096673+00	20250716073009_add_user_name_fields	\N	\N	2026-01-27 07:50:22.016109+00	1
b729110b-475f-4571-8409-b49a576a905a	91d5a16ee8795b785fb4412eec6dba91b329a165876b879bae2b10db7b194b5e	2026-01-27 07:50:22.456581+00	20250729130102_added_qr_codes	\N	\N	2026-01-27 07:50:22.125497+00	1
8c664302-b47c-4c67-bae7-9bf01c598194	22899d4df0ab0576dfbf396644d304f77a5b206c1925ac1573cff3f5223f3c07	2026-01-27 07:50:22.519534+00	20250729151622_add_qr_type	\N	\N	2026-01-27 07:50:22.469923+00	1
e7b1ca81-47ca-4e2c-90e9-4c87448d6feb	c8a85dfdfb42127a014456b6aba5cbabda061a00353a2ba18766e3348ca98d4d	2026-01-27 07:50:22.603091+00	20250729154453_add_qr_type	\N	\N	2026-01-27 07:50:22.543505+00	1
adb14e01-2771-4001-939d-4bb87850fafb	cd5fdb5da5c2b999d69ba1887acb6dffb302c345cbb31db60abbdb77eea028fb	2026-01-27 07:50:22.994772+00	20250821153051_add_appeals	\N	\N	2026-01-27 07:50:22.616369+00	1
2b049c31-94e3-47f7-8e20-f4f984e31a1b	77950141ad20bbf408a1922deba80dba980850153d2e072bbe18c52738b07b2e	2026-01-27 07:50:23.183081+00	20251115185222_test1	\N	\N	2026-01-27 07:50:23.00605+00	1
8711074f-2787-4ac7-b1e5-5fdc34c414d3	9d8aa51e399151371c0402eda209794c35c68edefb5c37f6aab43474fab51917	2026-01-27 07:50:23.564439+00	20251222130000_add_app_updates	\N	\N	2026-01-27 07:50:23.196153+00	1
\.


--
-- Name: Address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Address_id_seq"', 1, false);


--
-- Name: AppUpdateEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdateEvent_id_seq"', 12, true);


--
-- Name: AppUpdate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppUpdate_id_seq"', 5, true);


--
-- Name: AppealAssignee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAssignee_id_seq"', 1, false);


--
-- Name: AppealAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealAttachment_id_seq"', 1, false);


--
-- Name: AppealMessageRead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessageRead_id_seq"', 1, false);


--
-- Name: AppealMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealMessage_id_seq"', 1, false);


--
-- Name: AppealStatusHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealStatusHistory_id_seq"', 1, false);


--
-- Name: AppealWatcher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppealWatcher_id_seq"', 1, false);


--
-- Name: Appeal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Appeal_id_seq"', 1, false);


--
-- Name: AuditLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AuditLog_id_seq"', 7, true);


--
-- Name: ClientProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ClientProfile_id_seq"', 1, false);


--
-- Name: DepartmentRole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DepartmentRole_id_seq"', 1, false);


--
-- Name: Department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Department_id_seq"', 4, true);


--
-- Name: DeviceToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DeviceToken_id_seq"', 1, false);


--
-- Name: EmailVerification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailVerification_id_seq"', 1, true);


--
-- Name: EmployeeProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmployeeProfile_id_seq"', 1, true);


--
-- Name: LoginAttempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoginAttempt_id_seq"', 7, true);


--
-- Name: PasswordReset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordReset_id_seq"', 1, false);


--
-- Name: Permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Permission_id_seq"', 25, true);


--
-- Name: QRAnalytic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."QRAnalytic_id_seq"', 1, false);


--
-- Name: RefreshToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RefreshToken_id_seq"', 21, true);


--
-- Name: Role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Role_id_seq"', 4, true);


--
-- Name: RoutePoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RoutePoint_id_seq"', 570, true);


--
-- Name: SupplierProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SupplierProfile_id_seq"', 1, false);


--
-- Name: UserRoute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserRoute_id_seq"', 1, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdateEvent AppUpdateEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_pkey" PRIMARY KEY (id);


--
-- Name: AppUpdate AppUpdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdate"
    ADD CONSTRAINT "AppUpdate_pkey" PRIMARY KEY (id);


--
-- Name: AppealAssignee AppealAssignee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_pkey" PRIMARY KEY (id);


--
-- Name: AppealAttachment AppealAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessageRead AppealMessageRead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_pkey" PRIMARY KEY (id);


--
-- Name: AppealMessage AppealMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_pkey" PRIMARY KEY (id);


--
-- Name: AppealStatusHistory AppealStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: AppealWatcher AppealWatcher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_pkey" PRIMARY KEY (id);


--
-- Name: Appeal Appeal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: ClientAgreement ClientAgreement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_pkey" PRIMARY KEY (id);


--
-- Name: ClientContract ClientContract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_pkey" PRIMARY KEY (id);


--
-- Name: ClientProfile ClientProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_pkey" PRIMARY KEY (id);


--
-- Name: Counterparty Counterparty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Counterparty"
    ADD CONSTRAINT "Counterparty_pkey" PRIMARY KEY (id);


--
-- Name: DeliveryAddress DeliveryAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_pkey" PRIMARY KEY (id);


--
-- Name: DepartmentRole DepartmentRole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_pkey" PRIMARY KEY (id);


--
-- Name: Department Department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT "Department_pkey" PRIMARY KEY (id);


--
-- Name: DeviceToken DeviceToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_pkey" PRIMARY KEY (id);


--
-- Name: EmailVerification EmailVerification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeProfile EmployeeProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_pkey" PRIMARY KEY (id);


--
-- Name: LoginAttempt LoginAttempt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PriceType PriceType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PriceType"
    ADD CONSTRAINT "PriceType_pkey" PRIMARY KEY (id);


--
-- Name: ProductGroup ProductGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_pkey" PRIMARY KEY (id);


--
-- Name: ProductPackage ProductPackage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_pkey" PRIMARY KEY (id);


--
-- Name: ProductPrice ProductPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: QRAnalytic QRAnalytic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_pkey" PRIMARY KEY (id);


--
-- Name: QRList QRList_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: RolePermissions RolePermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_pkey" PRIMARY KEY ("roleId", "permissionId");


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: RoutePoint RoutePoint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_pkey" PRIMARY KEY (id);


--
-- Name: SpecialPrice SpecialPrice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_pkey" PRIMARY KEY (id);


--
-- Name: StockBalance StockBalance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_pkey" PRIMARY KEY (id);


--
-- Name: SupplierProfile SupplierProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_pkey" PRIMARY KEY (id);


--
-- Name: SyncRunItem SyncRunItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_pkey" PRIMARY KEY (id);


--
-- Name: SyncRun SyncRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRun"
    ADD CONSTRAINT "SyncRun_pkey" PRIMARY KEY (id);


--
-- Name: Unit Unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Unit"
    ADD CONSTRAINT "Unit_pkey" PRIMARY KEY (id);


--
-- Name: UserRoute UserRoute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Warehouse Warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Warehouse"
    ADD CONSTRAINT "Warehouse_pkey" PRIMARY KEY (id);


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AppUpdateEvent_deviceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_deviceId_idx" ON public."AppUpdateEvent" USING btree ("deviceId");


--
-- Name: AppUpdateEvent_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_platform_channel_versionCode_idx" ON public."AppUpdateEvent" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdateEvent_updateId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdateEvent_updateId_idx" ON public."AppUpdateEvent" USING btree ("updateId");


--
-- Name: AppUpdate_platform_channel_minSupportedVersionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_minSupportedVersionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "minSupportedVersionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AppUpdate_platform_channel_versionCode_idx" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppUpdate_platform_channel_versionCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppUpdate_platform_channel_versionCode_key" ON public."AppUpdate" USING btree (platform, channel, "versionCode");


--
-- Name: AppealAssignee_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealAssignee_appealId_userId_key" ON public."AppealAssignee" USING btree ("appealId", "userId");


--
-- Name: AppealMessageRead_messageId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealMessageRead_messageId_userId_key" ON public."AppealMessageRead" USING btree ("messageId", "userId");


--
-- Name: AppealWatcher_appealId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "AppealWatcher_appealId_userId_key" ON public."AppealWatcher" USING btree ("appealId", "userId");


--
-- Name: Appeal_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Appeal_number_key" ON public."Appeal" USING btree (number);


--
-- Name: ClientAgreement_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_contractId_idx" ON public."ClientAgreement" USING btree ("contractId");


--
-- Name: ClientAgreement_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_counterpartyId_idx" ON public."ClientAgreement" USING btree ("counterpartyId");


--
-- Name: ClientAgreement_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientAgreement_guid_key" ON public."ClientAgreement" USING btree (guid);


--
-- Name: ClientAgreement_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_isActive_idx" ON public."ClientAgreement" USING btree ("isActive");


--
-- Name: ClientAgreement_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_priceTypeId_idx" ON public."ClientAgreement" USING btree ("priceTypeId");


--
-- Name: ClientAgreement_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_sourceUpdatedAt_idx" ON public."ClientAgreement" USING btree ("sourceUpdatedAt");


--
-- Name: ClientAgreement_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientAgreement_warehouseId_idx" ON public."ClientAgreement" USING btree ("warehouseId");


--
-- Name: ClientContract_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_counterpartyId_idx" ON public."ClientContract" USING btree ("counterpartyId");


--
-- Name: ClientContract_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientContract_guid_key" ON public."ClientContract" USING btree (guid);


--
-- Name: ClientContract_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_isActive_idx" ON public."ClientContract" USING btree ("isActive");


--
-- Name: ClientContract_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientContract_sourceUpdatedAt_idx" ON public."ClientContract" USING btree ("sourceUpdatedAt");


--
-- Name: ClientProfile_activeAgreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeAgreementId_idx" ON public."ClientProfile" USING btree ("activeAgreementId");


--
-- Name: ClientProfile_activeContractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeContractId_idx" ON public."ClientProfile" USING btree ("activeContractId");


--
-- Name: ClientProfile_activeDeliveryAddressId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeDeliveryAddressId_idx" ON public."ClientProfile" USING btree ("activeDeliveryAddressId");


--
-- Name: ClientProfile_activePriceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activePriceTypeId_idx" ON public."ClientProfile" USING btree ("activePriceTypeId");


--
-- Name: ClientProfile_activeWarehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_activeWarehouseId_idx" ON public."ClientProfile" USING btree ("activeWarehouseId");


--
-- Name: ClientProfile_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ClientProfile_counterpartyId_idx" ON public."ClientProfile" USING btree ("counterpartyId");


--
-- Name: ClientProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ClientProfile_userId_key" ON public."ClientProfile" USING btree ("userId");


--
-- Name: Counterparty_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Counterparty_guid_key" ON public."Counterparty" USING btree (guid);


--
-- Name: Counterparty_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_isActive_idx" ON public."Counterparty" USING btree ("isActive");


--
-- Name: Counterparty_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Counterparty_sourceUpdatedAt_idx" ON public."Counterparty" USING btree ("sourceUpdatedAt");


--
-- Name: DeliveryAddress_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_counterpartyId_idx" ON public."DeliveryAddress" USING btree ("counterpartyId");


--
-- Name: DeliveryAddress_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeliveryAddress_guid_key" ON public."DeliveryAddress" USING btree (guid);


--
-- Name: DeliveryAddress_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_isActive_idx" ON public."DeliveryAddress" USING btree ("isActive");


--
-- Name: DeliveryAddress_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DeliveryAddress_sourceUpdatedAt_idx" ON public."DeliveryAddress" USING btree ("sourceUpdatedAt");


--
-- Name: DepartmentRole_userId_roleId_departmentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DepartmentRole_userId_roleId_departmentId_key" ON public."DepartmentRole" USING btree ("userId", "roleId", "departmentId");


--
-- Name: Department_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Department_name_key" ON public."Department" USING btree (name);


--
-- Name: DeviceToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DeviceToken_token_key" ON public."DeviceToken" USING btree (token);


--
-- Name: EmployeeProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmployeeProfile_userId_key" ON public."EmployeeProfile" USING btree ("userId");


--
-- Name: OrderItem_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_orderId_idx" ON public."OrderItem" USING btree ("orderId");


--
-- Name: OrderItem_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_productId_idx" ON public."OrderItem" USING btree ("productId");


--
-- Name: OrderItem_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderItem_sourceUpdatedAt_idx" ON public."OrderItem" USING btree ("sourceUpdatedAt");


--
-- Name: Order_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_agreementId_idx" ON public."Order" USING btree ("agreementId");


--
-- Name: Order_contractId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_contractId_idx" ON public."Order" USING btree ("contractId");


--
-- Name: Order_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_counterpartyId_idx" ON public."Order" USING btree ("counterpartyId");


--
-- Name: Order_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_guid_key" ON public."Order" USING btree (guid);


--
-- Name: Order_queuedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_queuedAt_idx" ON public."Order" USING btree ("queuedAt");


--
-- Name: Order_sentTo1cAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sentTo1cAt_idx" ON public."Order" USING btree ("sentTo1cAt");


--
-- Name: Order_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_sourceUpdatedAt_idx" ON public."Order" USING btree ("sourceUpdatedAt");


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: Order_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_warehouseId_idx" ON public."Order" USING btree ("warehouseId");


--
-- Name: Permission_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Permission_name_key" ON public."Permission" USING btree (name);


--
-- Name: PriceType_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PriceType_guid_key" ON public."PriceType" USING btree (guid);


--
-- Name: PriceType_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_isActive_idx" ON public."PriceType" USING btree ("isActive");


--
-- Name: PriceType_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PriceType_sourceUpdatedAt_idx" ON public."PriceType" USING btree ("sourceUpdatedAt");


--
-- Name: ProductGroup_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductGroup_guid_key" ON public."ProductGroup" USING btree (guid);


--
-- Name: ProductGroup_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_isActive_idx" ON public."ProductGroup" USING btree ("isActive");


--
-- Name: ProductGroup_parentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_parentId_idx" ON public."ProductGroup" USING btree ("parentId");


--
-- Name: ProductGroup_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductGroup_sourceUpdatedAt_idx" ON public."ProductGroup" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPackage_barcode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_barcode_idx" ON public."ProductPackage" USING btree (barcode);


--
-- Name: ProductPackage_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPackage_guid_key" ON public."ProductPackage" USING btree (guid);


--
-- Name: ProductPackage_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_productId_idx" ON public."ProductPackage" USING btree ("productId");


--
-- Name: ProductPackage_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPackage_sourceUpdatedAt_idx" ON public."ProductPackage" USING btree ("sourceUpdatedAt");


--
-- Name: ProductPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_guid_key" ON public."ProductPrice" USING btree (guid);


--
-- Name: ProductPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_isActive_idx" ON public."ProductPrice" USING btree ("isActive");


--
-- Name: ProductPrice_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_priceTypeId_idx" ON public."ProductPrice" USING btree ("priceTypeId");


--
-- Name: ProductPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_productId_idx" ON public."ProductPrice" USING btree ("productId");


--
-- Name: ProductPrice_productId_priceTypeId_startDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductPrice_productId_priceTypeId_startDate_key" ON public."ProductPrice" USING btree ("productId", "priceTypeId", "startDate");


--
-- Name: ProductPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductPrice_sourceUpdatedAt_idx" ON public."ProductPrice" USING btree ("sourceUpdatedAt");


--
-- Name: Product_article_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_article_idx" ON public."Product" USING btree (article);


--
-- Name: Product_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_groupId_idx" ON public."Product" USING btree ("groupId");


--
-- Name: Product_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Product_guid_key" ON public."Product" USING btree (guid);


--
-- Name: Product_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_isActive_idx" ON public."Product" USING btree ("isActive");


--
-- Name: Product_sku_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sku_idx" ON public."Product" USING btree (sku);


--
-- Name: Product_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_sourceUpdatedAt_idx" ON public."Product" USING btree ("sourceUpdatedAt");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: RoutePoint_routeId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_routeId_recordedAt_idx" ON public."RoutePoint" USING btree ("routeId", "recordedAt");


--
-- Name: RoutePoint_userId_recordedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RoutePoint_userId_recordedAt_idx" ON public."RoutePoint" USING btree ("userId", "recordedAt");


--
-- Name: SpecialPrice_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_guid_key" ON public."SpecialPrice" USING btree (guid);


--
-- Name: SpecialPrice_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_isActive_idx" ON public."SpecialPrice" USING btree ("isActive");


--
-- Name: SpecialPrice_productId_agreementId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_agreementId_idx" ON public."SpecialPrice" USING btree ("productId", "agreementId");


--
-- Name: SpecialPrice_productId_counterpartyId_agreementId_priceType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SpecialPrice_productId_counterpartyId_agreementId_priceType_key" ON public."SpecialPrice" USING btree ("productId", "counterpartyId", "agreementId", "priceTypeId", "startDate");


--
-- Name: SpecialPrice_productId_counterpartyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_counterpartyId_idx" ON public."SpecialPrice" USING btree ("productId", "counterpartyId");


--
-- Name: SpecialPrice_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_idx" ON public."SpecialPrice" USING btree ("productId");


--
-- Name: SpecialPrice_productId_priceTypeId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_productId_priceTypeId_idx" ON public."SpecialPrice" USING btree ("productId", "priceTypeId");


--
-- Name: SpecialPrice_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SpecialPrice_sourceUpdatedAt_idx" ON public."SpecialPrice" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_productId_warehouseId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StockBalance_productId_warehouseId_key" ON public."StockBalance" USING btree ("productId", "warehouseId");


--
-- Name: StockBalance_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_sourceUpdatedAt_idx" ON public."StockBalance" USING btree ("sourceUpdatedAt");


--
-- Name: StockBalance_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_updatedAt_idx" ON public."StockBalance" USING btree ("updatedAt");


--
-- Name: StockBalance_warehouseId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StockBalance_warehouseId_idx" ON public."StockBalance" USING btree ("warehouseId");


--
-- Name: SupplierProfile_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SupplierProfile_userId_key" ON public."SupplierProfile" USING btree ("userId");


--
-- Name: SyncRunItem_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_key_idx" ON public."SyncRunItem" USING btree (key);


--
-- Name: SyncRunItem_runId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_runId_idx" ON public."SyncRunItem" USING btree ("runId");


--
-- Name: SyncRunItem_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRunItem_status_idx" ON public."SyncRunItem" USING btree (status);


--
-- Name: SyncRun_entity_direction_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_entity_direction_startedAt_idx" ON public."SyncRun" USING btree (entity, direction, "startedAt");


--
-- Name: SyncRun_requestId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "SyncRun_requestId_key" ON public."SyncRun" USING btree ("requestId");


--
-- Name: SyncRun_status_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SyncRun_status_startedAt_idx" ON public."SyncRun" USING btree (status, "startedAt");


--
-- Name: Unit_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Unit_guid_key" ON public."Unit" USING btree (guid);


--
-- Name: Unit_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Unit_sourceUpdatedAt_idx" ON public."Unit" USING btree ("sourceUpdatedAt");


--
-- Name: UserRoute_userId_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "UserRoute_userId_startedAt_idx" ON public."UserRoute" USING btree ("userId", "startedAt");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Warehouse_guid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Warehouse_guid_key" ON public."Warehouse" USING btree (guid);


--
-- Name: Warehouse_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isActive_idx" ON public."Warehouse" USING btree ("isActive");


--
-- Name: Warehouse_isDefault_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_isDefault_idx" ON public."Warehouse" USING btree ("isDefault");


--
-- Name: Warehouse_sourceUpdatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Warehouse_sourceUpdatedAt_idx" ON public."Warehouse" USING btree ("sourceUpdatedAt");


--
-- Name: _EmployeeDepartmentRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_EmployeeDepartmentRoles_B_index" ON public."_EmployeeDepartmentRoles" USING btree ("B");


--
-- Name: AppUpdateEvent AppUpdateEvent_updateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_updateId_fkey" FOREIGN KEY ("updateId") REFERENCES public."AppUpdate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppUpdateEvent AppUpdateEvent_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppUpdateEvent"
    ADD CONSTRAINT "AppUpdateEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AppealAssignee AppealAssignee_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAssignee AppealAssignee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAssignee"
    ADD CONSTRAINT "AppealAssignee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealAttachment AppealAttachment_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealAttachment"
    ADD CONSTRAINT "AppealAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessageRead AppealMessageRead_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."AppealMessage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessageRead AppealMessageRead_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessageRead"
    ADD CONSTRAINT "AppealMessageRead_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AppealMessage AppealMessage_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealMessage AppealMessage_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealMessage"
    ADD CONSTRAINT "AppealMessage_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealStatusHistory AppealStatusHistory_changedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealStatusHistory"
    ADD CONSTRAINT "AppealStatusHistory_changedById_fkey" FOREIGN KEY ("changedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_appealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_appealId_fkey" FOREIGN KEY ("appealId") REFERENCES public."Appeal"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AppealWatcher AppealWatcher_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppealWatcher"
    ADD CONSTRAINT "AppealWatcher_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Appeal Appeal_fromDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_fromDepartmentId_fkey" FOREIGN KEY ("fromDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Appeal Appeal_toDepartmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appeal"
    ADD CONSTRAINT "Appeal_toDepartmentId_fkey" FOREIGN KEY ("toDepartmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientAgreement ClientAgreement_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientAgreement"
    ADD CONSTRAINT "ClientAgreement_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientContract ClientContract_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientContract"
    ADD CONSTRAINT "ClientContract_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientProfile ClientProfile_activeAgreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeAgreementId_fkey" FOREIGN KEY ("activeAgreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeContractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeContractId_fkey" FOREIGN KEY ("activeContractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeDeliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeDeliveryAddressId_fkey" FOREIGN KEY ("activeDeliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activePriceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activePriceTypeId_fkey" FOREIGN KEY ("activePriceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_activeWarehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_activeWarehouseId_fkey" FOREIGN KEY ("activeWarehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ClientProfile ClientProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClientProfile"
    ADD CONSTRAINT "ClientProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeliveryAddress DeliveryAddress_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeliveryAddress"
    ADD CONSTRAINT "DeliveryAddress_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DepartmentRole DepartmentRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepartmentRole"
    ADD CONSTRAINT "DepartmentRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DeviceToken DeviceToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DeviceToken"
    ADD CONSTRAINT "DeviceToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EmailVerification EmailVerification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailVerification"
    ADD CONSTRAINT "EmailVerification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeProfile EmployeeProfile_departmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES public."Department"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmployeeProfile EmployeeProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeProfile"
    ADD CONSTRAINT "EmployeeProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LoginAttempt LoginAttempt_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginAttempt"
    ADD CONSTRAINT "LoginAttempt_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_packageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_packageId_fkey" FOREIGN KEY ("packageId") REFERENCES public."ProductPackage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrderItem OrderItem_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_contractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_contractId_fkey" FOREIGN KEY ("contractId") REFERENCES public."ClientContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_deliveryAddressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_deliveryAddressId_fkey" FOREIGN KEY ("deliveryAddressId") REFERENCES public."DeliveryAddress"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductGroup ProductGroup_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductGroup"
    ADD CONSTRAINT "ProductGroup_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPackage ProductPackage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPackage ProductPackage_unitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPackage"
    ADD CONSTRAINT "ProductPackage_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductPrice ProductPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductPrice ProductPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductPrice"
    ADD CONSTRAINT "ProductPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_baseUnitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_baseUnitId_fkey" FOREIGN KEY ("baseUnitId") REFERENCES public."Unit"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."ProductGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QRAnalytic QRAnalytic_qrListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRAnalytic"
    ADD CONSTRAINT "QRAnalytic_qrListId_fkey" FOREIGN KEY ("qrListId") REFERENCES public."QRList"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QRList QRList_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QRList"
    ADD CONSTRAINT "QRList_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RolePermissions RolePermissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RolePermissions"
    ADD CONSTRAINT "RolePermissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Role Role_parentRoleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_parentRoleId_fkey" FOREIGN KEY ("parentRoleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RoutePoint RoutePoint_routeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_routeId_fkey" FOREIGN KEY ("routeId") REFERENCES public."UserRoute"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RoutePoint RoutePoint_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoutePoint"
    ADD CONSTRAINT "RoutePoint_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SpecialPrice SpecialPrice_agreementId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES public."ClientAgreement"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_counterpartyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_counterpartyId_fkey" FOREIGN KEY ("counterpartyId") REFERENCES public."Counterparty"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_priceTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_priceTypeId_fkey" FOREIGN KEY ("priceTypeId") REFERENCES public."PriceType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SpecialPrice SpecialPrice_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SpecialPrice"
    ADD CONSTRAINT "SpecialPrice_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StockBalance StockBalance_warehouseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StockBalance"
    ADD CONSTRAINT "StockBalance_warehouseId_fkey" FOREIGN KEY ("warehouseId") REFERENCES public."Warehouse"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SupplierProfile SupplierProfile_addressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_addressId_fkey" FOREIGN KEY ("addressId") REFERENCES public."Address"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SupplierProfile SupplierProfile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SupplierProfile"
    ADD CONSTRAINT "SupplierProfile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SyncRunItem SyncRunItem_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SyncRunItem"
    ADD CONSTRAINT "SyncRunItem_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."SyncRun"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserRoute UserRoute_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserRoute"
    ADD CONSTRAINT "UserRoute_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."DepartmentRole"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _EmployeeDepartmentRoles _EmployeeDepartmentRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_EmployeeDepartmentRoles"
    ADD CONSTRAINT "_EmployeeDepartmentRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."EmployeeProfile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 5QgOfEMcWP0q1OVBrwr6AdTqOba8NDluI8Tg6wVmxygfeHrvUsg0NSAxNrZJoPk

